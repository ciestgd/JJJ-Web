/*eslint-disable*/
import { defineConfig, loadEnv } from "vite";
import vue from "@vitejs/plugin-vue";
import vitePluginSvgIcons from "vite-plugin-svg-icons"; //npm i vite-plugin-svg-icons@1.1.0
import { resolve } from "path"; //npm install --save-dev @types/node 安装path插件
import { env } from "process";
// https://vitejs.dev/config/
export default defineConfig(({ mode, command }) => {
  const env = loadEnv(mode, process.cwd());
  const { VITE_APP_ENV, VITE_PUBLIC_PATH, VITE_APP_BASE_API } = env;
  // console.log(VITE_APP_ENV ,'VITE_APP_ENV')
  // console.log(VITE_PUBLIC_PATH,'VITE_PUBLIC_PATH')
  // console.log(VITE_APP_BASE_API,'VITE_APP_BASE_API')
  return {
    plugins: [
      vue(),
      /**
       *  把src/icons 下的所有svg 自动加载到body下，供组件使用
       */
      vitePluginSvgIcons({
        // 指定需要缓存的图标文件夹，地址可改
        iconDirs: [resolve(process.cwd(), "src/static/svg")],
        // 指定symbolId格式
        symbolId: "icon-[dir]-[name]",
      }),
    ],
    resolve: {
      alias: {
        //配置别名
        "@": resolve(__dirname, "./src"),
      },
    },
    base: VITE_APP_ENV === "production" ? VITE_PUBLIC_PATH : "/", //如果后面分开发和线上再用这个
    // base: '/',

    //  生产环境
    build: {
      //配置打包后文件，不配置的话 打包后文件很杂乱
      assetsDir: "static/img/",
      // sourcemap: true,
      rollupOptions: {
        output: {
          chunkFileNames: "static/js/[name]-[hash].js",
          entryFileNames: "static/js/[name]-[hash].js",
          assetFileNames: "static/css/[name]-[hash].[ext]",
        },
      },
      terserOptions: {
        compress: {
          drop_console: true, // 生产环境去除console
          drop_debugger: true, // 生产环境去除debugger
        },
      },
    },

    server: {
      port: 8000, // 端口号
      host: "0.0.0.0",
      open: true, // 自动在浏览器打开
      https: false, // 是否开启 https
      proxy: {
        "/api": {
          target: VITE_APP_BASE_API,
          changeOrigin: true,
          secure: false,
          ws: true,
          rewrite: (path) => path.replace(/^\/api/, ""), //有些接口不需要有些需要
        },
        "/ue_api": {
          target: "http://10.8.0.91/ue_api/",
          changeOrigin: true,
        },
      },
    },
    //关闭每次保存都进行检测
    lintOnSave: false,
  };
});
