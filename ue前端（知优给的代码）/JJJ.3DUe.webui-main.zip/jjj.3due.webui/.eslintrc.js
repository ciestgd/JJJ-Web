module.exports = {
  env: {
    browser: true,
    es2021: true
  },
  extends: ['plugin:vue/vue3-strongly-recommended', 'standard'],
  parserOptions: {
    ecmaVersion: 'latest',
    parser: '@typescript-eslint/parser',
    sourceType: 'module'
  },
  plugins: ['vue', '@typescript-eslint'],
  rules: {
    'vue/multi-word-component-names': 0, // Component name "home" should always be multi-word  vue/multi-word-component-names
    camelcase: 'off', // 关闭驼峰命名规则校验
    'new-cap': 'off', // 关闭构造函数名需以大写字母开头，以下内置标识符可免除此规则
    'vue/no-template-shadow': 'off', // Vue报错 Variable ‘scope’ is already declared in the upper scope’
    'no-extra-boolean-cast': 2
  }
}
