<!--
  作者：qing
  时间：2022年03月29日 16:33:24
-->
<script setup lang="ts">
/*eslint-disable*/
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { storage } from '@/storage/storage'
import { reactive, ref, onMounted } from 'vue'
import { Coordinate, Lock } from '@element-plus/icons-vue'
import { getCodeImg, getLogin } from '@/api/login'
import screenfull from 'screenfull'
const store = useStore()
const router = useRouter()

/**
 * @interface LoginParams -登录参数
 * @property {any} account -用户名
 * @property {any} password -用户密码
 * @property {string} captcha -验证码
 * @property {string} domain -域名
 * @property {number} type -域名
 */
interface LoginParams {
  username: any;
  password: any;
  code: string;
  uuid: any;
}
const formLabelAlign = reactive<LoginParams>({
  username: '',
  password: '',
  code: '',
  uuid: ''
})
const codeUrl = ref('')

// 是否全屏
// const isFullscreen = ref(false)

// 监听变化
// const change = () => {
//   isFullscreen.value = screenfull.isFullscreen
// }



const getCode = () => {
  getCodeImg().then((res: any) => {
    if (res.code == 200) {
      codeUrl.value = "data:image/gif;base64," + res.img
      formLabelAlign.uuid = res.uuid
    }
  });
}

const changeCode = () => {
  getCode()
}



const login = () => {
  getLogin(formLabelAlign).then((res: any) => {
    if (res.code == 200) {
      store.commit('appStore/SET_TOKEN', res.data.access_token)
      store.commit('appStore/SET_HOMESTATUS', true)
      store.commit('appStore/SET_STATUSOPEN', [true, false,false,false])
      router.push({ path: '/' })
      // screenfull.toggle()
    }
  })
    .catch((error: any) => {
      formLabelAlign.code = ''
      getCode()
    });


}


onMounted(() => {
  getCode()
  // screenfull.on('change', change)
})
</script>

<template>
  <div class="login">
    <!-- <img src="../static/image/bg.png" alt=""> -->
    <div class="loginMain">
      <el-form label-width="100px" :model="formLabelAlign" style="max-width: 600px" label-position="top">
        <el-form-item label="账号">
          <el-input v-model="formLabelAlign.username" :prefix-icon="Coordinate" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input type="password" show-password v-model="formLabelAlign.password" :prefix-icon="Lock" />
        </el-form-item>
        <el-form-item label="验证码">
          <div class="codeDiv">
            <el-input v-model="formLabelAlign.code" />
            <img @click="changeCode" :src="codeUrl" alt="">
          </div>

        </el-form-item>
        <el-button @click="login" class="btn">
          登录
        </el-button>
      </el-form>
    </div>
  </div>
</template>

<style lang="less" scoped>
@import "../styles/config.less";

.login {
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-image: url(../static/image/bg.png);
}

.loginMain {
  width: 31.25rem
    /* 600px -> 31.25rem */
  ;
  height: 20.8333rem
    /* 400px -> 20.8333rem */
  ;
  border-radius: 20px;
  display: flex;
  justify-content: center;
  background-color: rgba(245, 245, 245, 0.5);
  padding-top: 20px;
  backdrop-filter: blur(5px);
}

.codeDiv {
  width: 100%;
  display: flex;
  align-items: center;

  img {
    height: 2.2396rem
      /* 43px -> 2.2396rem */
    ;
  }

}

.btn {
  width: 18.2292rem
    /* 350px -> 18.2292rem */
  ;
  height: 2.2396rem
    /* 43px -> 2.2396rem */
  ;
  background-color: @mainColor;
  border: 0;
  margin-top: 10px;
  font-size: 14px;
}
</style>
