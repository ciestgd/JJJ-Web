<!--
  作者：qing
  时间：2022年03月28日 14:57:08
-->

<script setup lang="ts">
import {
  onUnmounted,
  onMounted,
  toRaw,
  ref
} from 'vue'
import {
  drawLine,
  drawText
} from '@/canvas/fun'
import screenfull from 'screenfull'

import { Swiper, SwiperSlide } from 'swiper/vue'
import 'swiper/css'
import { Autoplay } from 'swiper'
import ue4Player from '@/assets/ue4Player/ue4Player.vue'
import { app_load, api_send } from '@/assets/ue4Player/app'
const modules = [Autoplay]
// 定义swiperNew,目的获取非响应式swiper
let swiperNew: any

// 是否全屏
// const isFullscreen = ref(false)

// 监听变化
// const change = () => {
//   console.log('661')
//   isFullscreen.value = screenfull.isFullscreen
// }

// 切换事件
// const onToggle = () => {
//   // alert('88')
//   screenfull.toggle()
// }

const enter = () => {
  // console.log("...");
  swiperNew.autoplay.stop()
}
const leave = () => {
  swiperNew.autoplay.start()
}
const onSwiper = (swiper: any) => {
  swiperNew = toRaw(swiper)
  // console.log(swiperNew)
}
const btn = () => {
  // alert('......')
  // console.log('22222222222222')
  const data = {
    pos: 'AAAA'
  }
  api_send('TEST', data, (info:any) => {
    // console.log(info)
  })
}

onMounted(() => {
  screenfull.on('change', change)
  // nextTick(() => {
  //   alert('88')
  //   screenfull.toggle()
  // })
  console.log(window.ue4, 'ue4........................................')

  app_load('192.168.110.157:31', () => {
    console.log('画面出现之前的回调，可进行一些初始操作')
  })
  //   canvas.width = window.innerWidth;
  // canvas.height = window.innerHeight;
  // let ctx=initCanvas("#cont");
  // ctx.fillRect(25, 25, 100, 100);
  // ctx.clearRect(45, 45, 60, 60);
  // ctx.strokeRect(50, 50, 50, 50);
  // ctx.fillStyle = "orange";

  // ctx.beginPath();
  // ctx.moveTo(80, 80);
  // ctx.lineTo(105, 80);
  // ctx.lineTo(80, 105);
  // ctx.lineTo(80, 80);
  // ctx.stroke();
  // ctx.closePath();

  // drawLine("#cont",0,200,400,200,'blue')
  // drawLine("#cont",200,0,200,400,'blue')
  // drawText("#cont","米",200,200,'300px')
  // drawLineDash("#cont",0,0,400,400,'blue')
  // drawLineDash("#cont",0,400,400,0,'blue')
  // drawImage("#cont",'https://mdn.mozillademos.org/files/5397/rhino.jpg',0,0,400,400)
  // drawText("#cont","米",100,100,'100px')
  // roundRect("#cont",0,0,100,100,50,'black')
  drawLine('#cont', 0, 200, 400, 200, 'red')
  drawLine('#cont', 200, 0, 200, 400, 'red')
  drawText('#cont', '米', 200, 200, '300px')
})
// 删除监听器
onUnmounted(() => {
  screenfull.off('change', change)
})
</script>

<template>
  <div class="index">
    <!-- <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide" v-for="(item, index) in imgs" :key="index">
          {{ item.pic }}
        </div>
      </div>
    </div> -->
    <div>
      <!-- <svg-icon
        :icon="isFullscreen ? 'exit-fullscreen' : 'fullscreen'"
        @click="onToggle"
      /> -->
      <div
        style="height: 5rem;width:5rem;border:1px solid red;"
      >
        sdadasdasdasdasdasdasdasdasd
      </div>
    </div>
    <ue4Player />
    <button
      @click="btn"
      class="btnbtn"
    >
      点击
    </button>
    <swiper
      @swiper="onSwiper"
      :slides-per-view="3"
      :autoplay="{ delay: 2500, disableOnInteraction: false }"
      :loop="true"
      :direction="'vertical'"
      :space-between="10"
      :modules="modules"
      @mouseenter="enter"
      @mouseleave="leave"
    >
      <swiper-slide>Slide 1</swiper-slide>
      <swiper-slide>Slide 2</swiper-slide>
      <swiper-slide>Slide 3</swiper-slide>
      <swiper-slide>Slide 4</swiper-slide>
      <swiper-slide>Slide 5</swiper-slide>
      <swiper-slide>Slide 6</swiper-slide>
    </swiper>

    信息列表
    <canvas
      id="cont"
      width="400"
      height="400"
    >您的浏览器版本过低，请升级浏览器或使用chfrome打开！</canvas>
    <swiper
      @swiper="onSwiper"
      :slides-per-view="3"
      :autoplay="{ delay: 2500, disableOnInteraction: false }"
      :loop="true"
      :direction="'vertical'"
      :space-between="10"
      :modules="modules"
      @mouseenter="enter"
      @mouseleave="leave"
    >
      <swiper-slide>Slide 1</swiper-slide>
      <swiper-slide>Slide 2</swiper-slide>
      <swiper-slide>Slide 3</swiper-slide>
      <swiper-slide>Slide 4</swiper-slide>
      <swiper-slide>Slide 5</swiper-slide>
      <swiper-slide>Slide 6</swiper-slide>
    </swiper>
    <swiper
      @swiper="onSwiper"
      :slides-per-view="3"
      :autoplay="{ delay: 2500, disableOnInteraction: false }"
      :loop="true"
      :direction="'vertical'"
      :space-between="10"
      :modules="modules"
      @mouseenter="enter"
      @mouseleave="leave"
    >
      <swiper-slide>Slide 1</swiper-slide>
      <swiper-slide>Slide 2</swiper-slide>
      <swiper-slide>Slide 3</swiper-slide>
      <swiper-slide>Slide 4</swiper-slide>
      <swiper-slide>Slide 5</swiper-slide>
      <swiper-slide>Slide 6</swiper-slide>
    </swiper>
  </div>
</template>

<style lang="less" scoped>
    @import "@/styles/config.less";
.btnbtn{
  position: relative;
  z-index: 9999999999999999999;
}
.index{
  width: 100%;
  height: 6000px;
  border: 1px solid rgb(115, 89, 230);
}
#cont {
  width: 400px /* 500px -> 26.0417rem */;
  height: 400px /* 500px -> 26.0417rem */;
  border: 1px solid red;
  margin: 0 auto;
  display: block;
  max-width: 100%;
  max-height: 100%;
}
.swiper {
  width: 300px;
  height: 600px;
  border-radius: 10px;
  border: 1px solid red;
  .display;
  :deep(.swiper-slide) {
    height: 300px;
    font-size: 30px;
    text-align: center;
    background-color: lightgreen;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>
