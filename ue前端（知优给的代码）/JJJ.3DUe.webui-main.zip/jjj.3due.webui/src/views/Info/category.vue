<!--
  作者：qing
  时间：2022年03月28日 14:58:24
-->

<script setup lang="ts">
import { onMounted, reactive } from 'vue'

/* ----------------------------下拉菜单------------------------- */
const listDropDownArray = reactive([
  {
    value: 'a', title: '菜单1菜单1菜单1'
  },
  {
    value: 'b', title: '菜单2'
  },
  {
    value: 'c', title: '菜单3'
  }
])
const handleDropDownCommand = (command:any) => {
  // console.log(command)
}
/* ----------------------------下拉菜单 级联选择------------------------- */
const listCasCaderArray = reactive([
  {
    value: 'guide',
    label: 'Guide',
    children: [
      {
        value: 'disciplines',
        label: 'Disciplines',
        children: [
          {
            value: 'consistency',
            label: 'Consistency'
          },
          {
            value: 'feedback',
            label: 'Feedback'
          },
          {
            value: 'efficiency',
            label: 'Efficiency'
          },
          {
            value: 'controllability',
            label: 'Controllability'
          }
        ]
      },
      {
        value: 'navigation',
        label: 'Navigation',
        children: [
          {
            value: 'side nav',
            label: 'Side Navigation'
          },
          {
            value: 'top nav',
            label: 'Top Navigation'
          }
        ]
      }
    ]
  },
  {
    value: 'component',
    label: 'Component',
    children: [
      {
        value: 'basic',
        label: 'Basic',
        children: [
          {
            value: 'layout',
            label: 'Layout'
          },
          {
            value: 'color',
            label: 'Color'
          },
          {
            value: 'typography',
            label: 'Typography'
          },
          {
            value: 'icon',
            label: 'Icon'
          },
          {
            value: 'button',
            label: 'Button'
          }
        ]
      },
      {
        value: 'form',
        label: 'Form',
        children: [
          {
            value: 'radio',
            label: 'Radio'
          },
          {
            value: 'checkbox',
            label: 'Checkbox'
          },
          {
            value: 'input',
            label: 'Input'
          },
          {
            value: 'input-number',
            label: 'InputNumber'
          },
          {
            value: 'select',
            label: 'Select'
          },
          {
            value: 'cascader',
            label: 'Cascader'
          },
          {
            value: 'switch',
            label: 'Switch'
          },
          {
            value: 'slider',
            label: 'Slider'
          },
          {
            value: 'time-picker',
            label: 'TimePicker'
          },
          {
            value: 'date-picker',
            label: 'DatePicker'
          },
          {
            value: 'datetime-picker',
            label: 'DateTimePicker'
          },
          {
            value: 'upload',
            label: 'Upload'
          },
          {
            value: 'rate',
            label: 'Rate'
          },
          {
            value: 'form',
            label: 'Form'
          }
        ]
      },
      {
        value: 'data',
        label: 'Data',
        children: [
          {
            value: 'table',
            label: 'Table'
          },
          {
            value: 'tag',
            label: 'Tag'
          },
          {
            value: 'progress',
            label: 'Progress'
          },
          {
            value: 'tree',
            label: 'Tree'
          },
          {
            value: 'pagination',
            label: 'Pagination'
          },
          {
            value: 'badge',
            label: 'Badge'
          }
        ]
      },
      {
        value: 'notice',
        label: 'Notice',
        children: [
          {
            value: 'alert',
            label: 'Alert'
          },
          {
            value: 'loading',
            label: 'Loading'
          },
          {
            value: 'message',
            label: 'Message'
          },
          {
            value: 'message-box',
            label: 'MessageBox'
          },
          {
            value: 'notification',
            label: 'Notification'
          }
        ]
      },
      {
        value: 'navigation',
        label: 'Navigation',
        children: [
          {
            value: 'menu',
            label: 'Menu'
          },
          {
            value: 'tabs',
            label: 'Tabs'
          },
          {
            value: 'breadcrumb',
            label: 'Breadcrumb'
          },
          {
            value: 'dropdown',
            label: 'Dropdown'
          },
          {
            value: 'steps',
            label: 'Steps'
          }
        ]
      },
      {
        value: 'others',
        label: 'Others',
        children: [
          {
            value: 'dialog',
            label: 'Dialog'
          },
          {
            value: 'tooltip',
            label: 'Tooltip'
          },
          {
            value: 'popover',
            label: 'Popover'
          },
          {
            value: 'card',
            label: 'Card'
          },
          {
            value: 'carousel',
            label: 'Carousel'
          },
          {
            value: 'collapse',
            label: 'Collapse'
          }
        ]
      }
    ]
  },
  {
    value: 'resource',
    label: 'Resource',
    children: [
      {
        value: 'axure',
        label: 'Axure Components'
      },
      {
        value: 'sketch',
        label: 'Sketch Templates'
      },
      {
        value: 'docs',
        label: 'Design Documentation'
      }
    ]
  }
])
const changeCasCaderValue = (value:any) => {
  // console.log(value)
}
/* ----------------------------日期选择  年------------------------- */

const changeTimeYear = (dateString: string) => {
  console.log('Selected Time: ', dateString)
}
/* ----------------------------日期选择  日------------------------- */
const changeTimeDate = (dateString: string) => {
  console.log('Selected Time: ', dateString)
}

onMounted(() => {

  // 基于准备好的dom，初始化echarts实例
})
</script>

<template>
  <div class="category">
    <div style="display: flex;border:1px solid red;align-items: center;width: 15.625rem /* 300px -> 15.625rem */;height: 1.8229rem /* 35px -> 1.8229rem */">
      <CasCader
        :list="listCasCaderArray"
        @change-cas-cader-value="changeCasCaderValue"
      />
      <DropDown
        :list="listDropDownArray"
        @handle-drop-down-command="handleDropDownCommand"
      />
    </div>

    <div
      class="aDatePicker"
      style="display: flex;flex-flow: row;"
    >
      <ADatePickerYear @change-time-year="changeTimeYear" />
      <ADatePickerDate @change-time-date="changeTimeDate" />
    </div>
    <p class="ss">
      信息分类
    </p>
  </div>
</template>

<style lang="less" scoped>
@import "@/styles/config.less";
.category {
  font-size: 0.4688rem /* 18px -> .4688rem */;
  // display: flex;
}
.aDatePicker {
  margin: 0 60px 0 60px;
}

</style>
