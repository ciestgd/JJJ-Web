<script setup lang="ts">
import {
} from 'vue'
// const routes = reactive<any>(router.options.routes)
// 菜单中 path带‘/’ 代表能够跳转的页面，没带则在入口页
// 如果是需要跳转的页面(背景没有模型)，就按照安防监控的配置来，如果是需要背景是模型的按照智慧运营来配置
// const pageRoute = reactive([
//   {
//     meta: {
//       name: '海底机房',
//       smallName: 'Smart operations'
//     },
//     children: [
//       {
//         path: 'haiDiJiFang',
//         meta: {
//           name: '海底机房',
//           smallName: 'Smart operations'
//         }
//       }
//     ]
//   },
//   {
//     meta: {
//       name: '岸站',
//       smallName: 'Smart operations'
//     },
//     children: [
//       {
//         path: 'anzhan',
//         meta: {
//           name: '岸站',
//           smallName: 'Smart operations'
//         }
//       }
//     ]
//   }
// ])
/*
 *@description:导航菜单点击操作
 *@author: qing
 *@date: 2022-04-19 11:10:19
 */
</script>

<template>
  <div class="Nav">
    <div style="height: 100%">
      <!-- <el-menu
        :default-active="activeIndex"
        class="el-menu-vertical-demo"
        mode="horizontal"
        @open="handleOpen"
        @close="handleClose"
        @select="handleSelect"
        background-color="transpart"
        text-color="#fff"
        active-text-color="#ffd04b"
      >
        <template
          v-for="(item, index) in pageRoute"
          :key="index"
        >
          <template>
            <el-menu-item
              class="zidingyi"
              :index="itemSmall.path"
              v-for="(itemSmall, index) in item.children"
              :key="index"
            >
              <div style="  display: flex; flex-flow: column;  align-items: center; position: relative; ">
                <span class="spanName">{{ item.meta.name }}</span>
              </div>
              <p class="bboder" />
            </el-menu-item>
          </template>
        </template>
      </el-menu> -->

      <!-- <div
        class="firstNavBox animated bounceIn"
      >
        <template
          v-for="(item, index) in pageRoute"
          :key="index"
        >
          <template
            v-for="(itemSmall, index) in item.children"
            :key="index"
          >
            <div
              class="firstNav"
              @click="handleSelect(itemSmall.path,itemSmall.meta.name)"
            >
              <span>{{ item.meta.name }}</span>
            </div>
            <div class="Hr" />
          </template>
        </template>
      </div> -->
    </div>
  </div>
</template>

<style lang="less" scoped>
@import "../../../styles/config.less";

.Nav {
  // width: @navMenu;
  height: 100%;
  left: 0;
  display: flex;
  flex-flow: column;
  .webkit(transition,all 0.3s ease 0s);
}
</style>
