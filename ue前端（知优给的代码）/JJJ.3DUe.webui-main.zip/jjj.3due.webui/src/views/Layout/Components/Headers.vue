<script setup lang="ts">
import { ref, onMounted } from 'vue'
import LayoutNav from './Nav.vue'
import { useUserStore } from '@/store1/zhuangTaiGuanjLi'
import { shuJuChangStore } from '@/store1/shuJuChang'
const userStore1 = useUserStore()
const ShuJuChangData = shuJuChangStore()
// 是否全屏
// const isFullscreen = ref(false)

// 监听变化
// const change = () => {
//   console.log('661')
//   isFullscreen.value = screenfull.isFullscreen
// }

// const username = computed(() => store.state.appStore.username)
const nowTime: any = ref('')
// 当前时间
const nowTimeFun = () => {
  const nowDate = new Date()
  const year: any = nowDate.getFullYear()
  let month: any = nowDate.getMonth() + 1
  month = month > 9 ? month : '0' + month
  let date: any = nowDate.getDate()
  date = date > 9 ? date : '0' + date
  let hour: any = nowDate.getHours()
  hour = hour > 9 ? hour : '0' + hour
  let miunte: any = nowDate.getMinutes()
  miunte = miunte > 9 ? miunte : '0' + miunte
  let second: any = nowDate.getSeconds()
  second = second > 9 ? second : '0' + second
  nowTime.value =
    year + '-' + month + '-' + date + ' ' + hour + ':' + miunte + ':' + second
}

onMounted(() => {
  // screenfull.on('change', change)  全屏
  setInterval(function () {
    nowTimeFun()
  }, 1000)
  ShuJuChangData.getshuJuChangList('64')
})
</script>

<template>
  <!-- 头部背景图 -->
  <div class="Headers">
    <div class="titleNav">
      <span>基础项目</span>
    </div>
    <div v-show="userStore1.firstNavBox">
      <LayoutNav />
    </div>
  </div>
</template>

<style lang="less" scoped>
@import "@/styles/config.less";
.Headers {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 4rem;
  background-image: url("@/assets/image/topNav.png");
  background-size: 100% 100%;
  background-repeat: no-repeat;
  z-index: 999;
  display: flex;
  align-items: center;
}
</style>
