<!--
  作者：qing
  时间：2022年03月28日 10:00:06
-->

<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRouter } from 'vue-router'
const router = useRouter()
const isTop = ref(false)
watch(
  () => router.currentRoute.value.path,
  (newValue, oldValue) => {
    if (newValue === '/index') {
      isTop.value = false
    } else {
      isTop.value = true
    }
  },
  { immediate: true }
)
</script>

<template>
  <div class="Main">
    <div
      class="content"
    >
      <router-view />
    </div>
  </div>
</template>

<style lang="less" scoped>
@import "../../../styles/config.less";
.Main {
  width: 100%;
  // height: 100vh;
  // position: fixed;
  // top: 0;
  border-bottom: none;
  // background-color: #3f17d2;
  .webkit(transition,all .3s ease 0s);
  // border: 1px solid red;
  // z-index: 999999;
  // margin-top: @layoutHeader;
  // padding-top:1.5625rem /* 30px -> 1.5625rem */;
}

.content {
  width: 100%;
  // height: 100%;
  box-sizing: border-box;
  background-color: white;

}
.isaaa{
  padding-top: @layoutHeader;
}
</style>
