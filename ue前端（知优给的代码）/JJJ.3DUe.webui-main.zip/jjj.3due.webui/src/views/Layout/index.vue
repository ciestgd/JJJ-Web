<!--
  作者：qing
  时间：2022年03月28日 09:57:32
-->

<script setup lang="ts">
import { computed } from "vue";
import LayoutHeaders from "./Components/Headers.vue";
import LayoutMain from "./Components/Main.vue";
import { useStore } from "vuex";
const store = useStore();
const menuStatus = computed(() => store.state.appStore.isCollapse);
</script>

<template>
  <div class="index" :class="[menuStatus ? 'close' : 'open']">
    <!-- <LayoutHeaders /> -->
    <LayoutMain />
    <!-- <LayoutNav> </LayoutNav> -->
  </div>
</template>

<style lang="less" scoped>
.index {
  width: 100%;
  // height: 100vh;
  background-color: #f7f7f7;
  // border: 1px solid red;
}
</style>
