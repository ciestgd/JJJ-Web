<script setup lang="ts">
import { onMounted } from "vue";
import { useStore } from "vuex";
import { ue4Init } from "@/assets/index.js";
import { switchLevelFun } from "@/api/ue4";
// 初始化的ue4的对象
let ue4Config: any;
const store = useStore();

// vue钩子函数
onMounted(() => {
  let host = window.location.host;
  let url = `${host}${import.meta.env.VITE_MOOE_UE4_IP}`;
  console.log("url", url);
  // 初始化ue4视频流
  ue4Config = new ue4Init({
    url: url,
    name: import.meta.env.VITE_MODE_PROJECT_NAME,
  });
  // 把ue4对象挂在到window上
  if (ue4Config) window.ue4 = ue4Config;
  // 点击视频流返回的事件
  ue4Config.message = (ue4Date: any) => {
    // 更新保存的点击数据
    console.log(
      "%c console页面ue4Date 接收ue4返回参数",
      "background:#8a9bf0;color:#fff;padding:3px;border-radius:2px",
      ue4Date
    );
  };
  store.state.ue4.ue4Config = ue4Config;
});
</script>

<template>
  <div class="main">
    <div class="index">
      <!-- 推流地址 -->
      <div id="player" class="flowBoxWarp" />
    </div>
  </div>
</template>

<style lang="less" scoped>
@import "@/styles/config.less";

.main {
  width: 100%;
  height: 100vh;
  position: fixed;
}

.index {
  width: 100%;
  height: 100%;
  position: relative;
  top: 0;
  left: 0;
}

.flowBoxWarp {
  width: 100% !important;
  height: 100% !important;
  position: absolute;
  top: 0px;
  left: 0px;
  z-index: 1;
}

.bottomImg {
  z-index: 3;
  width: 97.5521rem /* 1873px -> 97.5521rem */;
  height: 3.9063rem /* 75px -> 3.9063rem */;
  margin: 0 auto;
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  background-image: url(/src/assets/image/bttomNav.png);
  background-size: 100% 100%;
  background-repeat: no-repeat;
  cursor: pointer;

  span {
    width: 3.3854rem /* 65px -> 3.3854rem */;
    height: 3.9063rem /* 75px -> 3.9063rem */;
    display: block;
    font-size: 0.8333rem /* 16px -> .8333rem */;
    font-family: "PingFang SC-Regular";
    font-weight: normal;
    color: #a6e2fe;
    line-height: 4.5833rem /* 88px -> 4.5833rem */;
    position: absolute;
    left: 48.8%;
    text-align: center;
  }
}

.leftDD {
  width: 18.2292rem /* 350px -> 18.2292rem */;
  height: 100%;
  background: var(--leftBg);
  border-radius: 0px 0px 0px 0px;
  opacity: 0.25;
  position: absolute;
  top: 0;
  left: 0;
}

.rightDD {
  width: 18.2292rem /* 350px -> 18.2292rem */;
  height: 100%;
  background: linear-gradient(-90deg, #262f44 0%, rgba(84, 84, 84, 0) 100%);
  border-radius: 0px 0px 0px 0px;
  opacity: 0.25;
  position: absolute;
  top: 0;
  right: 0;
}
</style>
