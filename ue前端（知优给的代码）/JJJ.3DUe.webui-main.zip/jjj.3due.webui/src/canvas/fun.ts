
export const initCanvas = (id: any): any => {
  return document.querySelector(id).getContext('2d')
}
/*
 *@functionName: drawLine
 *@params1: id 画布id
 *@params2: x1 起始x坐标
 *@params3: y1 起始y坐标
 *@params4: x2 终点x坐标
 *@params5: y2 终点y坐标
 *@params6: color 直线的颜色 可选
 *@description: 封装画直线方法
 *@author: qing
 *@date: 2022-04-28 17:12:43
*/
export const drawLine = (id: any, x1: number, y1: number, x2: number, y2: number, color?: any): any => {
  const ctx = document.querySelector(id).getContext('2d')
  ctx.beginPath()
  ctx.moveTo(x1, y1)
  ctx.lineTo(x2, y2)
  ctx.strokeStyle = color || '#000'
  ctx.stroke()
  ctx.closePath()
}

/*
 *@functionName: drawLineDash
 *@params1: id 画布id
 *@params2: x1 起始x坐标
 *@params3: y1 起始y坐标
 *@params4: x2 终点x坐标
 *@params5: y2 终点y坐标
 *@params6: color 虚线的颜色 可选
 *@description: 封装画虚线方法
 *@author: qing
 *@date: 2022-04-28 17:37:57
*/
export const drawLineDash = (id: any, x1: number, y1: number, x2: number, y2: number, color?: any): any => {
  const ctx = document.querySelector(id).getContext('2d')
  ctx.beginPath()
  ctx.setLineDash([5, 15]) // 5为虚线的长度，15为虚线之间的间隔
  ctx.moveTo(x1, y1)
  ctx.lineTo(x2, y2)
  ctx.strokeStyle = color || '#000'
  ctx.stroke()
  ctx.closePath()
}

/*
 *@functionName: drawText
 *@params1: id 画布id
 *@params2: text 文本内容
 *@params3: x 起始x坐标
 *@params4: y 终点y坐标
 *@params5: fontSize 文字大小
 *@params6: fontFamily 文字类型  默认值 楷体
 *@description: 封装画文本方法
 *@author: qing
 *@date: 2022-04-28 17:22:33
*/
export const drawText = (id: any, text: any, x: number, y: number, fontSize: any, fontFamily: any = '楷体'): any => {
  const ctx = document.querySelector(id).getContext('2d')
  ctx.font = fontSize + ' ' + fontFamily
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, x, y)
}

/**
 * @function drawImage
 * @param  id 画布id
 * @param img 图片路径
 * @param x 起始x坐标
 * @param y 终点y坐标
 * @param width 图片宽度
 * @param height 图片高度
 * @description 封装绘制图片的方法   可以加文字
 * @author qing
 * @date 2022-04-29 09:45:50
 */
export const drawImage = (id: any, img: any, x: number, y: number, width: any, height: any): any => {
  const ctx = document.querySelector(id).getContext('2d')
  const image = new Image()
  image.src = img
  image.onload = function () {
    ctx.drawImage(image, x, y, width, height)
    // 添加文字 后面两个数字是坐标
    // ctx.font  = "20px sans-serif"
    // ctx.fillStyle = '#e22018'
    // ctx.fillText("添加文字", 200, 137);
    // ctx.fillText("222222", 300, 200);
  }
}

/*
 *@functionName: roundRect
 *@param { Number } x x - 矩形的x坐标
 *@param { Number } y y - 矩形的y坐标
 *@param { Number } w w - 矩形的宽度
 *@param { Number } h h - 矩形的高度
 *@param { Number } r r - 矩形的圆角半径    类似 border-radius
 *@param { String } c [c = 'transparent'] - 矩形的填充色
 *@description: 绘制圆角矩形
 *@author: qing
 *@date: 2022-04-29 10:51:20
*/
export const roundRect = (id: any, x: any, y: any, w: any, h: any, r: any, c: any) => {
  const ctx = document.querySelector(id).getContext('2d')
  if (w < 2 * r) { r = w / 2 }
  if (h < 2 * r) { r = h / 2 }

  ctx.beginPath()
  ctx.fillStyle = c

  ctx.arc(x + r, y + r, r, Math.PI, Math.PI * 1.5)
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.lineTo(x + w, y + r)

  ctx.arc(x + w - r, y + r, r, Math.PI * 1.5, Math.PI * 2)
  ctx.lineTo(x + w, y + h - r)
  ctx.lineTo(x + w - r, y + h)

  ctx.arc(x + w - r, y + h - r, r, 0, Math.PI * 0.5)
  ctx.lineTo(x + r, y + h)
  ctx.lineTo(x, y + h - r)

  ctx.arc(x + r, y + h - r, r, Math.PI * 0.5, Math.PI)
  ctx.lineTo(x, y + r)
  ctx.lineTo(x + r, y)

  ctx.fill()
  ctx.closePath()
}
