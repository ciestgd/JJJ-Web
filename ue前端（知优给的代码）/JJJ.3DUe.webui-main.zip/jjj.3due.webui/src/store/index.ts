import { createStore } from 'vuex' // npm install vuex@next --save  安装vuex
import appStore from './appStore'
import pemission from './pemission'
import ue4 from './ue4'
const store = createStore({
  modules: {
    appStore,
    pemission,
    ue4
  }
})
// 将store store 导出去  不然在ts文件中用不成store
export function myStore () {
  return store
}

export default store
