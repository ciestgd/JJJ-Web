import { storage } from '@/storage/storage'
export interface States {
    countVuex: number,
    token: any,
    username:any,
    isCollapse:any,
    statusOpen:any,
    homeStatus:any,
    mainColor:any,
    leftHeight:any,
    leftSmallHeight:any,
    leftTop:any,
    initStatus:any,
    urlKey:any,
    floor:any,
    loading:any,
    modelId:any,
    floorCode:any,
    deviceName:any,
    deviceId:any
}

const states: States = {
  countVuex: 0,
  modelId: storage.get('modelId') ? storage.get('modelId') : [], // 模型id集合
  token: storage.get('token') ? storage.get('token') : '',
  username: storage.get('username') ? storage.get('username') : '',
  isCollapse: storage.get('isCollapse') ? storage.get('isCollapse') : false,
  statusOpen: storage.get('statusOpen') ? storage.get('statusOpen') : [],
  homeStatus: storage.get('homeStatus') ? storage.get('homeStatus') : true,
  mainColor: storage.get('mainColor') ? storage.get('mainColor') : '',
  leftHeight: storage.get('leftHeight') ? storage.get('leftHeight') : '25.8681rem',
  leftSmallHeight: storage.get('leftSmallHeight') ? storage.get('leftSmallHeight') : '18.5764rem',
  leftTop: storage.get('leftTop') ? storage.get('leftTop') : '0.520rem',
  initStatus: storage.get('initStatus') ? storage.get('initStatus') : true, // 报警模块初始化
  urlKey: storage.get('urlKey') ? storage.get('urlKey') : '', // 跳转的页面地址key
  floor: storage.get('floor') ? storage.get('floor') : '', // 点击的那一楼
  loading: storage.get('loading') ? storage.get('loading') : false,
  floorCode: storage.get('floorCode') ? storage.get('floorCode') : '', // 点击的那一楼code值
  deviceName: storage.get('deviceName') ? storage.get('deviceName') : '',
  deviceId: storage.get('deviceId') ? storage.get('deviceId') : ''

}

export default states
