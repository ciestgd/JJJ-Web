export default {
  countVuex: (state: any) => state.countVuex,
  isCollapse: (state: any) => state.isCollapse,
  username: (state: any) => state.username
}
