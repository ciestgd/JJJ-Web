
export default {
  ADD_ACOUNTVUEX (store: any, countVuex: Number) {
    store.commit('ADD_ACOUNTVUEX', countVuex)
  },

  /**
     * 退出登录
     * @returns
     */
  exit (content:any) {
    return new Promise((resolve:any) => {
      content.commit('DELETE_TOKEN')
      resolve()
    })
  }
}
