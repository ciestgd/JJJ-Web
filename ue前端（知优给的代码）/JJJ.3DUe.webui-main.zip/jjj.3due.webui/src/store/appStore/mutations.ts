import { storage } from '@/storage/storage'

export default {
  SET_URLKEY (state: any, urlKey: any) {
    state.urlKey = urlKey
    storage.set('urlKey', urlKey)
  },
  ADD_ACOUNTVUEX (state: any, countVuex: Number) {
    state.countVuex = countVuex
  },
  SET_ISCOLLAPSE (state: any, isCollapse: Boolean) {
    state.isCollapse = !state.isCollapse
  },
  SET_TOKEN (state: any, token: any) {
    state.token = token
    storage.set('token', token)
  },
  SET_LOADING (state: any, loading: Boolean) {
    state.loading = !state.loading
  },
  SET_MAINCOLOR (state: any, mainColor: any) {
    state.mainColor = mainColor
    storage.set('mainColor', mainColor)
  },
  SET_FLOOR (state: any, floor: any) {
    state.floor = floor
    storage.set('floor', floor)
  },
  SET_STATUSOPEN (state: any, statusOpen: any) {
    state.statusOpen = statusOpen
  },

  SET_MODELID (state: any, modelId: any) {
    state.modelId = modelId
    storage.set('modelId', modelId)
  },
  SET_DEVICENAME (state: any, deviceName: any) {
    state.deviceName = deviceName
    storage.set('deviceName', deviceName)
  },
  SET_DEVICEID (state: any, deviceId: any) {
    state.deviceId = deviceId
    storage.set('deviceId', deviceId)
  },
  SET_FLOORCODE (state: any, floorCode: any) {
    state.floorCode = floorCode
    storage.set('floorCode', floorCode)
  },

  SET_HOMESTATUS (state: any, homeStatus: any) {
    state.homeStatus = homeStatus
    storage.set('homeStatus', homeStatus)
  },
  SET_LEFTHEIGHT (state: any, leftHeight: any) {
    state.leftHeight = leftHeight
    storage.set('leftHeight', leftHeight)
  },
  SET_INITSTATUS (state: any, initStatus: any) {
    state.initStatus = initStatus
    storage.set('initStatus', initStatus)
  },

  SET_LEFTSMALLHEIGHT (state: any, leftSmallHeight: any) {
    state.leftSmallHeight = leftSmallHeight
    storage.set('leftSmallHeight', leftSmallHeight)
  },
  SET_LEFTTOP (state: any, leftTop: any) {
    state.leftTop = leftTop
    storage.set('leftTop', leftTop)
  },

  DELETE_TOKEN (state: any) {
    storage.remove('token')
    storage.remove('username')
    storage.set('isCollapse', false)
    state.token = ''
    state.username = ''
    state.isCollapse = false
  },
  SET_USERNAME (state: any, username: any) {
    state.username = username
  }

}
