import { defaultRouterMap } from '@/router'
export default {
  SET_ROLES (state: any, roles: Array<string>) {
    state.roles = roles
  },
  SET_ROUTER (state:any, router:any) {
    state.addRouters = router
    state.allRouters = defaultRouterMap.concat(router)
  }

}
