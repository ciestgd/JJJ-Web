/*eslint-disable*/
import { asyncRouterMap } from '@/router'
export default {

  /**
     * 创建路由
     * @param content
     * @param data
     * @returns
     */
  createRouter (content: any, data: any) {
    return new Promise((resolve, reject) => {
      const role = data // 获取后台给的角色权限 是个数组[userSystem,infoSystem]
      // console.log(role)
      // role= _.drop(data)
      // console.log(role)
      let addRouters = []
      if (role.includes('admin')) { // 如果权限是admin即最高权限，则能看所有路由
        addRouters = asyncRouterMap
        // console.log(asyncRouterMap,"asyncRouterMap")
      } else { // 这里判断角色权限，再去循环里判断  角色和路由里面的角色相匹配，再拿到所得的路由
        addRouters = asyncRouterMap.filter(item => {
          if (role.includes(item.meta.system)) {
            return item
          }
        })
        // console.log(addRouters,"asyncRouterMap")
      }

      // 更新路由
      content.commit('SET_ROUTER', addRouters)
      resolve(addRouters)
    })
  }
}
