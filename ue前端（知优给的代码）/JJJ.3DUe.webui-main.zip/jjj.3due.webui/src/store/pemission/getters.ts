export default {
  roles: (state: any) => state.roles,
  addRouters: (state: any) => state.addRouters, // 匹配路由
  allRouters: (state: any) => state.allRouters // 所有路由
}
