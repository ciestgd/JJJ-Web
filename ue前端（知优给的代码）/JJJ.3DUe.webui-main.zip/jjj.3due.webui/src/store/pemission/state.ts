
import { defaultRouterMap } from '@/router'
export interface States {
    roles:Array<any> ;
    allRouters:Array<any>;
    addRouters:Array<any>;
}

const states: States = {
  roles: [],
  allRouters: defaultRouterMap,
  addRouters: []
}

export default states
