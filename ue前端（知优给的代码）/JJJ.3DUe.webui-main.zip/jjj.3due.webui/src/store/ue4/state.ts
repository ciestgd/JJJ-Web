import { storage } from '@/storage/storage'
export interface States {
   ue4Config:any;
}

const states: States = {
  ue4Config: storage.get('ue4Config') ? storage.get('ue4Config') : {}
}

export default states
