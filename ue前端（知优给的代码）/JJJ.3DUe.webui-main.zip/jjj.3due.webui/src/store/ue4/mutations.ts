import { storage } from '@/storage/storage'

export default {
  SET_UE4CONFIG (state: any, ue4Config: any) {
    state.ue4Config = ue4Config
    storage.set('ue4Config', ue4Config)
  }
}
