import Axios from '@/utils/http'
import { IHttpResponse } from '@/types/interface'
/**
 * @interface loginParams -登录参数
 * @property {string} username -用户名
 * @property {string} password -用户密码
 */
interface LoginParams {
    pageNum: number
    pageSize: number
}
// 封装User类型的接口方法
export class UserService {
  /**
     * @description 查询User的信息
     * @param {number} teamId - 所要查询的团队ID
     * @return {HttpResponse} result
     */
  static login (data: LoginParams): Promise<IHttpResponse> {
    return Axios({
      url: '/api/index/init',
      method: 'post',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8'
      },
      responseType: 'json',
      data: {
        ...data
      }
    })
  }

  static resgister (params: LoginParams): Promise<IHttpResponse> {
    return Axios({
      url: '/api/index/getBulletin',
      method: 'get',
      responseType: 'json',
      params: {
        ...params
      }
    })
  }

  static async applist (params:any): Promise<IHttpResponse> {
    return Axios({
      url: params.url,
      method: params.post || 'post',
      responseType: 'json',
      data: {
        ...params.data || {}
      }
    })
  }
}
