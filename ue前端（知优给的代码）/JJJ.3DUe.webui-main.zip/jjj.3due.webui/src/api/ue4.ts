import { myStore } from "@/store/index";
// import { text } from 'stream/consumers'
import {} from "vue";

let ue4: any = null;

/** 初始化 ue4 对象 */
export function initUe4() {
  const store: any = myStore();
  ue4 = store.state.ue4.ue4Config.ue4;
  return ue4;
}
// setTimeout(() => {
//   const store: any = myStore();
//   // @ts-ignore
//   ue4 = store.state.ue4.ue4Config.ue4;
// }, 1000);

/* 通讯ue4 */
export function toUe4({ FuncName, Args }: any) {
  // const store:any = myStore()
  // ue4 = store.state.ue4.ue4Config.ue4
  // ue4.zhiu_SendMsgToUe({ FuncName, Args, time: +new Date() })
  if (!ue4) initUe4();
  // ue4.zhiu_SendMsgToUe({ FuncName, Args, time: Date.now() });
  ue4.zhiu_SendMsgToUe({ FuncName, Args });
}

/**  动态分辨率接口 */
export function DynamicResolutionFun({ width = 1100, height = 1424 }) {
  const parameter = {
    FuncName: "DynamicResolution",
    // HashCode: "44444",
    Args: { width, height },
    // time: Date.now(),
  };
  // console.log("DynamicResolution parameter:", parameter);
  toUe4(parameter);
}

/** 风力数据接口 */
export function WindRenderFun(points: Array<any>) {
  const parameter = {
    FuncName: "WindRender",
    // HashCode: "44444",
    Args: { points },
    // time: Date.now(),
  };
  // console.log("WindRender parameter:", parameter);
  toUe4(parameter);
}

/** 柱状污染物接口 */
export function DrawPollutantBarChartFun(points: Array<any>) {
  const parameter = {
    FuncName: "DrawPollutantBarChart",
    // HashCode: "44444",
    Args: { points },
    // time: Date.now(),
  };
  // console.log("DrawPollutantBarChart parameter:", parameter);
  toUe4(parameter);
}

/** 三维热力图接口 */
export function Draw3DHeatmapFun(PartialGroups: Array<any>) {
  const parameter = {
    FuncName: "Draw3DHeatmap",
    // HashCode: "44444",
    Args: { PartialGroups },
    // time: Date.now(),
  };
  // console.log("Draw3DHeatmap parameter:", parameter);
  toUe4(parameter);
}

/**  开关控制接口 */
export function SwitchFun({ wind, zhuzhuang, threeD, jinjingji }: any) {
  const parameter = {
    FuncName: "Switch",
    // HashCode: "44444",
    Args: {
      wind,
      zhuzhuang,
      "3D": threeD,
      jinjingji,
    },
    // time: Date.now(),
  };
  // console.log("Switch parameter:", parameter);
  toUe4(parameter);
}

/** 风力数据接口(json) */
export function WindRenderByJsonFun(filePath: string) {
  const parameter = {
    FuncName: "WindRenderByJson",
    // HashCode: "44444",
    Args: { FilePath: filePath },
    // time: Date.now(),
  };
  // console.log("WindRenderByJson parameter:", parameter);
  toUe4(parameter);
}

/** 柱状污染物接口(json) */
export function DrawPollutantBarChartJsonFun(filePath: string) {
  const parameter = {
    FuncName: "DrawPollutantBarChartJson",
    // HashCode: "44444",
    Args: { FilePath: filePath },
    // time: Date.now(),
  };
  // console.log("DrawPollutantBarChartJson parameter:", parameter);
  toUe4(parameter);
}

/** 三维热力图接口(json) */
export function Draw3DHeatmapJsonFun(filePaths: Array<string>) {
  const parameter = {
    FuncName: "Draw3DHeatmapJson",
    // HashCode: "44444",
    Args: { FilePaths: filePaths },
    // time: Date.now(),
  };
  // console.log("Draw3DHeatmapJson parameter:", parameter);
  toUe4(parameter);
}

/** 设定区域网格的空间范围接口 */
export function SetTheAreaScopeFun(gridInfo: any) {
  const parameter = {
    FuncName: "SetTheAreaScope",
    // HashCode: "44444",
    Args: { GridInfo: gridInfo },
    // time: Date.now(),
  };
  // console.log("SetTheAreaScope parameter:", parameter);
  toUe4(parameter);
}

/** 设置图例范围接口 */
export function SettingupLegendFun(
  title: string,
  maxValue: string,
  minValue: string
) {
  const parameter = {
    FuncName: "SettingupLegend",
    // HashCode: "44444",
    Args: { title: title, MaxRange: maxValue, MinRange: minValue },
    // time: Date.now(),
  };
  // console.log("SettingupLegend parameter:", parameter);
  toUe4(parameter);
}

// 复位
export function resetPawnFun() {
  const parameter = {
    FuncName: "ResetPawn",
    HashCode: "123",
    Args: {
      // State: value
    },
    time: Date.now(),
  };
  toUe4(parameter);
}

// 巡检状态
// "State" : "Pause（暂停）、ReStart（继续）、Stop（停止）、Finished（已完成）",
export function changeTourStateFun(value: any) {
  const parameter = {
    FuncName: "ChangeTourState",
    HashCode: "123",
    Args: {
      State: value,
    },
    time: Date.now(),
  };
  toUe4(parameter);
}

// 巡检过程 开始巡检
export function tourFun(value: any, type: any, text?: any) {
  console.log(value);
  const parameter = {
    FuncName: "Tour",
    HashCode: "123",
    Args: {
      Paths: value,
      IsLoop: type,
      EndPos: text,
    },
    time: Date.now(),
  };
  toUe4(parameter);
}

// 选中状态
export function switchDeviceStateFun(value: any, type: any) {
  const parameter = {
    FuncName: "SwitchDeviceState",
    HashCode: "123",
    Args: {
      Focus_Device: value,
      Alarm_Device: type,
    },
    time: Date.now(),
  };
  toUe4(parameter);
}

// 定位观察
export function isLookAtFun(value: any, type: any) {
  const parameter = {
    FuncName: "IsLookAt",
    HashCode: "123",
    Args: {
      LooatAtObjType: value,
      ID: type,
    },
    time: Date.now(),
  };
  toUe4(parameter);
}

// 切换关卡
export function switchLevelFun(value?: any) {
  const parameter = {
    FuncName: "SwitchLevel",
    HashCode: "123",
    Args: {
      LevelName: value,
    },
    time: Date.now(),
  };
  toUe4(parameter);
}

// 返回首页
// export function GoBackApi (value:any) {
//   const parameter = {
//     FuncName: 'goBackApi',
//     Args: {
//       switchValue: value
//     },
//     time: Date.now()
//   }
//   toUe4(parameter)
// }

// 设备报警
// export function EquipmentApi (value:any) {
//   const parameter = {
//     FuncName: 'EquipmentApi',
//     Args: {
//       alarmValue: value
//     },
//     time: Date.now()
//   }
//   toUe4(parameter)
// }

// 监控报警
// export function MonitorApi (value:any) {
//   const parameter = {
//     FuncName: 'MonitorApi',
//     Args: {
//       monitorValue: value
//     },
//     time: Date.now()
//   }
//   toUe4(parameter)
// }

// 楼层选择
// export function floorApi (value:any, idValue:any) {
//   const parameter = {
//     FuncName: 'floorApi',
//     Args: {
//       floorValue: value,
//       EquipmentValue: idValue
//     },
//     time: Date.now()
//   }
//   toUe4(parameter)
// }
// 环境监测传感器
// export function SensorApi (value:any) {
//   const parameter = {
//     FuncName: 'SensorApi',
//     Args: {
//       sensorValue: value
//     },
//     time: Date.now()
//   }
//   toUe4(parameter)
// }

// 挂载到全局 window 对象
// @ts-ignore
(window as any).ue4Api = {
  DynamicResolutionFun,
  WindRenderFun,
  DrawPollutantBarChartFun,
  Draw3DHeatmapFun,
  SwitchFun,
  WindRenderByJsonFun,
  DrawPollutantBarChartJsonFun,
  Draw3DHeatmapJsonFun,
  SetTheAreaScopeFun,
  SettingupLegendFun
};
