import http from '@/utils/requst'
/* 获取工单类型字典 */
export const getGongDanType = (type:any) => {
  return http.request({
    url: '/api/system/dict/data/type/' + type,
    method: 'GET'
  })
}
/* 派单 */
export const sendWorkOrderApi = (data:any) => {
  return http.request({
    url: '/api/work-order/apiOrder/sendWorkOrder',
    method: 'POST',
    data
  })
}
/* 直接处理 */
export const handleAlertHandle = (data:any) => {
  return http.request({
    url: '/api/alert/api/handleAlert/handle',
    method: 'POST',
    data
  })
}

/* 根据工单id 查询工单详情 */
export const getOrderInfoApi = (orderId:any) => {
  return http.request({
    url: '/api/work-order/apiOrder/getOrderInfo/' + orderId,
    method: 'GET'
  })
}

/* 工单下拉菜单 */
export const getOrderInfoByAlertIdApi = (alertId:any) => {
  return http.request({
    url: '/api/work-order/apiOrder/getOrderListByAlertId/' + alertId,
    method: 'GET'
  })
}

/* 安防监控右下角摄像头列表 */
export const getCameraList = () => {
  return http.request({
    url: '/api/device/camera/list',
    method: 'GET'
  })
}

/* 安防监控右下角摄像头更多列表 */
export const getCameraListAll = (params:any) => {
  return http.request({
    url: '/api/device/camera/listAll',
    method: 'GET',
    params
  })
}

/* 获取单个摄像头的视频流地址 */
export const getCameraDevice = (namespace:any) => {
  return http.request({
    url: '/api/device/camera/device/' + namespace,
    method: 'GET'
  })
}
/* 获取涉笔 */
export const getDeviceList = (params:any) => {
  return http.request({
    url: '/api/device/device/list',
    method: 'GET',
    params
  })
}
