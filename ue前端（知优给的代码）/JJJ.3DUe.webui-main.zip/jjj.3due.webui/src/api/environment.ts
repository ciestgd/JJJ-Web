import http from '@/utils/requst'
/* 获取左侧菜单栏预警模块顶部数据 */
export const getFloorSpaceList = () => {
  return http.request({
    url: '/api/device/api/floorSpaceList',
    method: 'GET'
  })
}

/* 获取左侧菜单栏预警模块数据 */
export const getAlarminfoList = (params:any) => {
  return http.request({
    url: '/api/alert/api/alarminfo/list',
    method: 'GET',
    params
  })
}

/* 根据设备id获取设备 */
export const getDeviceDetail = (id:any) => {
  return http.request({
    url: '/api/device/device/api/' + id,
    method: 'GET'
  })
}

/* 智慧运营楼层列表 */
export const getFloorList = () => {
  return http.request({
    url: '/api/device/api/floorList',
    method: 'GET'
  })
}

/* 智慧运营右下角工单占比 */
export const getBusinessCensus = () => {
  return http.request({
    url: '/api/activiti/api/business/census',
    method: 'GET'
  })
}
