import http from '@/utils/requst'
/* 安防监控设备详情 */
export const getSelectSurveyDeviceByRelationId = (params:any) => {
  return http.request({
    url: '/api/device/api/selectSurveyDeviceByRelationId',
    method: 'GET',
    params
  })
}
/* 安防监控设备列表 */
export const getSelectDeviceBYRelationIds = (params:any) => {
  return http.request({
    url: '/api/device/api/selectDeviceBYRelationIds',
    method: 'GET',
    params
  })
}
/* 获取设备所有id */
export const getSelectDeviceModuleIdByRelationIds = (params:any) => {
  return http.request({
    url: '/api/device/api/selectDeviceModuleIdByRelationIds',
    method: 'GET',
    params
  })
}
/* 查看设备报警 */
export const getSelectAlertByDeviceId = (deviceId:any) => {
  return http.request({
    url: '/api/alert/api/alarminfo/selectAlertByDeviceId/' + deviceId,
    method: 'GET'
  })
}

/* 安防监控右下角摄像头列表 */
export const getCameraList = () => {
  return http.request({
    url: '/api/device/camera/list',
    method: 'GET'
  })
}

/* 安防监控右下角摄像头更多列表 */
export const getCameraListAll = (params:any) => {
  return http.request({
    url: '/api/device/camera/selectCameraForFloor',
    method: 'GET',
    params
  })
}

/* 获取单个摄像头的视频流地址 */
export const getCameraDevice = (namespace:any) => {
  return http.request({
    url: '/api/device/camera/device/' + namespace,
    method: 'GET'
  })
}
/* 获取设备 */
export const getDeviceList = (params:any) => {
  return http.request({
    url: '/api/device/device/list',
    method: 'GET',
    params
  })
}
/* .获取视频回放流 */
export const playbackApi = (data:any) => {
  return http.request({
    url: '/api/device/camera/playback',
    method: 'POST',
    data
  })
}

/* 视频控制 */
export const controlCameraApi = (data:any) => {
  return http.request({
    url: '/api/device/camera/controlCamera',
    method: 'POST',
    data
  })
}

/* .照明回路控制 */
export const openAndCloseApi = (data:any) => {
  return http.request({
    url: '/api/device/lighting/openAndClose',
    method: 'POST',
    data
  })
}
/* .幕墙控制（开关和开度） */
export const curtainControllerApi = (data:any) => {
  return http.request({
    url: '/api/device/curtain/controller',
    method: 'POST',
    data
  })
}

/* 通过模型id获取设备 */
export const getInfoByModuleIdApi = (id:any) => {
  return http.request({
    url: '/api/device/device/getInfoByModuleId/' + id,
    method: 'GET'
  })
}

/* 获取楼层信息 */
export const spaceApi = (id:any) => {
  return http.request({
    url: '/api/device/space/' + id,
    method: 'GET'
  })
}
