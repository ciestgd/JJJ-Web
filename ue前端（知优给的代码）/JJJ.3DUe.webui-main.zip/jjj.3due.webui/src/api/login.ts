import http from '@/utils/requst'
/**
 * @interface loginParams -登录参数
 * @property {string} username -用户名
 * @property {string} password -用户密码
 */

// 封装User类型的接口方法

export const getLogin = (data:any) => {
  return http.request({
    url: '/api/auth/login',
    method: 'POST',
    data
  })
}
// export const getBulletin = (params:any) => {
//   return http.request({
//     url: '/api/index/getBulletin',
//     method: 'GET',
//     params
//   })
// }
export const getCodeImg = () => {
  return http.request({
    url: '/api/code',
    method: 'GET'
  })
}
