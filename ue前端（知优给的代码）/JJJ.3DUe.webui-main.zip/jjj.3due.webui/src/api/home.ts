import http from '@/utils/requst'
/* 获取左侧菜单栏预警模块顶部数据 */
export const getAlarminfoTotal = (params:any) => {
  return http.request({
    url: '/api/alert/api/alarminfo/total',
    method: 'GET',
    params
  })
}

/* 获取左侧菜单栏预警模块数据 */
export const getAlarminfoList = (params:any) => {
  return http.request({
    url: '/api/alert/api/alarminfo/list',
    method: 'GET',
    params
  })
}

/* 根据设备id获取设备 */
export const getDeviceDetail = (id:any) => {
  return http.request({
    url: '/api/device/device/api/' + id,
    method: 'GET'
  })
}

/* 智慧运营楼层列表 */
export const getFloorList = (params:any) => {
  return http.request({
    url: '/api/device/api/floorList',
    method: 'GET',
    params
  })
}

/* 智慧运营右下角工单占比 */
export const getBusinessCensus = () => {
  return http.request({
    url: '/api/work-order/apiOrder/orderStatisticsByMonth',
    method: 'GET'
  })
}

/* 图片上传 */
export const fileUpload = (data:any) => {
  return http.request({
    url: '/api/file/upload',
    method: 'POST',
    data
  })
}
/* 获取设备历史报警记录 */
export const getAlarminfo = (id:any) => {
  return http.request({
    url: '/api/alert/api/alarminfo/' + id,
    method: 'GET'
  })
}
/* 设备运行状态 */
export const getSelectDeviceRunPropertyById = (deviceId:any) => {
  return http.request({
    url: '/api/device/property/selectDeviceRunPropertyById/' + deviceId,
    method: 'GET'
  })
}

/* 获取处理人部门接口 */
export const getDeptTreeselect = () => {
  return http.request({
    url: '/api/system/user/userSelect',
    method: 'GET'
  })
}
/* 车库车位统计 */
export const getFreeSpaceNumApi = () => {
  return http.request({
    url: '/api/device/parkinglotcontrol/getFreeSpaceNum',
    method: 'GET'
  })
}
/* 获取车辆的出入记录接口 */
export const getParkListApi = () => {
  return http.request({
    url: '/api/device/parkinglotcontrol/getParkList',
    method: 'GET'
  })
}
/* 获取设备状态列表 */
export const deviceStatusApi = () => {
  return http.request({
    url: '/api/device/device/deviceStatus',
    method: 'GET'
  })
}
/* 获取摄像头设备状态 */
export const deviceCameraStatusApi = () => {
  return http.request({
    url: '/api/device/device/deviceCameraStatus',
    method: 'GET'
  })
}
