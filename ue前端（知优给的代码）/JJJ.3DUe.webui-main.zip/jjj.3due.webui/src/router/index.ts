import { createRouter, createWebHashHistory } from 'vue-router'
import Layout from '@/views/Layout/index.vue'
import { markRaw } from 'vue'
// 默认路由，不需要权限
export const defaultRouterMap = [
  {
    path: '/',
    redirect: '/console',
    hidden: true,
    meta: {
      name: '首页'
    }
  },

  {
    path: '/login',
    name: 'Login',
    hidden: true,
    meta: {
      name: '登录'
    },
    component: () => import('@/views/login.vue')
  },
  /* 信息管理 */
  {
    path: '/info',
    name: 'Info',
    meta: {
      system: 'infoSystem',
      name: '信息管理',
      icon: 'ChatDotSquare'
    },
    component: markRaw(Layout),
    children: [
      {
        path: '/infoIndex',
        name: 'InfoIndex',
        meta: {
          name: '信息列表'
        },
        component: () => import('@/views/Info/index.vue')
      },
      {
        path: '/infoCategory',
        name: 'InfoCategory',
        meta: {
          name: '信息分类'
        },
        component: () => import('@/views/Info/category.vue')
      }
    ]
  },

  {
    path: '/console',
    name: 'Console',
    redirect: '/index',
    meta: {
      name: '控制台',
      icon: 'Setting'
    },
    component: markRaw(Layout),
    children: [
      {
        path: '/index',
        name: 'Index',
        meta: {
          name: '首页'
        },
        component: () => import('@/views/Console/index.vue')
      }
    ]
  }
]

export const router = createRouter({
  history: createWebHashHistory(), // hash路由，带#的   还有种createWebHistory不带#
  routes: defaultRouterMap
})

// 动态加载的权限路由
export const asyncRouterMap = [
/* 信息管理 */
  {
    path: '/info',
    name: 'Info',
    meta: {
      system: 'infoSystem',
      name: '信息管理',
      icon: 'ChatDotSquare'
    },
    component: markRaw(Layout),
    children: [
      {
        path: '/infoIndex',
        name: 'InfoIndex',
        meta: {
          name: '信息列表'
        },
        component: () => import('@/views/Info/index.vue')
      },
      {
        path: '/infoCategory',
        name: 'InfoCategory',
        meta: {
          name: '信息分类'
        },
        component: () => import('@/views/Info/category.vue')
      }
    ]
  }

]

// router.beforeEach((to, from, next) => {
//     //在跳转路由之前，先清除所有的请求
//     clearPending()
//     // ...
//     next()
//   })
export default router
