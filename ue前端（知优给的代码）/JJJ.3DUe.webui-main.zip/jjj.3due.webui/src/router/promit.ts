/*
 * @Author: 青程钢 765596223@qq.com
 * @Date: 2022-04-15 13:50:34
 * @LastEditors: 青程钢 765596223@qq.com
 * @LastEditTime: 2022-05-13 10:40:55
 * @FilePath: \nanjingBank\src\router\promit.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import router from './index'
import { myStore } from '@/store/index'
import { storage } from '@/storage/storage'
// 路由守卫
const whiteRouter = ['/login']
const obj = {
  type: 'admin' // 不同角色  admin  userSystem  infoSystem
}
router.beforeEach((to, from, next) => {
  const token = storage.get('token')
  const store = myStore()
  // console.log(to.matched.length,"to.matched.length")
  if (token) {
    if (to.path === '/login') { // 当用户自己在地址栏输入login时，即给他清除token
      store.commit('appStore/DELETE_TOKEN')
      next()
    } else {
      // 获取用户角色，动态分配路由权限
      if (store.getters['pemission/roles'].length === 0) {
        store.dispatch('pemission/getRoles', obj).then((res) => {
          store.dispatch('pemission/createRouter', res).then((res) => {
            const addRouters = store.getters['pemission/addRouters']
            const allRouters = store.getters['pemission/allRouters']

            // 添加动态路由
            addRouters.forEach((route:any) => {
              router.addRoute(route)
            })
            // router.addRoute(addRouters);
            // console.log(addRouters)
            // 路由更新
            router.options.routes = allRouters
            next({ ...to, replace: true })
          })
        })
      } else {
        next()
      }
    }
  } else {
    if (whiteRouter.indexOf(to.path) !== -1) { // indexOf,判断数组中是否存在指定的对象，如果不存在，则返回 -1
      next()
    } else {
      next('/login')
    }
  }
})
