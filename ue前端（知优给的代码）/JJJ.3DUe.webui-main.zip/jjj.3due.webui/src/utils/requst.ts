import axios, { AxiosInstance, AxiosRequestConfig } from 'axios'
import { ElMessage } from 'element-plus'
import { storage } from '@/storage/storage'
import router from '@/router'
// 接口类型和方法
interface BaseType {
    baseURL: string;
    getConfigParams(): any;
    interceptors(instance: AxiosInstance, url: string | number | undefined): any;
    request(options: AxiosRequestConfig): any;
}

interface AxiosRequestType {
    baseURL?: string;
    url?: string | undefined;
    data?: any;
    params?: any;
    method?: string;
    headers?: any;
    timeout?: number;
    value?: any
    cancelToken?: any
}
let flag:any = true

// 取消函数
const pending:any = []

const CancelToken = axios.CancelToken

const removePending = (config:any) => {
  for (const p in pending) {
    if (pending[p].u === config.url + JSON.stringify(config.data) + '&' + config.method) {
      pending[p].f()

      pending.splice(p, 1)
    }
  }
}
const redirectLogin = () => {
  // router &&
  // router.push({ path: '/login' })
  storage.set('token', '')
  return false
}

if (storage.get('token') === undefined || storage.get('token') === null) {
  redirectLogin()
}

const url: any = import.meta.env

class AxiosHttpRequest implements BaseType {
  baseURL: string
  timeout: number
  constructor () {
    // 联调
    this.baseURL = process.env.NODE_ENV === 'production' ? url.VITE_APP_BASE_API : '/' // url.VITE_APP_BASE_API,
    // this.baseURL = '/' // 配置本地代理用 "/"
    this.timeout = 5000 * 10
    // console.log(this.baseURL, 'baseURL')
  }

  // 配置参数
  getConfigParams () {
    const config = {
      baseURL: this.baseURL,
      timeout: this.timeout,
      headers: {}
    }
    return config
  }

  // 拦截设置
  interceptors (instance: AxiosInstance, url: string | number | undefined) {
    // 请求拦截
    instance.interceptors.request.use((config: AxiosRequestType) => {
      // 取消重复请求
      removePending(config)
      config.cancelToken = new CancelToken((c) => {
        // 这里的axios标识我是用请求地址&请求方式拼接的字符串，当然你可以选择其他的一些方式

        pending.push({ u: config.url + JSON.stringify(config.data) + '&' + config.method, f: c })
      })
      // 添加全局的loading..
      // 请求头携带token
      if (storage.get('token') && ((storage.get('token') as any).length) > 70) {
        config.headers.Authorization = 'Bearer ' + storage.get('token')
      } else {
        config.headers.Authorization = ''
      }
      // config.headers['Content-Type'] = 'application/json;charset=utf-8'
      // get请求映射params参数
      // console.log(config.params, 'config.params')
      if (config.method === 'get' && config.params) {
        config.headers['Content-Type'] = 'application/json;charset=utf-8'
        let url = config.url + '?'
        for (const propName of Object.keys(config.params)) {
          const value = config.params[propName]
          const part = encodeURIComponent(propName) + '='
          if (value !== null && typeof (value) !== 'undefined') {
            if (typeof value === 'object') {
              for (const key of Object.keys(value)) {
                const params = propName + '[' + key + ']'
                const subPart = encodeURIComponent(params) + '='
                url += subPart + encodeURIComponent(value[key]) + '&'
              }
            } else {
              // get请求中可以传不带属性名的拼接参数 去掉part即可 https://wxpp.qksign66.com/api/index/getBulletin?363&30
              url += part + encodeURIComponent(value) + '&'
            }
          }
        }
        url = url.slice(0, -1)
        config.params = {}
        config.url = url
      } else {
        // config.headers['Content-Type'] = 'application/x-www-form-urlencoded'
      }
      return config
    }, (error: any) => {
      return Promise.reject(error)
    })

    // 响应拦截
    instance.interceptors.response.use((res: any) => {
      // 取消重复请求
      // console.log(process.env.NODE_ENV, '00')
      // 未设置状态码则默认成功状态
      const code = res.data.code || 200
      // 获取错误信息
      let msg = res.data.msg || ''
      if (code === 200) {
        return Promise.resolve(res.data)
      } else {
        switch (code) {
          case 401:
            // msg = '无有效凭证，无法访问系统资源'
            router.replace('/login')
            break
          case 403:
            msg = '当前操作没有权限'
            break
          case 404:
            msg = '访问资源不存在'
            break
          case 500:
            msg = res.data.msg
            break
          default:
            msg = '系统未知错误，请反馈给管理员'
        }
        if (!flag) return
        setTimeout(() => {
          // ElMessage.error(msg)
          // ElMessage.error({
          //   message: msg
          // })
          flag = true
        }, 300)
        flag = false

        return Promise.reject(res.data)
      }
    }, (error: any) => {
      console.log('err' + error)
      let { message } = error
      if (message === 'Network Error') {
        message = '后端接口连接异常'
      } else if (message?.includes('timeout')) {
        message = '系统接口请求超时'
      } else if (message?.includes('Request failed with status code')) {
        message = '系统接口' + message.substr(message.length - 3) + '异常'
      }
      // ElMessage.error({
      //   message,
      //   duration: 5 * 1000
      // })
      return Promise.reject(error)
    })
  }

  /**
     * 外部调用方法
     * @param options axios请求参数
     * @returns 实例
     */
  request (options: AxiosRequestConfig) {
    const instance = axios.create()
    options = Object.assign(this.getConfigParams(), options)
    this.interceptors(instance, options.url)
    return instance(options)
  }
}

// 实例化请求类
const http = new AxiosHttpRequest()

export default http
