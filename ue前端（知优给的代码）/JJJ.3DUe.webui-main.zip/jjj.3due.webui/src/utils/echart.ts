import {
  nextTick
} from 'vue'
import * as echarts from 'echarts'
/* 封装图表文字大小 */
const fontSize = (res: any) => {
  const clientWidth =
    window.innerWidth ||
    document.documentElement.clientWidth ||
    document.body.clientWidth
  if (!clientWidth) return
  const fontSize = clientWidth / 1920
  return res * fontSize
}
/**
 *@function js
 *@param id  图表id
 *@param value 环形图内的值
 *@param text 环形图内文本
 *@param dataText data的文本
 *@param dataValue data的value
 *@description 环形图  有占比
 *@author qing
 *@date 2022-05-25 10:43:58
*/
export const RingDiagram = (id: any, value: any, text: string, dataValue: any, colorLists: any) => {
  const data = dataValue
  let sum = 0
  let avgValue = 0
  const seriesData: any = []
  data.forEach(function (item: any) {
    sum += item
  })
  avgValue = sum / 100 // 间隙数据
  data.forEach(function (item: any, index: any) {
    // 实际展示数据
    seriesData.push({
      name: '测试数据',
      value: item
    })
    seriesData.push(
      // 虚拟数据做间隙使用
      // 实际当前数据是渲染成饼图的一部分，设置了颜色透明，视觉效果是间隙
      {
        name: '',
        value: avgValue, // 间隔数据取总数的百分之一
        itemStyle: {
          normal: {
            label: {
              show: false
            },
            labelLine: {
              show: false
            },
            color: 'rgba(0, 0, 0, 0)',
            borderColor: 'rgba(0, 0, 0, 0)',
            borderWidth: 0
          }
        }
      }
    )
  })
  const colorList = colorLists
  const myChart: any = echarts.init(
    document.getElementById(id) as any
  )
  nextTick(() => {
    myChart.setOption({
      grid: {
        width: '100%',
        height: '100%',
        left: 0,
        top: 0,
        show: false
      },
      legend: [
        {
          show: false
        }
      ],
      title: [
        {
          text: value,
          top: '35%',
          textAlign: 'center',
          left: '47%',
          textStyle: {
            color: '#FFFFFF',
            fontSize: fontSize(18),
            fontFamily: 'SourceHanSansCN'
          }
        },
        {
          text,
          top: '55%',
          textAlign: 'center',
          left: '49%',
          textStyle: {
            color: 'rgba(255, 255, 255, 0.65)',
            fontSize: fontSize(12),
            fontFamily: 'SourceHanSansCN'
          }
        }
      ],
      series: [
        {
          type: 'pie',
          z: 3,
          center: ['50%', '50%'],
          radius: ['70%', '88%'],
          clockwise: true,
          avoidLabelOverlap: true,
          emphasis: {
            scale: true,
            scaleSize: 10
          },
          itemStyle: {
            normal: {
              color: function (params: any) {
                return colorList[params.dataIndex / 2]
              }
            }
          },
          labelLine: {
            show: false
          },
          label: {
            show: false
          },
          data: seriesData
        }
      ]
    })
  })

  window.addEventListener = function () {
    setTimeout(function () {
      myChart.resize()
    }, 500)
  }
}

/**
 *@function js
 *@param id  图表id
 *@param value 环形图内的值
 *@param text 环形图内文本
 *@param dataText data的文本
 *@param dataValue data的value
 *@description 环形图  无占比
 *@author qing
 *@date 2022-05-25 10:43:58
*/
export const RingDiagramNoData = (id: any, value: any, text: string, dataValue: any, colorLists: any, sceneColor: any) => {
  const data = dataValue
  let sum = 0
  let avgValue = 0
  const seriesData: any = []
  data.forEach(function (item: any) {
    sum += item.value
  })
  avgValue = sum / 100 // 间隙数据
  data.forEach(function (item: any, index: any) {
    // 实际展示数据
    seriesData.push({
      name: item.name,
      value: item.value
    })
    seriesData.push(
      // 虚拟数据做间隙使用
      // 实际当前数据是渲染成饼图的一部分，设置了颜色透明，视觉效果是间隙
      {
        name: '',
        value: avgValue, // 间隔数据取总数的百分之一
        itemStyle: {
          normal: {
            label: {
              show: false
            },
            labelLine: {
              show: false
            },
            color: 'rgba(0, 0, 0, 0)',
            borderColor: 'rgba(0, 0, 0, 0)',
            borderWidth: 0
          }
        }
      }
    )
  })
  const colorList = colorLists
  const myChart: any = echarts.init(
    document.getElementById(id) as any
  )
  const legend = {
    icon: 'circle', // 图例形状
    bottom: 'center',
    itemGap: 15,
    itemWidth: 16,
    itemHeight: 16,
    right: '0',
    y: 'center', // 垂直居中
    width: '260', // 这个定义图例的总宽度
    textStyle: {
      color: sceneColor,
      fontSize: fontSize(14),
      width: 118,
      overflow: 'break'

    },
    data
  }
  myChart.setOption({
    grid: {
      width: '100%',
      height: '100%',
      left: 0,
      top: 0,
      show: false
    },
    legend,

    tooltip: {
      trigger: 'item',
      axisPointer: {
        type: 'shadow'
      },
      backgroundColor: 'rgba(231, 244, 255, 1)',
      textStyle: {
        color: '#000000'
      },
      borderWidth: 1
    },
    title: [
      {
        text: value,
        top: '43%',
        textAlign: 'center',
        left: '18%',
        textStyle: {
          color: sceneColor,
          fontSize: fontSize(15),
          fontFamily: 'SourceHanSansCN'
        }
      }

    ],
    series: [
      {
        type: 'pie',
        z: 3,
        center: ['19%', '50%'],
        radius: ['70%', '88%'],
        clockwise: true,
        avoidLabelOverlap: true,
        emphasis: {
          scale: true,
          scaleSize: 10
        },
        itemStyle: {
          normal: {
            color: function (params: any) {
              return colorList[params.dataIndex / 2]
            }
          }
        },
        labelLine: {
          show: false
        },
        label: {
          show: false
        },
        data: seriesData
      }
    ]
  })

  window.addEventListener = function () {
    setTimeout(function () {
      myChart.resize()
    }, 500)
  }
}

/**
 *@function js
 *@param xData  x轴数据
 *@param yData y轴数据
 *@param id 图表id
 *@param yName y轴name
 *@description 折线图
*/
export const lineChart = (xData: any, yData: any, id: any, yName: string) => {
  if (document.getElementById(id)) {
    const myChart: any = echarts.init(
        document.getElementById(id) as any
    )
    myChart.setOption({
      grid: {
        left: '13%',
        right: '5%',
        top: '17%',
        bottom: '12%'
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(0, 0, 0, 0.6)', // 设置背景图片 rgba格式
        borderColor: 'rgba(0, 0, 0, 0.6)', // 设置边框颜色
        axisPointer: {
          type: 'line'
        },
        // 自定义tooltip内容
        formatter: function (param: any) {
          let text = ''
          text += '<div">' +
              '<div style="display:flex;color:white">' +
              '<span>' + '用电量：' + '</span>' +
              '<span>' + param[0].value + '万kWh' + '</span>' + '</div>'
          return text
        }
      },
      xAxis: {
        type: 'category',
        data: xData,

        handle: {
          show: true,
          color: '#7581BD'
        },
        axisLine: {
          lineStyle: {
            color: '#1DA4F6'
          }
        },
        axisLabel: {
          color: '#fff',
          textStyle: {
            fontSize: fontSize(12)
          }
        },
        axisTick: {
          show: false
        }
      },

      yAxis: {
        type: 'value',
        name: yName,
        show: true,
        splitNumber: 5, // 坐标轴分割的段数
        axisLabel: {
          color: '#fff',
          textStyle: {
            fontSize: fontSize(12)
          }
        },
        splitLine: {
          lineStyle: {
            type: 'dashed' // y轴分割线类型
          }
        },
        nameTextStyle: {
          color: '#fff',
          fontSize: fontSize(12)
        },
        axisLine: { // 标轴轴线相关设置。
          symbol: 'arrow', // 坐标轴两边的图表类型，不写默认没有
          lineStyle: {
            type: 'dashed' // 坐标轴的分割线类型还有其他关于轴线的样式自行开发吧
          }
        }

      },
      series: [
        {
          data: yData,
          type: 'line',
          smooth: true,
          itemStyle: {
            normal: {
              color: '#81C5FF', // 改变折线点的颜色
              lineStyle: {
                width: 3,
                color: '#81C5FF' // 改变折线颜色
              }
            }
          }
        }

      ]
    })
    window.onresize = function () {
      setTimeout(function () {
        myChart.resize()
      }, 1000)
    }
  }
}

/**
 *@function js
 *@param id 图表id
 *@param xData x轴数据
 *@param yData y轴数据
 *@param text y轴上方文字
 *@description 柱状图
 *@author qing
 *@date 2022-05-27 10:13:43
*/
export const histogram = (id: any, xData: any, yData: any, text: string) => {
  echarts.init(document.getElementById(id) as any).dispose()
  if (document.getElementById(id)) {
    const myChart: any = echarts.init(document.getElementById(id) as any)
    myChart.clear()
    // 绘制图表
    myChart.setOption({
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        backgroundColor: 'rgba(9, 24, 48, 0.5)',
        borderColor: 'rgba(75, 253, 238, 0.4)',
        textStyle: {
          color: '#CFE3FC'
        },
        borderWidth: 1
      },
      grid: {
        top: '20%',
        right: '3%',
        left: '11%',
        bottom: '10%'
      },
      xAxis: [
        {
          type: 'category',
          data: xData,
          axisLine: {
            lineStyle: {
              color: '#279CFE'
            }
          },
          axisLabel: {
            textStyle: {
              fontSize: fontSize(12),
              fontFamily: 'PingFang SC-Regular',
              color: '#D0DEEE'
            }
          },
          axisTick: {
            show: false
          }

        }
      ],
      yAxis: [
        {
          name: text,
          nameTextStyle: {
            fontSize: fontSize(12),
            fontFamily: 'PingFang SC-Regular',

            color: '#D0DEEE',
            padding: [0, 0, 5, 0]
          },
          axisLabel: {
            formatter: '{value}',
            color: '#e2e9ff',
            textStyle: {
              fontSize: fontSize(12),
              fontFamily: 'PingFang SC-Regular',
              color: '#D0DEEE'
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            show: false,
            lineStyle: {
              color: '#FFFFFF'
            }
          },
          // splitLine: {
          //   lineStyle: {
          //     type: 'dashed',
          //     color: 'rgba(255,255,255,0.12)'
          //   }
          // },
          splitLine: { // 去除网格线
            show: false
          }
        }
      ],
      series: [
        {
          type: 'bar',
          data: yData,
          barWidth: '20%',
          itemStyle: {
            normal: {
              color: '#51A5ED',
              shadowColor: 'rgba(0,160,221,1)',
              shadowBlur: 4
            }
          }
          // label: {     //柱状图上面的数字
          //   normal: {
          //     show: true,
          //     lineHeight: 10,
          //     formatter: '{c}',
          //     position: 'top',
          //     textStyle: {
          //       color: '#FFFFFF',
          //       fontSize: fontSize(12),
          //       fontFamily: 'Panmen'
          //     }
          //   }
          // }
        }
      ]
    })
    window.onresize = function () {
      setTimeout(function () {
        myChart.resize()
      }, 1000)
    }
  }
}

/**
 *@function js
 *@param id 图表id
 *@param xData x轴数据
 *@param yData y轴数据
 *@param text x轴坐标文字
 *@description 横向柱状图
 *@author qing
 *@date 2022-05-27 14:05:57
*/
export const horizontalHistogram = (id: any, xData: any, yData: any, text: string) => {
  const myChart: any = echarts.init(document.getElementById(id) as any)
  myChart.setOption({
    grid: {
      left: '5%',
      right: '5%',
      bottom: '5%',
      top: '10%',
      containLabel: true
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      formatter: function (params: any) {
        return params[0].name + '<br/>' +
          "<span style='display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:rgba(36,207,233,0.9)'></span>" +
          // params[0].seriesName + ' : ' + Number((params[0].value.toFixed(4) / 10000).toFixed(2)).toLocaleString() + ' <br/>'
          params[0].seriesName + ' : ' + params[0].value
      }
    },
    xAxis: {
      name: text,
      nameTextStyle: {
        color: '#D0DEEE',
        fontSize: fontSize(12),
        padding: [120, 20, 10, 20]
      },
      type: 'value',
      axisLine: {
        show: false
      },
      axisLabel: {
        show: true,
        textStyle: {
          color: '#D0DEEE',
          fontSize: fontSize(12)
        }
      },
      splitLine: {
        lineStyle: {
          type: 'dashed',
          color: 'rgba(255,255,255,0.12)'
        }
      }
    },
    yAxis: [{
      type: 'category',
      inverse: true,
      axisLabel: {
        show: true,
        textStyle: {
          color: '#D0DEEE',
          fontSize: fontSize(14)
        }
      },

      splitLine: {
        show: false
      },
      axisTick: {
        show: false
      },
      axisLine: {
        lineStyle: {
          color: '#2199FF'
        }
      },
      data: yData
    }, {
      type: 'category',
      inverse: true,
      axisTick: 'none',
      axisLine: 'none',
      show: true,
      axisLabel: {
        textStyle: {
          color: '#D0DEEE',
          fontSize: fontSize(14),
          fontFamily: 'Panmen'
        },
        formatter: function (value: any) {
          return value + ' %'
        }
      },
      data: xData
    }],
    series: [{
      name: '完成率',
      type: 'bar',
      zlevel: 1,
      itemStyle: {
        normal: {
          show: true,
          color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
            {
              offset: 0,
              color: '#8AC5F8'
            },
            {
              offset: 1,
              color: '#2199FF'
            }
          ]),
          borderWidth: 0
        }
      },
      barWidth: 10,
      data: xData
    }
    ]
  })
  window.onresize = function () {
    setTimeout(function () {
      myChart.resize()
    }, 500)
  }
}
/**
 *@function js
 *@param id 图表id
 *@param xData x轴数据
 *@param yData y轴数据
 *@param text y轴上方文字
 *@description 基础饼图
 *@author qing
 *@date 2022-09-02 10:52:43
*/
export const pieChart = (id: any, value: any, total: any, text: string) => {
  if (document.getElementById(id)) {
    const myChart: any = echarts.init(document.getElementById(id) as any)
    myChart.clear()
    // 绘制图表
    myChart.setOption({

      title: [
        {
          text: ((value / total) * 100).toFixed(0) + '%',
          x: 'center',
          top: '25%',
          textStyle: {
            color: '#ffffff',
            fontSize: fontSize(14),
            fontFamily: 'PingFang SC-Regular'
          }
        },
        {
          text,
          x: 'center',
          top: '50%',
          textStyle: {
            fontSize: fontSize(13),
            color: '#DBDBDB',
            fontFamily: 'PingFang SC-Regular'
          }
        }
      ],
      series: [
        {
          type: 'pie',
          radius: ['80%', '100%'],
          labelLine: {
            normal: {
              show: false
            }
          },
          data: [
            {
              value,
              itemStyle: { color: '#A6E2FE' }
            },
            {
              value: total - value,
              itemStyle: {
                color: '#7D7D7D'
              }
            }
          ]
        }
      ]
    })
    window.onresize = function () {
      setTimeout(function () {
        myChart.resize()
      }, 1000)
    }
  }
}

/**
 *@function js
 *@param id 图表id
 *@param value 运行设备
 *@param total 设备总数
 *@description 进度条
 *@author qing
 *@date 2022-09-02 10:52:43
*/
export const progressBar = (id: any, value: any, total: any) => {
  if (document.getElementById(id)) {
    const myChart: any = echarts.init((document.getElementById(id)) as any)
    // 绘制图表
    myChart.setOption({
      grid: {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0
      },
      xAxis: {
        show: false,
        type: 'value',
        boundaryGap: [0, 0]
      },
      yAxis: [
        {
          type: 'category',
          data: [''],
          axisLine: { show: false },
          axisTick: [
            {
              show: false
            }
          ]
        }
      ],
      series: [
        {
          name: '金额',
          type: 'bar',
          zlevel: 1,
          itemStyle: {
            normal: {
              barBorderRadius: 30,
              color: new echarts.graphic.LinearGradient(1, 0, 0, 1, [
                {
                  offset: 1,
                  color: '#3184C0'
                },
                {
                  offset: 0,
                  color: '#69C0FF'
                }
              ])
            }
          },
          barWidth: 10,
          data: [value]
        },
        {
          name: '背景',
          type: 'bar',
          barWidth: 10,
          barGap: '-100%',
          data: [total],
          itemStyle: {
            normal: {
              color: 'rgba(255,255,255,0.15)',
              borderWidth: 1,
              barBorderRadius: 30
            }
          }
        }
      ]

    })
    window.onresize = function () {
      setTimeout(function () {
        myChart.resize()
      }, 1000)
    }
  }
}
