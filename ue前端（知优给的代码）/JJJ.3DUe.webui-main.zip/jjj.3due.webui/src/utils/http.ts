// http.ts
import axios, { AxiosRequestConfig } from 'axios'
import { IHttpResponse, IObject } from '@/types/interface'
import { getValueByKeys } from './utils'
import { ElMessage } from 'element-plus'
import qs from 'qs'
import router from '@/router'
import { storage } from '@/storage/storage'
const requestPending: IObject = {}

// const url: any = import.meta.env
// console.log(url, 'urlurlurl')
const service = axios.create({
  // 联调
  // baseURL: process.env.NODE_ENV === 'production' ? '/' : '/api',       // url.VITE_APP_BASE_API,
  baseURL: '/', // 配置本地代理用 "/"
  // 是否跨站点访问控制请求
  withCredentials: true,
  timeout: 30000
})

const getRequestIdentify = (config: AxiosRequestConfig) => {
  return encodeURIComponent(config.url + qs.stringify(config.params, { addQueryPrefix: true }))
}

// 请求拦截器
service.interceptors.request.use(
  function (config: any) {
    config.headers['X-Requested-With'] = 'XMLHttpRequest'
    config.headers['Request-Start'] = new Date().getTime()
    // config.headers!["Accept-Language"] = getLocaleLang();
    const token = storage.get('token')
    // config.headers["token"] = token;
    if (token && config.url !== '/auth/oauth/token') {
      config.headers.token = token
    }
    if (config.method?.toUpperCase() === 'GET') {
      // config.params = { ...config.params, _t: new Date().getTime() };
      config.params = { ...config.params }
    }
    /* 给header里面Content-Type加"application/x-www-form-urlencoded" 就会以formData形式传参 */
    if (Object.values(config.headers).includes('application/x-www-form-urlencoded')) {
      config.data = qs.stringify(config.data)
    }
    return config
  },
  function (error) {
    return Promise.reject(error)
  }
)

// 响应拦截器
service.interceptors.response.use(
  (response) => {
    if (response.data.code === 401) {
      // 自定义业务状态码
      redirectLogin()
    } else if (response.data.code === 0) {
      // alert("芭比Q")
      ElMessage.error(response.data.msg)
    }
    return Promise.resolve(response.data)
  },
  (error) => {
    const status = getValueByKeys(error, 'response.status', 500)
    const httpCodeLabel: IObject<string> = {
      400: '请求参数错误',
      401: '未授权，请登录',
      403: '拒绝访问',
      404: `请求地址出错: ${getValueByKeys(error, 'response.config.url', '')}`,
      408: '请求超时',
      500: 'API接口报500错误',
      501: '服务未实现',
      502: '网关错误',
      503: '服务不可用',
      504: '网关超时',
      505: 'HTTP版本不受支持'
    }
    if (error && error.response) {
      console.error('请求错误', error.response.data)
    }
    if (status === 401) {
      redirectLogin()
    }
    return Promise.reject(new Error(httpCodeLabel[status] || '接口错误'))
  }
)

const redirectLogin = () => {
  router.replace('/login')
}

export default (o: AxiosRequestConfig): Promise<IHttpResponse> => {
  const key = getRequestIdentify(o)
  if (requestPending[key]) {
    return Promise.reject(new Error('-999'))
  } else {
    requestPending[key] = 1
  }
  return new Promise((resolve, reject) => {
    service(o)
      .then((res) => {
        delete requestPending[key]
        return resolve(res.data)
      })
      .catch(reject)
  })
}
// export default service
