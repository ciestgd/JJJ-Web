import { defineStore } from 'pinia'
export const useNavDataList = defineStore({
  id: 'navDataList',
  state: () => {
    return {
      navData: [{
        value: 0,
        name: '设备管理',
        openSelect: true
      }, {
        value: 1,
        name: '设备报警',
        openSelect: false
      }, {
        value: 2,
        name: '环境运行',
        openSelect: false
      }, {
        value: 3,
        name: '数字巡逻',
        openSelect: false
      }, {
        value: 4,
        name: '能源管理',
        openSelect: false
      }]
    }
  },
  actions: {
    navDataFun (index:any, openSelect:boolean) {
      this.navData.forEach((item, i) => {
        item.openSelect = false
      })
      this.navData[index].openSelect = openSelect
    }
  }
})
