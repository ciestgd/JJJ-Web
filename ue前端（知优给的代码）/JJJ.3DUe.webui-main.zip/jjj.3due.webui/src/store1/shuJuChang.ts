import { defineStore } from 'pinia'
import { getFloorList } from '@/api/home'
import { getSelectDeviceModuleIdByRelationIds } from '@/api/shebei'
import { useUserStore } from '@/store1/zhuangTaiGuanjLi'
import { switchDeviceStateFun } from '@/api/ue4'

export const shuJuChangStore = defineStore({
  id: 'shuJuChangData',
  state: () => {
    return {
      shuJuChangList: [{
        label: '',
        value: ''
      }], // 获取海底机房数据舱数据
      anZhanShuJuChangList: [{
        label: '',
        value: ''
      }],
      cangSheBei: [] // 岸站数据舱数据
    }
  },
  actions: {
    getshuJuChangList (name:any) {
      const data = {
        buildingId: name
      }
      getFloorList(data).then((res:any) => {
        res.rows.forEach((v: any) => {
          v.value = v.id
          v.label = v.name
        })

        res.rows.unshift({ value: '', label: '全部' })
        this.shuJuChangList = res.rows
      })
    },
    getAnZhanshuJuChangList (name:any) {
      const data = {
        buildingId: name
      }
      getFloorList(data).then((res:any) => {
        res.rows.forEach((v: any) => {
          v.value = v.id
          v.label = v.name
        })

        res.rows.unshift({ value: '', label: '全部' })
        this.anZhanShuJuChangList = res.rows
      })
    },
    // 获取仓设备
    handleCangSheBei (data: any) {
      getSelectDeviceModuleIdByRelationIds(data).then((res:any) => {
        if (res.data.length !== 0) {
          this.cangSheBei = res.data
          useUserStore().modelIdArrayBtn(res.data.join('-'))
          switchDeviceStateFun(res.data.modelIdArray, ' ')
        }
      })
    }
  }

})
