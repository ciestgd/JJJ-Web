import { defineStore } from 'pinia'
export const useUserStore = defineStore({
  id: 'xunjian',
  state: () => {
    return {
      xunJianStatus: false // 设备状态表格
    }
  },
  actions: {
    xunJianStatusFun (name:any) {
      this.xunJianStatus = name
    }
  }
})
