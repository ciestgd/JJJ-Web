import { defineStore } from 'pinia'
import { getSelectDeviceBYRelationIds, getSelectSurveyDeviceByRelationId } from '@/api/shebei'
import {
  ref,
  nextTick
} from 'vue'
import { progressBar } from '@/utils/echart'
export const useSheBeiGuanLiData = defineStore({
  id: 'useSheBeiGuanLiData',
  state: () => {
    return {
      sheBeiGuanLiList: [], // 获取设备管理数据
      idList: [] as any []
    }
  },
  actions: {
    getSheBeiList (name:any) {
    //   const data = {
    //     relationIds: userStore1.relationIds,
    //     deviceFloor: userStore1.no2SelectId
    //   }
      const idValue = ref('')
      getSelectSurveyDeviceByRelationId(name).then((res:any) => {
        // const idList:any = []
        res.data.forEach((v:any, i:any) => {
          v.select = false
          v.sumAlert = 0
          let baojingNum = 0
          v.surveyDeviceVO.forEach((j:any, k:any) => {
            j.select = false
            j.id = 'id' + k + i // 有问题
            idValue.value = j.id
            baojingNum += j.deviceAndOnlineCountVO.sumAlert
            res.data[i].sumAlert = baojingNum
            nextTick(() => {
              progressBar(
                j.id,
                j.deviceAndOnlineCountVO.onlineCount,
                j.deviceAndOnlineCountVO.deviceCount
              )
            })
          })
        })
        // 默认显示第一个大类的ids
        res.data[0].surveyDeviceVO.forEach((v:any) => {
          this.idList.push(v.relationId)
        })
        this.sheBeiGuanLiList = res.data
        this.sheBeiGuanLiList[0].select = true
        // this.sheBeiGuanLiList = res.data
      })
    },
    getSelectDeviceBYRelationIds (data:any) {
      console.log(data)
      getSelectDeviceBYRelationIds(data).then((res: any) => {
        if (res.code === 200) {
          this.sheBeiGuanLiList = res.data
          // if (res.data.length !== 0) {
          //   res.data.forEach((v:any) => {
          //     v.deviceList.forEach((k:any) => {
          //       modelIdArray.push(k.modelId)
          //     })
          //   })
          // }
          // // if (store.state.appStore.floorCode) {
          // // }
          // emit('listLengthFun', shebeiListData.list.length)
          // store.commit('appStore/SET_MODELID', modelIdArray.toString())
          // store.commit('appStore/SET_LOADING', false)
        }
      }).catch((error:any) => {
        console.log(error)
        // store.commit('appStore/SET_LOADING', false)
      })
      }
  }
})
