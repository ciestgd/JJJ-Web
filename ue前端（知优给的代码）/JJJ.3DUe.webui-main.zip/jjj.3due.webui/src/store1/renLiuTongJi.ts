import { defineStore } from 'pinia'

const useRenLiuTongJiStore = defineStore(
  'renLiuTongJi', {
  state: () => {
    return {
      tableData: [
        {
          userName: '小明',
          cardNum: 'A001',
          location: '南门',
          type: '设备故障',
          time: '2022-5-05  15:30:45',
          state: '1'
        },
        {
          userName: '小明',
          cardNum: 'A001',
          location: '南门',
          type: '设备故障',
          time: '2022-5-05  15:30:45',
          state: '0'
        },
        {
          userName: '小明',
          cardNum: 'A001',
          location: '南门',
          type: '设备故障',
          time: '2022-5-05  15:30:45',
          state: '1'
        },
        {
          userName: '小明',
          cardNum: 'A001',
          location: '南门',
          type: '设备故障',
          time: '2022-5-05  15:30:45',
          state: '1'
        },
        {
          userName: '小明',
          cardNum: 'A001',
          location: '南门',
          type: '设备故障',
          time: '2022-5-05  15:30:45',
          state: '0'
        },
        {
          userName: '小明',
          cardNum: 'A001',
          location: '南门',
          type: '设备故障',
          time: '2022-5-05  15:30:45',
          state: '1'
        }
      ],
      total: 2,
      formBoxShow: false,
      selectRow: {},
      ruleForm: {type:"可疑人员",time:"2022-05-21 08:30"},
      role: [{
        value: 1, label: "dd"
      }]
    }
  },
  actions: {

    setFormBoxShow(v: boolean) {
      this.formBoxShow = v
    },

    setSelectRow(value: any) {
      this.selectRow = value
    }

  }
}
)

export default useRenLiuTongJiStore
