import { tourFun } from '@/api/ue4'
import { defineStore } from 'pinia'
import * as _ from 'lodash'
import { useUserStore } from './zhuangTaiGuanjLi'
import { useNavDataList } from '@/store1/navList'

// const zhuangTaiGuanjLiStore = useUserStore()

export const useXunjianDataStore = defineStore(
  'xunjianData', {
  state: () => {
    return {
      list: [
        {
          order: 0,
          id: '01',
          name: '分电站',
          value: '3',
          lineList: [{
            value: 'fendian1',
            label: '线路1',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'fendiancang',
            label: '线路2',
            xunLuoDianList: [] as any[]
          }
          ],
          currentLine: 'fendian1',
          currentLineIndex: 0
        },
        {
          order: 1,
          id: '02',
          name: '2号数据舱',
          value: '1',
          lineList: [{
            value: 'peidian2',
            label: '线路1',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'peidiancangxia',
            label: '线路2',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'ITcang2shang',
            label: '线路3',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'ITcang2xia',
            label: '线路4',
            xunLuoDianList: [] as any[]
          }
          ],
          currentLine: 'peidian2',
          currentLineIndex: 0
        },
        {
          order: 2,
          id: '03',
          name: '1号数据舱',
          value: '0',
          lineList: [{
            value: 'peidian1',
            label: '线路1',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'peidiancangxia1',
            label: '线路2',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'ITcang1shang',
            label: '线路3',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'ITcang1xia',
            label: '线路4',
            xunLuoDianList: [] as any[]
          }
          ],
          currentLine: 'peidian1',
          currentLineIndex: 0
        }, {
          order: 3,
          id: '04',
          name: '3号数据舱',
          value: '2',
          lineList: [{
            value: 'peidian3',
            label: '线路1',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'peidiancangxia3',
            label: '线路2',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'ITcang3shang',
            label: '线路3',
            xunLuoDianList: [] as any[]
          },
          {
            value: 'ITcang3xia',
            label: '线路4',
            xunLuoDianList: [] as any[]
          },
          ],
          currentLine: 'peidian3',
          currentLineIndex: 0
        }
      ],
      TourPathList: [
        {
          "Name": "quanbu1",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "quanbu2",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "fendiancang",
          "SplineIndex": [ 0, 1, 2 ]
         },
         {
          "Name": "peidiancangxia",
          "SplineIndex": [ 0, 1, 2 ]
         },
         {
          "Name": "quanbu3",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "ITcang2xia",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "peidian1",
          "SplineIndex": [ 0, 1, 2, 3 ]
         },
         {
          "Name": "peidian2",
          "SplineIndex": [ 0, 1, 2, 3 ]
         },
         {
          "Name": "peidian3",
          "SplineIndex": [ 0, 1, 2, 3 ]
         },
         {
          "Name": "fendian1",
          "SplineIndex": [ 0, 1, 2, 3 ]
         },
         {
          "Name": "ITcang2shang",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "ITcang3xia",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "ITcang3shang",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "ITcang1xia",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "ITcang1shang",
          "SplineIndex": [ 0, 1 ]
         },
         {
          "Name": "peidiancangxia1",
          "SplineIndex": [ 0, 1, 2 ]
         },
         {
          "Name": "peidiancangxia3",
          "SplineIndex": [ 0, 1, 2 ]
         }
      ],
      arrivalPosition: {},
      shuZiXunluoList: [] as any[],
      leftXunLuoSelected: {} as any,
      sheBeiGuanLiSelectedCang: {}
    }
  },
  getters: {
    orderList(): any {
      return this.list.sort((item1, item2) => item1.order - item2.order)
    },
    quanbuOrderList(): any {
      return this.list.sort((item1, item2) => item1.order - item2.order).filter((item) => item.name === '分电站' || item.name === '2号数据舱')
    }
  },
  actions: {
    setArrivalPosition(value: any) {
      this.arrivalPosition = value
      let belongCang = ''

      if (useUserStore().no2SelectVal !== '全部') {
        const currentLine = this.orderList.filter((item: any) => item.name === useUserStore().no2SelectVal)[0]
          .lineList.filter((item2: any) => item2.value === value.Paths)[0]
        // console.log(currentLine, value, this.orderList.filter((item: any) => item.name === useUserStore().no2SelectVal)[0])
        if (currentLine?.label) {
          this.leftXunLuoSelected = {
            lineLabel: currentLine.label
          }
        }
      }

      switch (value.Paths) {
        case 'peidian1':
        case 'peidiancangxia1':
        // case 'peidiancangshang1':
        case 'ITcang1xia':
        case 'ITcang1shang':
          belongCang = '1号数据舱'
          break
        case 'peidian2':
        case 'peidiancangxia':
        // case 'peidiancangshang':
        case 'ITcang2xia':
        case 'ITcang2shang':
          belongCang = '2号数据舱'
          break
        case 'peidian3':
        case 'peidiancangxia3':
        // case 'peidiancangshang3':
        case 'ITcang3xia':
        case 'ITcang3shang':
          belongCang = '3号数据舱'
          break
        case 'fendian1':
        case 'fendiancang':
          belongCang = '分电站'
          break
        default:
          break
      }
      if (belongCang) {
        this.list.forEach((item: any, index1) => {
          item?.lineList.forEach((item2: any, index2: number) => {
            item2.xunLuoDianList.forEach((item3: any, index3: number) => {
              if (belongCang === item.name && item.currentLine !== value.Paths) {
                item.currentLine = value.Paths
              }
              if (belongCang === item.name && item2.value === value.Paths) {
                item.currentLineIndex = index2
              }

              if (belongCang === item.name && index3 === Number(value.TourIndex)
              ) {
                return (this.list[index1].lineList[item.currentLineIndex].xunLuoDianList[index3].openSelect = true)
              } else {
                return (item3.openSelect = false)
              }
            })
          })
        })
      }
    },

    setListOrder(id: string, type: 'down' | 'up') {
      const index = this.list.findIndex((item) => item.id === id)
      const currenOrder = this.list[index].order

      if (type === 'down' && this.list[index + 1]) {
        this.list[index].order = this.list[index + 1]?.order
        this.list[index + 1].order = currenOrder
        const otherPath = _.flatten(this.orderList.map((item: any) => item.lineList.map((item1: any) => item1.value)))
        const paths = (`quanbu1-quanbu2-quanbu3-${otherPath.join('-')}`)
        tourFun(paths, true)
      }
      if (type === 'up' && this.list[index - 1]) {
        this.list[index].order = this.list[index - 1]?.order
        this.list[index - 1].order = currenOrder
        const otherPath = _.flatten(this.orderList.map((item: any) => item.lineList.map((item1: any) => item1.value)))
        const paths = (`quanbu1-quanbu2-quanbu3-${otherPath.join('-')}`)
        tourFun(paths, true)
      }
    },
    inintList() {
      this.list.forEach((item) => {
        item.currentLineIndex = 0
        item.lineList.forEach((line) => {
          this.TourPathList.forEach(pathItem => {
            if (line.value === pathItem.Name) {
              line.xunLuoDianList = pathItem.SplineIndex.map((spline, index) => ({
                value: index,
                label: `巡逻点${index}`,
                openSelect: false
              }))
            }
          })
        })
      })
    },
    setShuZiXunluoList(id?: string) {
      this.inintList()
      // console.log(this.orderList)
      switch (useUserStore().no2SelectVal) {
        case '全部':
          const data = this.list.map((item) => {
            return item.lineList.map((item2) => {
              return {
                pathName: `${item.name}${item2.label}`,
                loction: item2.xunLuoDianList.map((item3) => item3.label).join('、'),
                cangId: item.id,
                lineValue: item2.value,
                lineLabel: item2.label
              }
            })
          })

          this.shuZiXunluoList = _.flatten(data)
          return
        case '1号数据舱':
          const data1 = this.list.filter((item) => item.id === '03')[0]
            .lineList.map((item2) => {
              return {
                pathName: `1号数据舱${item2.label}`,
                loction: item2.xunLuoDianList.map((item3) => item3.label).join('、'),
                cangId: '03',
                lineValue: item2.value,
                lineLabel: item2.label
              }
            })
          this.shuZiXunluoList = data1
          return
        case '2号数据舱':
          const data2 = this.list.filter((item) => item.id === '02')[0]
            .lineList.map((item2) => {
              return {
                pathName: `2号数据舱${item2.label}`,
                loction: item2.xunLuoDianList.map((item3) => item3.label).join('、'),
                cangId: '02',
                lineValue: item2.value,
                lineLabel: item2.label
              }
            })
          this.shuZiXunluoList = data2
          return
        case '3号数据舱':
          const data3 = this.list.filter((item) => item.id === '04')[0]
            .lineList.map((item2) => {
              return {
                pathName: `3号数据舱${item2.label}`,
                loction: item2.xunLuoDianList.map((item3) => item3.label).join('、'),
                cangId: '04',
                lineValue: item2.value,
                lineLabel: item2.label
              }
            })
          this.shuZiXunluoList = data3
          return
        case '分电站':
          const data4 = this.list.filter((item) => item.id === '01')[0]
            .lineList.map((item2) => {
              return {
                pathName: `分电站${item2.label}`,
                loction: item2.xunLuoDianList.map((item3) => item3.label).join('、'),
                cangId: '01',
                lineValue: item2.value,
                lineLabel: item2.label
              }
            })
          this.shuZiXunluoList = data4

        default:
      }
    },
    setLeftXunLuoSelected(value: {
      cangId: string
      lineValue: string
      lineLabel: string
      loction: string
      pathName: string
      select: boolean
    }) {
      this.leftXunLuoSelected = value
      const paths = this.orderList.filter((item: { id: any; }) => item.id === value.cangId)[0]?.lineList.filter((item2: { value: string; }) => item2.value === value.lineValue)[0]
      if (useNavDataList().navData[3].openSelect) {
        tourFun(paths.value, false)
      }
    },
    setSheBeiGuanLiSelectedCang(value: any) {
      this.sheBeiGuanLiSelectedCang = value
      useUserStore().no2SelectValBtn(value.name)
    },
    handleReset() {
      this.list.forEach((item) => {
        switch (item.name) {
          case '分电站':
            item.currentLine = 'fendian1'
            item.currentLineIndex = 0

            break
          case '2号数据舱':
            item.currentLine = 'peidian2'
            item.currentLineIndex = 0
            break
          default:
            break
        }
      })
    }
  }
}
)
