// import { type } from 'os'
import { defineStore } from 'pinia'
import { isLookAtFun, switchDeviceStateFun } from '@/api/ue4'
import { getDeviceDetail } from '@/api/home'
export const useUserStore = defineStore({
  id: 'user', // id必填，且唯一
  state: () => {
    return {
      maskFlag: false, // 设备台账信息
      chakandrawer: false, // 历史数据表格
      sheBeiStatusReset: [false, false, false],
      isSmallFlag: false, // 是否选中小类
      smallFlag: false, // 小类控制
      bigFlag: false, // 大类控制
      sheBeiWidth: '0', // 设备大类 设备小类宽度
      xunJianStatus: false, // 巡检状态/控制显/隐
      huanJingYunXing: false, // 环境运行状态控制
      nengYuanGuanLi: false, // 能源状态控制
      firstNavBox: false, // 菜单状态控制
      shouHuiBox: false, // 收回巡检
      navName: '海底机房', // 菜单导航
      leftWidth: '25.5208rem ', // 设备管理宽度
      leftSheBeiWidth: '11.5104rem', // 设备类宽度
      baoJingWidth: '8.1771rem', // 报警列表宽度
      haiDiJiFangShouYe: false, // 海底机房首页
      sheBeiOutBox: false, // 海底机房设备最外层
      fanHui: false, // 返回
      fanHuiShouYe: false, // 返回首页
      no2SelectVal: '全部', // 选中巡检路线
      no2SelectId: '', // 选中数据舱ID
      no2NavBox: false, // 选中数据舱控制
      weibao: false, // 录入维保信息
      liShiWeiBao: false, // 历史维保信息
      zongheanfangRight: false, // 综合安防右边部分
      anfangfanHui: false, // 安防返回
      isWeiBao: false, // 维保信息
      xunjianfanhui: false, // 巡检返回按钮
      isSheBeiLei: false, // 点击设备类进入
      anZhanFanhuihouYe: false, // 岸站返回首页按钮
      xunJianZhuangTai: '自由巡检', // 巡检状态
      huanJingYunYoubianZhuangTai: false, // 巡检状态
      homePageShow: true,
      modelIdArray: [], // 当前选中模型id集合
      relationIds: '', // 设备管理id集合
      shuZiXunJian: false, // 选中数字巡检状态
      moduleId: '', // 报警ID
      cangShiXuanZhong: '', // 右边设备状态 舱室选中下拉
      securitySmallFlag: false, // 点击报警数据
      accountData: ''
    }
  },
  actions: {
    updateName (name:any) {
      this.maskFlag = name
    },
    // 点击历史信息
    upChakandrawer (to:any) {
      this.chakandrawer = to
    },
    // 点击设备列表
    upSheBeiList (text1:any, text2:any, text3:any) {
      this.sheBeiStatusReset[0] = text1
      this.sheBeiStatusReset[1] = text2
      this.sheBeiStatusReset[2] = text3
    },
    // 是否点击设备小类
    upSmallFlag (type:any) {
      this.isSmallFlag = type
    },
    // 设备小类控制
    upSmallBoxFlag (type:any) {
      this.smallFlag = type
    },
    // 设备大类控制
    upBigFlag (type:any) {
      this.bigFlag = type
    },
    // 巡检状态控制
    xunJianStatusFun (name:any) {
      this.xunJianStatus = name
    },
    // 环境运行控制
    huanJingYunXingRight (name:any) {
      this.huanJingYunXing = name
    },
    // 能源管理控制
    nengYuanGuanLiRight (name:any) {
      this.nengYuanGuanLi = name
    },
    isFirstNavBox (name?:any) {
      this.firstNavBox = name || !this.firstNavBox
    },
    isShouHuiBox (name?:any) {
      this.shouHuiBox = name || !this.shouHuiBox
    },
    navNameList (name:any) {
      this.navName = name
    },
    leftWidthNum (name:any) {
      this.leftWidth = name
    },
    leftSheBeiWidthNum (name:any) {
      this.leftSheBeiWidth = name
    },
    baoJingWidthNum (name:any) {
      this.baoJingWidth = name
    },
    haiDiJiFangShouYeBtn (name:any) {
      this.haiDiJiFangShouYe = name
    },
    sheBeiOut (name:any) {
      this.sheBeiOutBox = name
    },
    fanHuiBtn (name:any) {
      this.fanHui = name
    },
    fanHuiShouYeBtn (name:any) {
      this.fanHuiShouYe = name
    },
    no2SelectValBtn (name:any) {
      this.no2SelectVal = name
    },
    no2SelectIdBtn (name:any) {
      this.no2SelectId = name
    },
    no2NavBoxBtn (name?:any) {
      this.no2NavBox = name || !this.no2NavBox
    },
    WeiBaoBtn (name:any) {
      this.weibao = name
    },
    liShiWeiBaobtn (name:any) {
      this.liShiWeiBao = name
    },
    zongheanfangRightBtn (name:any) {
      this.zongheanfangRight = name
    },
    anfangfanHuibtn (name:any) {
      this.anfangfanHui = name
    },
    isWeiBaoBtn (name:any) {
      this.isWeiBao = name
    },
    xunjianfanhuiBtn (name:any) {
      this.xunjianfanhui = name
    },
    isSheBeiLeiBtn (name:any) {
      this.isSheBeiLei = name
    },
    anZhanFanhuihouYeBtn (name:any) {
      this.anZhanFanhuihouYe = name
    },
    xunJianZhuangTaiBtn (name:any) {
      this.xunJianZhuangTai = name
    },
    huanJingYunYoubianZhuangTaiShouhuiBox () {
      this.huanJingYunYoubianZhuangTai = !this.huanJingYunYoubianZhuangTai
    },
    homePageShowBtn () {
      this.homePageShow = !this.homePageShow
    },
    modelIdArrayBtn (name:any) {
      this.modelIdArray = name
    },
    relationIdsBtn (name:any) {
      this.relationIds = name
    },
    shuZiXunJianBtn (name:any) {
      this.shuZiXunJian = name
    },
    moduleIdBtn (name:any) {
      this.moduleId = name
    },
    cangShiXuanZhongBtn (name:any) {
      this.cangShiXuanZhong = name
    },
    securitySmallFlagBtn1 (name:any) {
      console.log(name)
      this.securitySmallFlag = name
    },
    getDeviceDetailFun (id: any) {
      getDeviceDetail(id).then((res: any) => {
        this.accountData = res.data
        switchDeviceStateFun(' ', res.data.moduleId)
        isLookAtFun('Device', res.data.moduleId)
      })
    }
  }
})
