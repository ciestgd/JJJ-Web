import { defineStore } from 'pinia'

export const useHuanJingYunXingStore = defineStore(
  'huanJingYunXing', {
    state: () => {
      return {
        huanJingYunXingOptions: [
          {
            id: '1',
            name: '舱内温湿度',
            card: [{
              name: 'IT舱舱内温湿度',
              warnNmu: 0,
              list: [{
                maxName: '舱内最高温度',
                minName: '舱内最低温度',
                max: 25,
                min: 20,
                switch: true,
                unity: '°C'
              },
              {
                maxName: '舱内最高湿度',
                minName: '舱内最低湿度',
                max: 25,
                min: 20,
                switch: true,
                unity: '%'
              }
              ]
            }, {
              name: '配电舱舱内温湿度',
              warnNmu: 0,
              list: [{
                maxName: '舱内最高温度',
                minName: '舱内最低温度',
                max: 25,
                min: 20,
                switch: true,
                unity: '°C'
              },
              {
                maxName: '舱内最高湿度',
                minName: '舱内最低湿度',
                max: 25,
                min: 20,
                switch: true,
                unity: '%'
              }
              ]
            }]

          },
          {
            id: '2',
            name: '舱外环境水温',
            card: [{
              name: 'IT舱舱外环境水温',
              warnNmu: 0,
              list: [
                {
                  maxName: '舱外最高温度',
                  minName: '舱外最低温度',
                  max: 25,
                  min: 20,
                  switch: true,
                  unity: '°C'
                }
              ]
            }, {
              name: '配电舱舱外环境水温',
              warnNmu: 0,
              list: [
                {
                  maxName: '舱外最高温度',
                  minName: '舱外最低温度',
                  max: 25,
                  min: 20,
                  switch: true,
                  unity: '°C'
                }
              ]
            }]
          },
          {
            id: '3',
            name: '舱内空气质量监测',
            card: [{
              name: 'IT舱舱内空气质量监测',
              warnNmu: 0,
              list: [
                {
                  maxName: '舱内最高温度',
                  minName: '舱内最低温度',
                  max: 25,
                  min: 20,
                  switch: null,
                  unity: '°C'
                }
              ]
            }, {
              name: '配电舱舱内空气质量监测',
              warnNmu: 0,
              list: [{
                maxName: '舱内最高温度',
                minName: '舱内最低温度',
                max: 25,
                min: 20,
                switch: null,
                unity: '°C'
              }]
            }]
          },
          {
            id: '4',
            name: '舱内气压',
            card: [{
              name: 'IT舱舱内气压',
              warnNmu: 0,
              list: [{
                maxName: '舱内最高温度',
                minName: '舱内最低温度',
                max: 120,
                min: 110,
                switch: null,
                unity: 'Kpa'
              }]
            }, {
              name: '配电舱舱内气压',
              warnNmu: 0,
              list: [{
                maxName: '舱内最高温度',
                minName: '舱内最低温度',
                max: 120,
                min: 90,
                switch: null,
                unity: 'Kpa'
              }]
            }]
          }
        ],
        huanJingYunXingRight: {
          title: '运行环境监控',
          subTitle: 'SMART BIJIANG',
          data: [{
            card: [{
              name: '天气/海洋气候预报',
              list: [{
                maxName: '未来平均温度',
                minName: '未来平均湿度',
                max: 25,
                min: 20,
                maxUnity: '°C',
                minUnity: '%'
              },
              {
                maxName: '未来季风',
                minName: '未来潮汐',
                max: '夏季风',
                min: '满潮',
                unity: null
              },
              {
                maxName: '未来洋流',
                minName: null,
                max: '暖流',
                min: null,
                unity: null
              }
              ]
            }, {
              name: '地面气候/天气',
              list: [{
                maxName: '地面温度',
                minName: '地面湿度',
                max: 12,
                min: 20,
                maxUnity: '°C',
                minUnity: '%'
              }
              ]
            }]

          }]
        },
        selectOption: '1'
      }
    },
    actions: {

    }
  }
)
