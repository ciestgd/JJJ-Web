/*eslint-disable*/
declare function initNECaptcha(...args: any[]): any;
// declare function JSPlugin(...args: any[]): any;
declare function Autoplay(...args: any[]): any;
declare class ue4Init {
  constructor(url: any, name?:any, userName?:any);
};
declare class JSPlugin {
  constructor(szId: any, szBasePath?:any, iMaxSplit?:any, iCurrentSplit?:any, openDebug?:any);
};
   
declare module 'h5player.min' {
      const content: any
      export = content
  }
  declare module '*.js'