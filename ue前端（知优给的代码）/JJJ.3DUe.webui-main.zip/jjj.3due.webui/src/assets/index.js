/*
 * @Author: 青程钢 765596223@qq.com
 * @Date: 2022-04-15 13:50:34
 * @LastEditors: 青程钢 765596223@qq.com
 * @LastEditTime: 2022-05-13 10:41:44
 * @FilePath: \nanjingBank\src\assets\index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import ue4 from './ue4/app'
import axios from 'axios'

// 避免重复初始化导致多次 play() / 加载
let isPixelStreamInitializing = false
let isPixelStreamStarted = false

/**
 * @author: 王琛
 * @description: UE4项目初始化
 * @Date: 2021-11-15 09:37:53
 * @param {*}
 * @return {*}
 */
export class ue4Init {
  ue4 = ue4
  message = (data) => {
    console.log('%c阿青-141259', 'color:#fff;background:#ee6f57;padding:3px;border-radius:2px', data)
  }

  constructor({ url, name, userName }) {
    // 流地址
    // 获取项目名称
    const projectName = name || 'not'
    // 判断如果没有给到ue4地址则不会显示流信息;
    if (!url) return
    console.warn(' >LJason< 警告： ue4项目名称', import.meta.env.VITE_ISHTTSP)
    // 防止还在初始化/播放时被重复调用，导致 AbortError
    if (isPixelStreamInitializing) {
      console.warn(' >LJason< UE4 像素流仍在初始化，本次初始化忽略')
      return this
    }

    // 先关掉UE4场景再开开;
    try {
      ue4.zhiu_ClosePixelStream()
    } catch (e) {
      console.warn(' >LJason< 关闭旧像素流时异常（可忽略）', e)
    }

    isPixelStreamInitializing = true
    let cirrusServerUrl = import.meta.env.VITE_ISHTTSP == 'TRUE' ? `wss://${url}` : `ws://${url}`
    console.warn(' >LJason< 警告：ue4地址', cirrusServerUrl)
    // 初始化推流
    try {
      ue4.zhiu_InitializePixelStream(cirrusServerUrl, 'player',
        {
          userName: userName || 'unknown',
          userAuthorityLevel: 99,
          userId: (userName || 'unknown') + 'id'
        })
    } catch (e) {
      isPixelStreamInitializing = false
      console.error(' >LJason< 初始化像素流异常', e)
    }
    // 接收ue信息的回调
    ue4.zhiu_AddListener('app_ueMessage', (msg) => {
      const obj = JSON.parse(msg)
      this.message(obj)
    })
    // socket连接成功
    ue4.zhiu_AddListener('app_wsOpen', event => {
      console.warn(' >LJason< 警告： wsOpen  ', event)
    })
    // 连接结束
    ue4.zhiu_AddListener('app_wsClose', event => {
      console.warn(' >LJason< 警告： wsClose  ', event)
      isPixelStreamInitializing = false
      isPixelStreamStarted = false
    })
    // 连接错误
    ue4.zhiu_AddListener('app_wsError', event => {
      console.warn(' >LJason< 警告： wsError  ', event)
      isPixelStreamInitializing = false
      isPixelStreamStarted = false
    })
    // 自踢回调
    ue4.zhiu_AddListener('app_kickSelfTimeout', () => { })
    // UE连接成功（视频真正开始播放）
    ue4.zhiu_AddListener('app_videoPlayed', () => {
      isPixelStreamInitializing = false
      isPixelStreamStarted = true
      console.log('%c阿青-095718', 'color:#fff;background:#ee6f57;padding:3px;border-radius:2px', '我连接UE4成功了')
    })
    return this
  }
}
