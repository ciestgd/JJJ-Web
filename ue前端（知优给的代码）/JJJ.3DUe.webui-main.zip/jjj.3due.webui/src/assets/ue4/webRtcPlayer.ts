/*eslint-disable*/
// Copyright Epic Games, Inc. All Rights Reserved.
// universal module definition - read https://www.davidbcalhoun.com/2014/what-is-amd-commonjs-and-umd/
import adapter from 'webrtc-adapter'
export function webRtcPlayer (parOptions:any) {
  parOptions = parOptions || {}

  const self = this

  //* *********************
  // Config setup
  //* *********************;
  this.cfg = parOptions.peerConnectionOptions || {}
  this.cfg.sdpSemantics = 'unified-plan'
  this.pcClient = null
  this.dcClient = null
  this.tnClient = null

  this.sdpConstraints = {
    offerToReceiveAudio: 1,
    offerToReceiveVideo: 1
  }

  // See https://www.w3.org/TR/webrtc/#dom-rtcdatachannelinit for values
  this.dataChannelOptions = { ordered: true }

  //* *********************
  // Functions
  //* *********************

  // 创建视频元素并将其作为参数公开
  const createWebRtcVideo = function () {
    const video = document.createElement('video')
    video.id = 'streamingVideo'
    video.playsInline = true
    video.muted = true
    video.style.width = '100%'
    video.style.height = '100%'

    video.addEventListener('loadedmetadata', function (e) {
      video.play(); console.log(' >LJason< 日志：这样就能自动播放了？？？？？')
      if (self.onVideoInitialised) {
        self.onVideoInitialised()
      }
    }, true)
    return video
  }

  this.video = createWebRtcVideo()

  const onsignalingstatechange = function (state) {
    _zhiuLogger.SystemLog('signaling state change: ' + state)
  }

  const oniceconnectionstatechange = function (state) {
    _zhiuLogger.SystemLog('ice connection state change: ' + state)
  }

  const onicegatheringstatechange = function (state) {
    _zhiuLogger.SystemLog('ice gathering state change: ' + state)
  }

  const handleOnTrack = function (e) {
    _zhiuLogger.SystemLog('handleOnTrack' + JSON.stringify(e.streams))
    if (self.video.srcObject !== e.streams[0]) {
      _zhiuLogger.SystemLog('setting video stream from ontrack')
      self.video.srcObject = e.streams[0]
    }
  }
  // 数据通讯通道
  const setupDataChannel = function (pc, label, options) {
    try {
      const datachannel = pc.createDataChannel(label, options)
      _zhiuLogger.SystemLog(`Created datachannel (${label})`)

      datachannel.onopen = function (e) {
        _zhiuLogger.SystemLog(`data channel (${label}) connect`)
        if (self.onDataChannelConnected) {
          self.onDataChannelConnected()
        }
      }

      datachannel.onclose = function (e) {
        _zhiuLogger.SystemLog(`data channel (${label}) closed`)
      }

      datachannel.onmessage = function (e) {
        // _zhiuLogger.SystemLog(`Got message (${label}) ${e.data}` );
        if (self.onDataChannelMessage) { self.onDataChannelMessage(e.data) }
      }

      return datachannel
    } catch (e) {
      _zhiuLogger.SystemLog('No data channel' + JSON.stringify(e))
      return null
    }
  }

  const onicecandidate = function (e) {
    _zhiuLogger.SystemLog('ICE candidate' + JSON.stringify(e))
    if (e.candidate && e.candidate.candidate) {
      self.onWebRtcCandidate(e.candidate)
    }
  }

  const handleCreateOffer = function (pc) {
    pc.createOffer(self.sdpConstraints).then(function (offer) {
      pc.setLocalDescription(offer)
      if (self.onWebRtcOffer) {
        // (andriy): increase start bitrate from 300 kbps to 20 mbps and max bitrate from 2.5 mbps to 100 mbps
        // (100 mbps means we don't restrict encoder at all)
        // after we `setLocalDescription` because other browsers are not c happy to see google-specific config
        offer.sdp = offer.sdp.replace(/(a=fmtp:\d+ .*level-asymmetry-allowed=.*)\r\n/gm, '$1;x-google-start-bitrate=10000;x-google-max-bitrate=20000\r\n')
        self.onWebRtcOffer(offer)
      }
    },
    function () { _zhiuLogger.SystemWarning("Couldn't create offer") })
  }

  const setupPeerConnection = function (pc) {
    if (pc.SetBitrate) { _zhiuLogger.SystemLog("Hurray! there's RTCPeerConnection.SetBitrate function") }

    // Setup peerConnection events
    pc.onsignalingstatechange = onsignalingstatechange
    pc.oniceconnectionstatechange = oniceconnectionstatechange
    pc.onicegatheringstatechange = onicegatheringstatechange

    pc.ontrack = handleOnTrack
    pc.onicecandidate = onicecandidate
  }

  const generateAggregatedStatsFunction = function () {
    if (!self.aggregatedStats) { self.aggregatedStats = {} }

    return function (stats) {
      // _zhiuLogger.SystemLog('Printing Stats');

      const newStat = {}
      // _zhiuLogger.SystemLog('----------------------------- Stats start -----------------------------');
      stats.forEach(stat => {
        // _zhiuLogger.SystemLog(JSON.stringify(stat, undefined, 4));
        if (stat.type == 'inbound-rtp' &&
                    !stat.isRemote &&
                    (stat.mediaType == 'video' || stat.id.toLowerCase().includes('video'))) {
          newStat.timestamp = stat.timestamp
          newStat.bytesReceived = stat.bytesReceived
          newStat.framesDecoded = stat.framesDecoded
          newStat.packetsLost = stat.packetsLost
          newStat.bytesReceivedStart = self.aggregatedStats && self.aggregatedStats.bytesReceivedStart ? self.aggregatedStats.bytesReceivedStart : stat.bytesReceived
          newStat.framesDecodedStart = self.aggregatedStats && self.aggregatedStats.framesDecodedStart ? self.aggregatedStats.framesDecodedStart : stat.framesDecoded
          newStat.timestampStart = self.aggregatedStats && self.aggregatedStats.timestampStart ? self.aggregatedStats.timestampStart : stat.timestamp

          if (self.aggregatedStats && self.aggregatedStats.timestamp) {
            if (self.aggregatedStats.bytesReceived) {
              // bitrate = bits received since last time / number of ms since last time
              // This is automatically in kbits (where k=1000) since time is in ms and stat we want is in seconds (so a '* 1000' then a '/ 1000' would negate each other)
              newStat.bitrate = 8 * (newStat.bytesReceived - self.aggregatedStats.bytesReceived) / (newStat.timestamp - self.aggregatedStats.timestamp)
              newStat.bitrate = Math.floor(newStat.bitrate)
              newStat.lowBitrate = self.aggregatedStats.lowBitrate && self.aggregatedStats.lowBitrate < newStat.bitrate ? self.aggregatedStats.lowBitrate : newStat.bitrate
              newStat.highBitrate = self.aggregatedStats.highBitrate && self.aggregatedStats.highBitrate > newStat.bitrate ? self.aggregatedStats.highBitrate : newStat.bitrate
            }

            if (self.aggregatedStats.bytesReceivedStart) {
              newStat.avgBitrate = 8 * (newStat.bytesReceived - self.aggregatedStats.bytesReceivedStart) / (newStat.timestamp - self.aggregatedStats.timestampStart)
              newStat.avgBitrate = Math.floor(newStat.avgBitrate)
            }

            if (self.aggregatedStats.framesDecoded) {
              // framerate = frames decoded since last time / number of seconds since last time
              newStat.framerate = (newStat.framesDecoded - self.aggregatedStats.framesDecoded) / ((newStat.timestamp - self.aggregatedStats.timestamp) / 1000)
              newStat.framerate = Math.floor(newStat.framerate)
              newStat.lowFramerate = self.aggregatedStats.lowFramerate && self.aggregatedStats.lowFramerate < newStat.framerate ? self.aggregatedStats.lowFramerate : newStat.framerate
              newStat.highFramerate = self.aggregatedStats.highFramerate && self.aggregatedStats.highFramerate > newStat.framerate ? self.aggregatedStats.highFramerate : newStat.framerate
            }

            if (self.aggregatedStats.framesDecodedStart) {
              newStat.avgframerate = (newStat.framesDecoded - self.aggregatedStats.framesDecodedStart) / ((newStat.timestamp - self.aggregatedStats.timestampStart) / 1000)
              newStat.avgframerate = Math.floor(newStat.avgframerate)
            }
          }
        }

        // Read video track stats
        if (stat.type == 'track' && (stat.trackIdentifier == 'video_label' || stat.kind == 'video')) {
          newStat.framesDropped = stat.framesDropped
          newStat.framesReceived = stat.framesReceived
          newStat.framesDroppedPercentage = stat.framesDropped / stat.framesReceived * 100
          newStat.frameHeight = stat.frameHeight
          newStat.frameWidth = stat.frameWidth
          newStat.frameHeightStart = self.aggregatedStats && self.aggregatedStats.frameHeightStart ? self.aggregatedStats.frameHeightStart : stat.frameHeight
          newStat.frameWidthStart = self.aggregatedStats && self.aggregatedStats.frameWidthStart ? self.aggregatedStats.frameWidthStart : stat.frameWidth
        }

        if (stat.type == 'candidate-pair' && stat.hasOwnProperty('currentRoundTripTime') && stat.currentRoundTripTime != 0) {
          newStat.currentRoundTripTime = stat.currentRoundTripTime
        }
      })

      // _zhiuLogger.SystemLog(JSON.stringify(newStat));
      self.aggregatedStats = newStat

      if (self.onAggregatedStats) { self.onAggregatedStats(newStat) }
    }
  }

  //* *********************
  // Public functions
  //* *********************

  // This is called when revceiving new ice candidates individually instead of part of the offer
  // This is currently not used but would be called externally from this class
  this.handleCandidateFromServer = function (iceCandidate) {
    _zhiuLogger.SystemLog('ICE candidate: ' + JSON.stringify(iceCandidate))
    const candidate = new RTCIceCandidate(iceCandidate)
    self.pcClient.addIceCandidate(candidate).then(_ => {
      _zhiuLogger.SystemLog('ICE candidate successfully added')
    })
  }

  // Called externaly to create an offer for the server
  this.createOffer = function () {
    if (self.pcClient) {
      _zhiuLogger.SystemLog('Closing existing PeerConnection')
      self.pcClient.close()
      self.pcClient = null
    }
    self.pcClient = new RTCPeerConnection(self.cfg)
    setupPeerConnection(self.pcClient)
    self.dcClient = setupDataChannel(self.pcClient, 'cirrus', self.dataChannelOptions)
    handleCreateOffer(self.pcClient)
  }

  // Called externaly when an answer is received from the server
  this.receiveAnswer = function (answer) {
    _zhiuLogger.SystemLog(`Received answer:\n${answer}`)
    const answerDesc = new RTCSessionDescription(answer)
    self.pcClient.setRemoteDescription(answerDesc)
  }

  this.close = function () {
    if (self.pcClient) {
      _zhiuLogger.SystemLog('Closing existing peerClient')
      self.pcClient.close()
      self.pcClient = null
    }
    if (self.aggregateStatsIntervalId) { clearInterval(self.aggregateStatsIntervalId) }
  }

  // 通过数据通道发送数据
  this.send = function (data) {
    if (self.dcClient && self.dcClient.readyState == 'open') {
      // _zhiuLogger.SystemLog('在数据连接上发送数据'+JSON.stringify( self.dcClient));
      self.dcClient.send(data)
    }
  }

  this.getStats = function (onStats) {
    if (self.pcClient && onStats) {
      self.pcClient.getStats(null).then((stats) => {
        onStats(stats)
      })
    }
  }

  this.aggregateStats = function (checkInterval) {
    const calcAggregatedStats = generateAggregatedStatsFunction()
    const printAggregatedStats = () => { self.getStats(calcAggregatedStats) }
    self.aggregateStatsIntervalId = setInterval(printAggregatedStats, checkInterval)
  }
}
const _zhiuLogger = {
  isOpenZhiuLog: true,
  isOpenSystemLog: false,
  Log: function (msg) {
    if (this.isOpenZhiuLog) { console.log(' >LJason< 日志：', msg) }
  },
  Warning: function (msg) {
    if (this.isOpenZhiuLog) { console.warn(' >LJason< 警告：', msg) }
  },
  Error: function (msg) {
    if (this.isOpenZhiuLog) { console.error(' >LJason< 错误：', msg) }
  },
  SystemLog: function (msg) {
    if (this.isOpenSystemLog) { console.log(' >System< 日志：', msg) }
  },
  SystemWarning: function (msg) {
    if (this.isOpenSystemLog) { console.warn(' >System< 警告：', msg) }
  },
  SystemError: function (msg) {
    if (this.isOpenSystemLog) { console.error(' >System< 错误：', msg) }
  }
}// 打印功能，可以直接屏蔽系统日志和己方日志
