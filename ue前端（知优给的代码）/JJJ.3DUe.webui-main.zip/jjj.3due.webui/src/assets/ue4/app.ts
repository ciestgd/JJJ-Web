/*eslint-disable*/
// Copyright Epic Games, Inc. All Rights Reserved.
import { webRtcPlayer } from './webRtcPlayer'

let webRtcPlayerObj:any = null// webrtc句柄 视频主要是这个提供的
const print_stats = false// 是否打印状态  目前原生UI禁用后，这个就坏了
const print_inputs = false// 是否打印键盘鼠标输入
const connect_on_load = false// 貌似是是否显示

let is_reconnection = false// 是否重连
let ws:any// 用于创建webRTC通道的webSocket
const WS_OPEN_STATE = 1// webSocket打开状态 用于判断当前状态

let qualityControlOwnershipCheckBox:any// 质量控制所有权复选框
let matchViewportResolution// UI上面的 是否匹配分辨率 boolean 目前已禁用
// TODO: 删除这个- 解决方法，因为错误导致切换分辨率过快时UE崩溃
let lastTimeResized = new Date().getTime()// 最后修改分辨率的时间
let resizeTimeout:any// 用于存储重设分辨率setTimeout句柄的

let onDataChannelConnected// 当数据通道已连接
const responseEventListeners = new Map()// 响应事件监听表

let freezeFrameOverlay:any = null// 冻结帧遮罩层
let shouldShowPlayOverlay = false// 是否显示开始遮罩
// 冻结帧是显示的静态JPEG图像，而不是视频。
const freezeFrame = {
  receiving: false,
  size: 0,
  jpeg: undefined,
  height: 0,
  width: 0,
  valid: false
}

// （可选）检测用户是否未互动（AFK）并断开他们的连接.
const afk = {
  enabled: false, // Set to true to enable the AFK system.
  warnTimeout: 120, // The time to elapse before warning the user they are inactive.
  closeTimeout: 10, // The time after the warning when we disconnect the user.

  active: false, // Whether the AFK system is currently looking for inactivity.
  overlay: undefined, // The UI overlay warning the user that they are inactive.
  warnTimer: undefined, // The timer which waits to show the inactivity warning overlay.
  countdown: 0, // The inactivity warning overlay has a countdown to show time until disconnect.
  countdownTimer: undefined // The timer used to tick the seconds shown on the inactivity warning overlay.
}

// 如果用户专注于UE4输入小部件，则我们向他们显示一个打开屏幕键盘的按钮。
// JavaScript安全性意味着我们只能在响应用户交互时显示屏幕键盘。
let editTextButton:any

// 隐藏的输入文本框，仅用于聚焦和或打开屏幕上的键盘。
let hiddenInput:any

const t0 = Date.now()// log专用的开始时间
function log (str:any) {
  _zhiuLogger.SystemLog(`${Math.floor(Date.now() - t0)}: ` + str)
}

// 初始化h5事件 尺寸变更 移动端方向变换
function setupHtmlEvents () {
  // Window events
  window.addEventListener('resize', resizePlayerStyle, true)
  window.addEventListener('orientationchange', onOrientationChange)

  // HTML elements controls
  const overlayButton = document.getElementById('overlayButton')
  if (overlayButton != null) { overlayButton.addEventListener('click', onExpandOverlay_Click) }

  const resizeCheckBox = document.getElementById('enlarge-display-to-fill-window-tgl')
  if (resizeCheckBox !== null) {
    resizeCheckBox.onchange = function (event) {
      resizePlayerStyle()
    }
  }

  qualityControlOwnershipCheckBox = document.getElementById('quality-control-ownership-tgl')
  if (qualityControlOwnershipCheckBox !== null) {
    qualityControlOwnershipCheckBox.onchange = function (event:any) {
      requestQualityControl()
    }
  }

  const prioritiseQualityCheckbox = document.getElementById('prioritise-quality-tgl')
  const qualityParamsSubmit = document.getElementById('quality-params-submit')

  if (prioritiseQualityCheckbox !== null) {
    prioritiseQualityCheckbox.onchange = function (event) {
      if (prioritiseQualityCheckbox.checked) {
        // TODO: This state should be read from the UE Application rather than from the initial values in the HTML
        const lowBitrate = document.getElementById('low-bitrate-text').value
        const highBitrate = document.getElementById('high-bitrate-text').value
        const minFPS = document.getElementById('min-fps-text').value

        const initialDescriptor = {
          PrioritiseQuality: 1,
          LowBitrate: lowBitrate,
          HighBitrate: highBitrate,
          MinFPS: minFPS
        }
        // TODO: The descriptor should be sent as is to a generic handler on the UE side
        // but for now we're just sending it as separate console commands
        // emitUIInteraction(initialDescriptor);
        sendQualityConsoleCommands(initialDescriptor)
        _zhiuLogger.SystemLog(initialDescriptor)

                qualityParamsSubmit!.onclick = function (event) {
                  const lowBitrate = document.getElementById('low-bitrate-text').value
                  const highBitrate = document.getElementById('high-bitrate-text').value
                  const minFPS = document.getElementById('min-fps-text').value
                  const descriptor = {
                    PrioritiseQuality: 1,
                    LowBitrate: lowBitrate,
                    HighBitrate: highBitrate,
                    MinFPS: minFPS
                  }
                  // emitUIInteraction(descriptor);
                  sendQualityConsoleCommands(descriptor)
                  _zhiuLogger.SystemLog(descriptor)
                }
      } else { // Prioritise Quality unchecked
        const initialDescriptor = {
          PrioritiseQuality: 0
        }
        // emitUIInteraction(initialDescriptor);
        sendQualityConsoleCommands(initialDescriptor)
        _zhiuLogger.SystemLog(initialDescriptor)

        qualityParamsSubmit.onclick = null
      }
    }
  }

  const showFPSButton = document.getElementById('show-fps-button')
  if (showFPSButton !== null) {
    showFPSButton.onclick = function (event) {
      const consoleDescriptor = {
        Console: 'stat fps'
      }
      emitUIInteraction(consoleDescriptor)
    }
  }

  const matchViewportResolutionCheckBox = document.getElementById('match-viewport-res-tgl')
  if (matchViewportResolutionCheckBox !== null) {
    matchViewportResolutionCheckBox.onchange = function (event) {
      matchViewportResolution = matchViewportResolutionCheckBox.checked
    }
  }

  const statsCheckBox = document.getElementById('show-stats-tgl')
  if (statsCheckBox !== null) {
    statsCheckBox.onchange = function (event) {
      const stats = document.getElementById('statsContainer')
      stats.style.display = event.target.checked ? 'block' : 'none'
    }
  }

  const kickButton = document.getElementById('kick-other-players-button')
  if (kickButton) {
    kickButton.onclick = function (event) {
      _zhiuLogger.SystemLog('-> SS: kick')
      ws.send(JSON.stringify({ type: 'kick' }))
    }
  }
}

// 发送质量控制台命令
function sendQualityConsoleCommands (descriptor) {
  // 优先考虑质量
  if (descriptor.PrioritiseQuality !== null) {
    const command = 'Streamer.PrioritiseQuality ' + descriptor.PrioritiseQuality
    const consoleDescriptor = {
      Console: command
    }
    emitUIInteraction(consoleDescriptor)
  }
  // 低比特率
  if (descriptor.LowBitrate !== null) {
    const command = 'Streamer.LowBitrate ' + descriptor.LowBitrate
    const consoleDescriptor = {
      Console: command
    }
    emitUIInteraction(consoleDescriptor)
  }
  // 高比特率
  if (descriptor.HighBitrate !== null) {
    const command = 'Streamer.HighBitrate ' + descriptor.HighBitrate
    const consoleDescriptor = {
      Console: command
    }
    emitUIInteraction(consoleDescriptor)
  }
  // 最小帧率
  if (descriptor.MinFPS !== null) {
    const command = 'Streamer.MinFPS ' + descriptor.MinFPS
    const consoleDescriptor = {
      Console: command
    }
    emitUIInteraction(consoleDescriptor)
  }
}

// 主要用于设置删除旧ui放入新ui 原生的功能  因为不用UI所以停了
function setOverlay (htmlClass, htmlElement, onClickFunction) {
  let videoPlayOverlay = document.getElementById('videoPlayOverlay')
  if (!videoPlayOverlay) {
    const playerDiv = document.getElementById(_videoContainerId)
    videoPlayOverlay = document.createElement('div')
    videoPlayOverlay.id = 'videoPlayOverlay'
    playerDiv.appendChild(videoPlayOverlay)
  }

  // 删除现有的html子元素，以便我们可以添加新的子元素
  while (videoPlayOverlay.lastChild) {
    videoPlayOverlay.removeChild(videoPlayOverlay.lastChild)
  }

  if (htmlElement) { videoPlayOverlay.appendChild(htmlElement) }

  if (onClickFunction) {
    videoPlayOverlay.addEventListener('click', function onOverlayClick (event) {
      onClickFunction(event)
      videoPlayOverlay.removeEventListener('click', onOverlayClick)
    })
  }

  // 删除现有的html类，以便我们可以设置新的html类
  const cl = videoPlayOverlay.classList
  for (let i = cl.length - 1; i >= 0; i--) {
    cl.remove(cl[i])
  }

  videoPlayOverlay.classList.add(htmlClass)
}

// 这是play按键的UI控制器  原生的功能  因为不用UI所以停了
function showConnectOverlay () {
  const startText = document.createElement('div')
  startText.id = 'playButton'
  startText.innerHTML = 'Click to start'

  setOverlay('clickableState', startText, event => {
    connect()
    startAfkWarningTimer()
  })
}

// 用于设置文字ui  原生的功能  因为不用UI所以停了
function showTextOverlay (text) {
  return
  const textOverlay = document.createElement('div')
  textOverlay.id = 'messageOverlay'
  textOverlay.innerHTML = text || ''
  setOverlay('textDisplayState', textOverlay)
}

// 用于设置 播放图片 原生的功能  因为不用UI所以停了
function showPlayOverlay () {
  const img = document.createElement('img')
  img.id = 'playButton'
  img.src = '/Play.png'
  img.alt = 'Start Streaming'
  setOverlay('clickableState', img, event => {
    if (webRtcPlayerObj) { webRtcPlayerObj.video.play() }

    requestQualityControl()

    showFreezeFrameOverlay()
    hideOverlay()
  })
  shouldShowPlayOverlay = false
}

// 更新AFK页面文字  原生的功能  因为不用UI所以停了
function updateAfkOverlayText () {
  afk.overlay.innerHTML = '<center>No activity detected<br>Disconnecting in ' + afk.countdown + ' seconds<br>Click to continue<br></center>'
}

// 显示AFK遮罩  原生的功能  因为不用UI所以停了
function showAfkOverlay () {
  // Pause the timer while the user is looking at the inactivity warning overlay.
  stopAfkWarningTimer()

  // Show the inactivity warning overlay.
  afk.overlay = document.createElement('div')
  afk.overlay.id = 'afkOverlay'
  setOverlay('clickableState', afk.overlay, event => {
    // The user clicked so start the timer again and carry on.
    hideOverlay()
    clearInterval(afk.countdownTimer)
    startAfkWarningTimer()
  })

  afk.countdown = afk.closeTimeout
  updateAfkOverlayText()

  if (inputOptions.controlScheme == ControlSchemeType.LockedMouse) {
    document.exitPointerLock()
  }

  afk.countdownTimer = setInterval(function () {
    afk.countdown--
    if (afk.countdown == 0) {
      // The user failed to click so disconnect them.
      hideOverlay()
      ws.close()
    } else {
      // Update the countdown message.
      updateAfkOverlayText()
    }
  }, 1000)
}

// 隐藏遮罩
function hideOverlay () {
  setOverlay('hiddenState')
}

// 启动一个计时器，该计时器经过后将警告用户它们不活动
function startAfkWarningTimer () {
  afk.active = afk.enabled
  resetAfkWarningTimer()
}

// 停止计时器，计时器到期后会警告用户它们不活动
function stopAfkWarningTimer () {
  afk.active = false
}

// 如果用户进行交互，则重置警告计时器
function resetAfkWarningTimer () {
  if (afk.active) {
    clearTimeout(afk.warnTimer)
    afk.warnTimer = setTimeout(function () {
      showAfkOverlay()
    }, afk.warnTimeout * 1000)
  }
}

// 创建WebRtcOffer
function createWebRtcOffer () {
  if (webRtcPlayerObj) {
    _zhiuLogger.SystemLog('Creating offer')
    showTextOverlay('Starting connection to server, please wait')
    webRtcPlayerObj.createOffer()
  } else {
    _zhiuLogger.SystemLog('WebRTC player not setup, cannot create offer')
    showTextOverlay('Unable to setup video')
  }
}

// 发送输入信息
function sendInputData (data) {
  if (webRtcPlayerObj) {
    resetAfkWarningTimer()
    webRtcPlayerObj.send(data)
    zhiu_ResetAFKTimer()
  }
}

// 添加响应监听 这就是专门用来接收ue信息的
function addResponseEventListener (name, listener) {
  responseEventListeners.set(name, listener)
}

// 清除响应监听 这就是专门用来接收ue信息的
function removeResponseEventListener (name) {
  responseEventListeners.remove(name)
}

// 必须与PixelStreamingProtocol :: EToClientMsg C ++枚举保持同步
const ToClientMessageType = {
  QualityControlOwnership: 0,
  Response: 1,
  Command: 2,
  FreezeFrame: 3,
  UnfreezeFrame: 4,
  VideoEncoderAvgQP: 5
}
// 视频编码？
let VideoEncoderQP = 'N/A'

// 初始化WebRTC播放器 并在加载完成后直接进行调用屏蔽原有播放流程
function removeExtmapAllowMixed (desc) {
  /* remove a=extmap-allow-mixed for webrtc.org < M71 */
  if (!window.RTCPeerConnection) {
    return
  }
  if (desc.sdp.indexOf('\na=extmap-allow-mixed') !== -1) {
    const sdp = desc.sdp.split('\n').filter((line) => {
      return line.trim() !== 'a=extmap-allow-mixed'
    }).join('\n')
    desc.sdp = sdp
    return sdp
  }
}
function setupWebRtcPlayer (htmlElement, config) {
  webRtcPlayerObj = new webRtcPlayer({ peerConnectionOptions: config.peerConnectionOptions })
  htmlElement.appendChild(webRtcPlayerObj.video)
  htmlElement.appendChild(freezeFrameOverlay)
  _CreateWelcomeLay()// 创建欢迎页面
  // offer交换？
  webRtcPlayerObj.onWebRtcOffer = function (offer) {
    if (ws && ws.readyState === WS_OPEN_STATE) {
      removeExtmapAllowMixed(offer)
      const offerStr = JSON.stringify(offer)
      _zhiuLogger.SystemLog(`-> SS: offer:\n${offerStr}`)
      ws.send(offerStr)
    }
  }
  // 候选人信息？
  webRtcPlayerObj.onWebRtcCandidate = function (candidate) {
    if (ws && ws.readyState === WS_OPEN_STATE) {
      _zhiuLogger.SystemLog(`-> SS: iceCandidate\n${JSON.stringify(candidate, undefined, 4)}`)
      ws.send(JSON.stringify({ type: 'iceCandidate', candidate }))
    }
  }
  // 当视频初始化完成
  webRtcPlayerObj.onVideoInitialised = function () {
    if (ws && ws.readyState === WS_OPEN_STATE) {
      // region LJason 不进行UI显示直接播放
      // webRtcPlayerObj.video.play();
      webRtcPlayerObj.video.onplay = _VideoPlayedCallback()
      return
      // endregion
      if (shouldShowPlayOverlay) {
        showPlayOverlay()
        resizePlayerStyle()
      }
    }
  }
  // 当rtc连接成功，等待视频 原来有个等待页面
  webRtcPlayerObj.onDataChannelConnected = function () {
    if (ws && ws.readyState === WS_OPEN_STATE) {
      // showTextOverlay('WebRTC connected, waiting for video');
    }
  }

  // 显示冻结帧
  function showFreezeFrame () {
    const base64 = btoa(freezeFrame.jpeg.reduce((data, byte) => data + String.fromCharCode(byte), ''))
    freezeFrameOverlay.src = 'data:image/jpeg;base64,' + base64
    freezeFrameOverlay.onload = function () {
      freezeFrame.height = freezeFrameOverlay.naturalHeight
      freezeFrame.width = freezeFrameOverlay.naturalWidth
      resizeFreezeFrameOverlay()
      if (shouldShowPlayOverlay) {
        showPlayOverlay()
        resizePlayerStyle()
      } else {
        showFreezeFrameOverlay()
      }
    }
  }

  // 和ue4通讯就在这里
  webRtcPlayerObj.onDataChannelMessage = function (data) {
    const view = new Uint8Array(data)
    if (freezeFrame.receiving) {
      const jpeg = new Uint8Array(freezeFrame.jpeg.length + view.length)
      jpeg.set(freezeFrame.jpeg, 0)
      jpeg.set(view, freezeFrame.jpeg.length)
      freezeFrame.jpeg = jpeg
      if (freezeFrame.jpeg.length === freezeFrame.size) {
        freezeFrame.receiving = false
        freezeFrame.valid = true
        _zhiuLogger.SystemLog(`收到完整的冻结帧 ${freezeFrame.size}`)
        showFreezeFrame()
      } else if (freezeFrame.jpeg.length > freezeFrame.size) {
        _zhiuLogger.SystemError(`received bigger freeze frame than advertised: ${freezeFrame.jpeg.length}/${freezeFrame.size}`)
        freezeFrame.jpeg = undefined
        freezeFrame.receiving = false
      } else {
        _zhiuLogger.SystemLog(`received next chunk (${view.length} bytes) of freeze frame: ${freezeFrame.jpeg.length}/${freezeFrame.size}`)
      }
    } else if (view[0] === ToClientMessageType.QualityControlOwnership) {
      const ownership = view[1] !== 0
      // If we own the quality control, we can't relenquish it. We only loose
      // quality control when another peer asks for it
      if (qualityControlOwnershipCheckBox != null) {
        qualityControlOwnershipCheckBox.disabled = ownership
        qualityControlOwnershipCheckBox.checked = ownership
      }
    } else if (view[0] === ToClientMessageType.Response) {
      const response = new TextDecoder('utf-16').decode(data.slice(1))
      for (const listener of responseEventListeners.values()) {
        listener(response)
      }
    } else if (view[0] === ToClientMessageType.Command) {
      const commandAsString = new TextDecoder('utf-16').decode(data.slice(1))
      _zhiuLogger.SystemLog(commandAsString)
      const command = JSON.parse(commandAsString)
      if (command.command === 'onScreenKeyboard') {
        showOnScreenKeyboard(command)
      }
    } else if (view[0] === ToClientMessageType.FreezeFrame) {
      freezeFrame.size = (new DataView(view.slice(1, 5).buffer)).getInt32(0, true)
      freezeFrame.jpeg = view.slice(1 + 4)
      if (freezeFrame.jpeg.length < freezeFrame.size) {
        _zhiuLogger.SystemLog(`received first chunk of freeze frame: ${freezeFrame.jpeg.length}/${freezeFrame.size}`)
        freezeFrame.receiving = true
      } else {
        _zhiuLogger.SystemLog(`received complete freeze frame: ${freezeFrame.jpeg.length}/${freezeFrame.size}`)
        showFreezeFrame()
      }
    } else if (view[0] === ToClientMessageType.UnfreezeFrame) {
      invalidateFreezeFrameOverlay()
    } else if (view[0] === ToClientMessageType.VideoEncoderAvgQP) {
      VideoEncoderQP = new TextDecoder('utf-16').decode(data.slice(1))
      _zhiuLogger.SystemLog(`received VideoEncoderAvgQP ${VideoEncoderQP}`)
    } else {
      _zhiuLogger.SystemError(`unrecognized data received, packet ID ${view[0]}`)
    }
  }
  // 注册输入
  registerInputs(webRtcPlayerObj.video)

  // 在触摸设备上，我们将需要特殊的方式来显示屏幕键盘.
  if ('ontouchstart' in document.documentElement) {
    createOnScreenKeyboardHelpers(htmlElement)
  }

  createWebRtcOffer()

  return webRtcPlayerObj.video
}

// 当WebRTC回复
function onWebRtcAnswer (webRTCData) {
  webRtcPlayerObj.receiveAnswer(webRTCData)

  const printInterval = 5 * 60 * 1000 /* Print every 5 minutes */
  let nextPrintDuration = printInterval

  webRtcPlayerObj.onAggregatedStats = (aggregatedStats) => {
    const numberFormat = new Intl.NumberFormat(window.navigator.language, { maximumFractionDigits: 0 })
    const timeFormat = new Intl.NumberFormat(window.navigator.language, { maximumFractionDigits: 0, minimumIntegerDigits: 2 })
    _OnWebRTCAggregatedStatsCallback(aggregatedStats)// LJason 用于拿到帧数等状态
    // Calculate duration of run
    let runTime = (aggregatedStats.timestamp - aggregatedStats.timestampStart) / 1000
    const timeValues = []
    const timeDurations = [60, 60]
    for (let timeIndex = 0; timeIndex < timeDurations.length; timeIndex++) {
      timeValues.push(runTime % timeDurations[timeIndex])
      runTime = runTime / timeDurations[timeIndex]
    }
    timeValues.push(runTime)

    const runTimeSeconds = timeValues[0]
    const runTimeMinutes = Math.floor(timeValues[1])
    const runTimeHours = Math.floor([timeValues[2]])

    let receivedBytesMeasurement = 'B'
    let receivedBytes = aggregatedStats.hasOwnProperty('bytesReceived') ? aggregatedStats.bytesReceived : 0
    const dataMeasurements = ['kB', 'MB', 'GB']
    for (let index = 0; index < dataMeasurements.length; index++) {
      if (receivedBytes < 100 * 1000) { break }
      receivedBytes = receivedBytes / 1000
      receivedBytesMeasurement = dataMeasurements[index]
    }

    const qualityStatus = document.getElementById('qualityStatus')
    if (qualityStatus == null) return
    // "blinks" quality status element for 1 sec by making it transparent, speed = number of blinks
    const blinkQualityStatus = function (speed) {
      let iter = speed
      let opacity = 1 // [0..1]
      const tickId = setInterval(
        function () {
          opacity -= 0.1
          // map `opacity` to [-0.5..0.5] range, decrement by 0.2 per step and take `abs` to make it blink: 1 -> 0 -> 1
          qualityStatus.style = `opacity: ${Math.abs((opacity - 0.5) * 2)}`
          if (opacity <= 0.1) {
            if (--iter == 0) {
              clearInterval(tickId)
            } else { // next blink
              opacity = 1
            }
          }
        },
        100 / speed // msecs
      )
    }

    const orangeQP = 26
    const redQP = 35

    let statsText = ''

    let color = 'lime'
    if (VideoEncoderQP > redQP) {
      color = 'red'
      blinkQualityStatus(2)
      statsText += `<div style="color: ${color}">Bad network connection</div>`
    } else if (VideoEncoderQP > orangeQP) {
      color = 'orange'
      blinkQualityStatus(1)
      statsText += `<div style="color: ${color}">Spotty network connection</div>`
    }

    qualityStatus.className = `${color}Status`

    statsText += `<div>Duration: ${timeFormat.format(runTimeHours)}:${timeFormat.format(runTimeMinutes)}:${timeFormat.format(runTimeSeconds)}</div>`
    statsText += `<div>Video Resolution: ${
            aggregatedStats.hasOwnProperty('frameWidth') && aggregatedStats.frameWidth && aggregatedStats.hasOwnProperty('frameHeight') && aggregatedStats.frameHeight
                ? aggregatedStats.frameWidth + 'x' + aggregatedStats.frameHeight
: 'N/A'
        }</div>`
    statsText += `<div>Received (${receivedBytesMeasurement}): ${numberFormat.format(receivedBytes)}</div>`
    statsText += `<div>Frames Decoded: ${aggregatedStats.hasOwnProperty('framesDecoded') ? numberFormat.format(aggregatedStats.framesDecoded) : 'N/A'}</div>`
    statsText += `<div>Packets Lost: ${aggregatedStats.hasOwnProperty('packetsLost') ? numberFormat.format(aggregatedStats.packetsLost) : 'N/A'}</div>`
    statsText += `<div style="color: ${color}">Bitrate (kbps): ${aggregatedStats.hasOwnProperty('bitrate') ? numberFormat.format(aggregatedStats.bitrate) : 'N/A'}</div>`
    statsText += `<div>Framerate: ${aggregatedStats.hasOwnProperty('framerate') ? numberFormat.format(aggregatedStats.framerate) : 'N/A'}</div>`
    statsText += `<div>Frames dropped: ${aggregatedStats.hasOwnProperty('framesDropped') ? numberFormat.format(aggregatedStats.framesDropped) : 'N/A'}</div>`
    statsText += `<div>Latency (ms): ${aggregatedStats.hasOwnProperty('currentRoundTripTime') ? numberFormat.format(aggregatedStats.currentRoundTripTime * 1000) : 'N/A'}</div>`
    statsText += `<div style="color: ${color}">Video Quantization Parameter: ${VideoEncoderQP}</div>`

    const statsDiv = document.getElementById('stats')
    statsDiv.innerHTML = statsText

    if (print_stats) {
      if (aggregatedStats.timestampStart) {
        if ((aggregatedStats.timestamp - aggregatedStats.timestampStart) > nextPrintDuration) {
          if (ws && ws.readyState === WS_OPEN_STATE) {
            _zhiuLogger.SystemLog(`-> SS: stats\n${JSON.stringify(aggregatedStats)}`)
            ws.send(JSON.stringify({ type: 'stats', data: aggregatedStats }))
          }
          nextPrintDuration += printInterval
        }
      }
    }
  }

  webRtcPlayerObj.aggregateStats(1 * 1000 /* Check every 1 second */)

  // let displayStats = () => { webRtcPlayerObj.getStats( (s) => { s.forEach(stat => { _zhiuLogger.SystemLog(JSON.stringify(stat)); }); } ); }
  // let displayStatsIntervalId = setInterval(displayStats, 30 * 1000);
}

// 当WebRTC候选人？？？
function onWebRtcIce (iceCandidate) {
  if (webRtcPlayerObj) { webRtcPlayerObj.handleCandidateFromServer(iceCandidate) }
}

let styleWidth// 宽度样式
let styleHeight// 高度样式
let styleTop// 顶部距离样式
let styleLeft// 左部距离样式
let styleCursor = 'default'// 鼠标样式
let styleAdditional// 附加样式？
// 鼠标控制方案枚举 锁定或不锁定
const ControlSchemeType = {
  // 鼠标可以锁定在WebRTC播放器内部，因此用户只需移动鼠标即可控制摄像机的方向。用户按下Escape键以解锁鼠标。
  LockedMouse: 0,

  // 鼠标可以悬停在WebRTC播放器上，因此用户需要单击和或拖动以控制摄像机的方向。
  HoveringMouse: 1
}
// 输入配置 鼠标控制、是否允许浏览器控制例如F5、是否伪装单指触摸
const inputOptions = {
  // 当鼠标与WebRTC播放器交互时，该控制方案控制鼠标的行为。
  controlScheme: ControlSchemeType.HoveringMouse,

  // 浏览器键是浏览器UI通常使用的键。我们通常希望抑制这些，以便例如UE4在不刷新网页的情况下使用F5键显示着色器的复杂性
  suppressBrowserKeys: true,

  // UE4具有“ faketouches”选项，当用户用鼠标拖动时，该选项会伪造单指触摸。
  // 我们可能执行相反的操作；单指触摸可以转换为UE4端的鼠标拖动。这允许通过触摸设备部分控制非触摸应用程序
  fakeMouseWithTouches: false
}

// 调整video样式以填充窗口
function resizePlayerStyleToFillWindow (playerElement) {
  const videoElement = playerElement.getElementsByTagName('VIDEO')

  // 在窗口中填充播放器显示，保持图片的长宽比.
  const windowAspectRatio = window.innerHeight / window.innerWidth
  const playerAspectRatio = playerElement.clientHeight / playerElement.clientWidth
  // 我们要保持视频流的视频比例正确
  const videoAspectRatio = videoElement.videoHeight / videoElement.videoWidth
  if (isNaN(videoAspectRatio)) {
    // 视频尚未初始化，因此请将playerElement设置为窗口大小
    styleWidth = window.innerWidth
    styleHeight = window.innerHeight
    styleTop = 0
    styleLeft = 0
    playerElement.style = 'top: ' + styleTop + 'px; left: ' + styleLeft + 'px; width: ' + styleWidth + 'px; height: ' + styleHeight + 'px; cursor: ' + styleCursor + '; ' + styleAdditional
  } else if (windowAspectRatio < playerAspectRatio) {
    // Window height is the constraining factor so to keep aspect ratio change width appropriately
    styleWidth = Math.floor(window.innerHeight / videoAspectRatio)
    styleHeight = window.innerHeight
    styleTop = 0
    styleLeft = Math.floor((window.innerWidth - styleWidth) * 0.5)
    // Video is now 100% of the playerElement, so set the playerElement style
    playerElement.style = 'top: ' + styleTop + 'px; left: ' + styleLeft + 'px; width: ' + styleWidth + 'px; height: ' + styleHeight + 'px; cursor: ' + styleCursor + '; ' + styleAdditional
  } else {
    // Window width is the constraining factor so to keep aspect ratio change height appropriately
    styleWidth = window.innerWidth
    styleHeight = Math.floor(window.innerWidth * videoAspectRatio)
    styleTop = Math.floor((window.innerHeight - styleHeight) * 0.5)
    styleLeft = 0
    // Video is now 100% of the playerElement, so set the playerElement style
    playerElement.style = 'top: ' + styleTop + 'px; left: ' + styleLeft + 'px; width: ' + styleWidth + 'px; height: ' + styleHeight + 'px; cursor: ' + styleCursor + '; ' + styleAdditional
  }
}

// 将video样式调整为实际大小
function resizePlayerStyleToActualSize (playerElement) {
  const videoElement = playerElement.getElementsByTagName('VIDEO')

  if (videoElement.length > 0) {
    // Display image in its actual size
    styleWidth = videoElement[0].videoWidth
    styleHeight = videoElement[0].videoHeight
    styleTop = Math.floor((window.innerHeight - styleHeight) * 0.5)
    styleLeft = Math.floor((window.innerWidth - styleWidth) * 0.5)
    // Video is now 100% of the playerElement, so set the playerElement style
    playerElement.style = 'top: ' + styleTop + 'px; left: ' + styleLeft + 'px; width: ' + styleWidth + 'px; height: ' + styleHeight + 'px; cursor: ' + styleCursor + '; ' + styleAdditional
  }
}

// 将video样式调整为任意大小
function resizePlayerStyleToArbitrarySize (playerElement) {
  const videoElement = playerElement.getElementsByTagName('VIDEO')
  // Video is now 100% of the playerElement, so set the playerElement style
  playerElement.style = 'top: 0px; left: 0px; width: ' + styleWidth + 'px; height: ' + styleHeight + 'px; cursor: ' + styleCursor + '; ' + styleAdditional
}

// 初始化冻结帧遮罩
function setupFreezeFrameOverlay () {
  freezeFrameOverlay = document.createElement('img')
  freezeFrameOverlay.id = 'freezeFrameOverlay'
  freezeFrameOverlay.style.display = 'none'
  freezeFrameOverlay.style.pointerEvents = 'none'
  freezeFrameOverlay.style.position = 'absolute'
  freezeFrameOverlay.style.zIndex = '30'
}

// 显示冻结帧遮罩
function showFreezeFrameOverlay () {
  if (freezeFrame.valid) {
    freezeFrameOverlay.style.display = 'block'
  }
}

// 关闭冻结帧遮罩无效
function invalidateFreezeFrameOverlay () {
  freezeFrameOverlay.style.display = 'none'
  freezeFrame.valid = false
}

// 设置冻结帧遮罩分辨率
function resizeFreezeFrameOverlay () {
  if (freezeFrame.width !== 0 && freezeFrame.height !== 0) {
    let displayWidth = 0
    let displayHeight = 0
    let displayTop = 0
    let displayLeft = 0
    const checkBox = document.getElementById('enlarge-display-to-fill-window-tgl')
    if (checkBox !== null && checkBox.checked) {
      const windowAspectRatio = window.innerWidth / window.innerHeight
      const videoAspectRatio = freezeFrame.width / freezeFrame.height
      if (windowAspectRatio < videoAspectRatio) {
        displayWidth = window.innerWidth
        displayHeight = Math.floor(window.innerWidth / videoAspectRatio)
        displayTop = Math.floor((window.innerHeight - displayHeight) * 0.5)
        displayLeft = 0
      } else {
        displayWidth = Math.floor(window.innerHeight * videoAspectRatio)
        displayHeight = window.innerHeight
        displayTop = 0
        displayLeft = Math.floor((window.innerWidth - displayWidth) * 0.5)
      }
    } else {
      displayWidth = freezeFrame.width
      displayHeight = freezeFrame.height
      displayTop = 0
      displayLeft = 0
    }
    freezeFrameOverlay.style.width = displayWidth + 'px'
    freezeFrameOverlay.style.height = displayHeight + 'px'
    freezeFrameOverlay.style.left = displayLeft + 'px'
    freezeFrameOverlay.style.top = displayTop + 'px'
  }
}

// 更新h5video元素的尺寸 内部会调用更新推流分辨率
function resizePlayerStyle (event) {
  const playerElement = document.getElementById(_videoContainerId)

  if (!playerElement) { return }

  updateVideoStreamSize()// 更新推流分辨率
  resizePlayerStyleToFillWindow(playerElement)// 因为样式删除所以必须把下面窗口缩放移动上来
  if (playerElement.classList.contains('fixed-size')) { return }

  const checkBox = document.getElementById('enlarge-display-to-fill-window-tgl')
  const windowSmallerThanPlayer = window.innerWidth < playerElement.videoWidth || window.innerHeight < playerElement.videoHeight
  if (checkBox !== null) {
    if (checkBox.checked || windowSmallerThanPlayer) {
      resizePlayerStyleToFillWindow(playerElement)
    } else {
      resizePlayerStyleToActualSize(playerElement)
    }
  } else {
    resizePlayerStyleToArbitrarySize(playerElement)
  }

  // Calculating and normalizing positions depends on the width and height of
  // the player.
  playerElementClientRect = playerElement.getBoundingClientRect()
  setupNormalizeAndQuantize()
  resizeFreezeFrameOverlay()
}

// 更新推流分辨率 发送setres给ue更改分辨率
function updateVideoStreamSize () {
  // if (!matchViewportResolution) { // UI禁用后该选项会禁止分辨率更改，暂时跳过
  // 	return;
  // }

  const now = new Date().getTime()
  if (now - lastTimeResized > 1000) {
    const playerElement = document.getElementById(_videoContainerId)
    if (!playerElement) { return }
    const descriptor = {
      Console: 'setres ' + playerElement.clientWidth + 'x' + playerElement.clientHeight
    }
    // emitUIInteraction(descriptor);// LJason 关闭原生UI控制
    _OnWindowResize(playerElement.clientWidth, playerElement.clientHeight)// LJason 新款分辨率控制
    // _zhiuLogger.SystemLog(descriptor);// LJason 分辨率打印太多了，放弃了
    lastTimeResized = new Date().getTime()
  } else {
    // _zhiuLogger.SystemLog('Resizing too often - skipping');
    clearTimeout(resizeTimeout)
    resizeTimeout = setTimeout(updateVideoStreamSize, 1000)
  }
}

// 修复了在IOS或方向更改时 window size不正确的iOS中的错误
// https://github.com/dimsemenov/PhotoSwipe/issues/1315
let _orientationChangeTimeout

// 当手机端方向改变
function onOrientationChange (event) {
  clearTimeout(_orientationChangeTimeout)
  _orientationChangeTimeout = setTimeout(function () {
    resizePlayerStyle()
  }, 500)
}

// 必须与PixelStreamingProtocol :: EToUE4Msg C++ 枚举保持同步
const MessageType = {

  /**********************************************************************/

  /*
     * 控制信息. 范围 = 0..49.
     */
  IFrameRequest: 0, // 帧请求
  RequestQualityControl: 1, // 质量控制请求
  MaxFpsRequest: 2, // 最大帧数请求
  AverageBitrateRequest: 3, // 平均比特率请求
  StartStreaming: 4, // 开始推流
  StopStreaming: 5, // 结束推流

  /**********************************************************************/

  /*
     * 输入信息. 范围 = 50..89.
     */

  // 通用输入消息. 范围 = 50..59.
  UIInteraction: 50, // UI交互 这个是可以把指令发过去
  Command: 51, // 指令

  // 键盘输入消息  范围 = 60..69.
  KeyDown: 60, // 键盘按下
  KeyUp: 61, // 键盘抬起
  KeyPress: 62, // 按键

  // 鼠标输入信息. 范围 = 70..79.
  MouseEnter: 70, // 鼠标进入
  MouseLeave: 71, // 鼠标离开
  MouseDown: 72, // 鼠标按下
  MouseUp: 73, // 鼠标抬起
  MouseMove: 74, // 鼠标移动
  MouseWheel: 75, // 鼠标滚轮

  // 触摸输入信息. 范围 = 80..89.
  TouchStart: 80, // 触摸开始
  TouchEnd: 81, // 触摸结束
  TouchMove: 82// 滑动触摸

  /**************************************************************************/
}

// 通用消息具有类型和描述符。
function emitDescriptor (messageType, descriptor) {
  // 将descriptor对象转换为JSON字符串
  const descriptorAsString = JSON.stringify(descriptor)
  // 将UTF-16 JSON字符串添加到数组字节缓冲区，一次进入两个字节
  const data = new DataView(new ArrayBuffer(1 + 2 + 2 * descriptorAsString.length))
  let byteIdx = 0
  data.setUint8(byteIdx, messageType)
  byteIdx++
  data.setUint16(byteIdx, descriptorAsString.length, true)
  byteIdx += 2
  for (let i = 0; i < descriptorAsString.length; i++) {
    data.setUint16(byteIdx, descriptorAsString.charCodeAt(i), true)
    byteIdx += 2
  }
  sendInputData(data.buffer)
}

// 当用户按下由JavaScript驱动的按钮而不是从UE4客户端接收像素流UI的按钮时，会发生UI交互。
function emitUIInteraction (descriptor) {
  emitDescriptor(MessageType.UIInteraction, descriptor)
}

// <LJason 试了貌似没用>内置命令可以发送到UE4客户端。这些命令由JSON描述符定义，并将自动执行。
// 当前支持的命令是：
//
// 1.运行任何控制台命令的命令:
//    "{ ConsoleCommand: <string> }"
//
// 2. 将分辨率更改为给定宽度和高度的命令.
//    "{ Resolution: { Width: <value>, Height: <value> } }"
//
// 3. 通过将比特率降低给定百分比来更改编码器设置的命令.
//    "{ Encoder: { BitrateReduction: <value> } }"
function emitCommand (descriptor) {
  emitDescriptor(MessageType.Command, descriptor)
}

// 请求质量控制
function requestQualityControl () {
  sendInputData(new Uint8Array([MessageType.RequestQualityControl]).buffer)
}

let playerElementClientRect// 获取video元素相对于视窗的位置集合
let normalizeAndQuantizeUnsigned// 计算用方法 标准化和量化无符号
let normalizeAndQuantizeSigned// 计算用方法 标准化和量化签名
let unquantizeAndDenormalizeUnsigned

// 初始化归一化和量化
function setupNormalizeAndQuantize () {
  const playerElement = document.getElementById(_videoContainerId)
  const videoElement = playerElement.getElementsByTagName('video')

  if (playerElement && videoElement.length > 0) {
    const playerAspectRatio = playerElement.clientHeight / playerElement.clientWidth
    const videoAspectRatio = videoElement[0].videoHeight / videoElement[0].videoWidth

    // Unsigned XY positions are the ratio (0.0..1.0) along a viewport axis,
    // quantized into an uint16 (0..65536).
    // Signed XY deltas are the ratio (-1.0..1.0) along a viewport axis,
    // quantized into an int16 (-32767..32767).
    // This allows the browser viewport and client viewport to have a different
    // size.
    // Hack: Currently we set an out-of-range position to an extreme (65535)
    // as we can't yet accurately detect mouse enter and leave events
    // precisely inside a video with an aspect ratio which causes mattes.
    if (playerAspectRatio > videoAspectRatio) {
      if (print_inputs) {
        _zhiuLogger.SystemLog('Setup Normalize and Quantize for playerAspectRatio > videoAspectRatio')
      }
      const ratio = playerAspectRatio / videoAspectRatio
      // Unsigned.
      normalizeAndQuantizeUnsigned = (x, y) => {
        const normalizedX = x / playerElement.clientWidth
        const normalizedY = ratio * (y / playerElement.clientHeight - 0.5) + 0.5
        if (normalizedX < 0.0 || normalizedX > 1.0 || normalizedY < 0.0 || normalizedY > 1.0) {
          return {
            inRange: false,
            x: 65535,
            y: 65535
          }
        } else {
          return {
            inRange: true,
            x: normalizedX * 65536,
            y: normalizedY * 65536
          }
        }
      }
      unquantizeAndDenormalizeUnsigned = (x, y) => {
        const normalizedX = x / 65536
        const normalizedY = (y / 65536 - 0.5) / ratio + 0.5
        return {
          x: normalizedX * playerElement.clientWidth,
          y: normalizedY * playerElement.clientHeight
        }
      }
      // Signed.
      normalizeAndQuantizeSigned = (x, y) => {
        const normalizedX = x / (0.5 * playerElement.clientWidth)
        const normalizedY = (ratio * y) / (0.5 * playerElement.clientHeight)
        return {
          x: normalizedX * 32767,
          y: normalizedY * 32767
        }
      }
    } else {
      if (print_inputs) {
        _zhiuLogger.SystemLog('Setup Normalize and Quantize for playerAspectRatio <= videoAspectRatio')
      }
      const ratio = videoAspectRatio / playerAspectRatio
      // Unsigned.
      normalizeAndQuantizeUnsigned = (x, y) => {
        const normalizedX = ratio * (x / playerElement.clientWidth - 0.5) + 0.5
        const normalizedY = y / playerElement.clientHeight
        if (normalizedX < 0.0 || normalizedX > 1.0 || normalizedY < 0.0 || normalizedY > 1.0) {
          return {
            inRange: false,
            x: 65535,
            y: 65535
          }
        } else {
          return {
            inRange: true,
            x: normalizedX * 65536,
            y: normalizedY * 65536
          }
        }
      }
      unquantizeAndDenormalizeUnsigned = (x, y) => {
        const normalizedX = (x / 65536 - 0.5) / ratio + 0.5
        const normalizedY = y / 65536
        return {
          x: normalizedX * playerElement.clientWidth,
          y: normalizedY * playerElement.clientHeight
        }
      }
      // Signed.
      normalizeAndQuantizeSigned = (x, y) => {
        const normalizedX = (ratio * x) / (0.5 * playerElement.clientWidth)
        const normalizedY = y / (0.5 * playerElement.clientHeight)
        return {
          x: normalizedX * 32767,
          y: normalizedY * 32767
        }
      }
    }
  }
}

// 发送鼠标移动信息
function emitMouseMove (x, y, deltaX, deltaY) {
  if (print_inputs) {
    _zhiuLogger.SystemLog(`x: ${x}, y:${y}, dX: ${deltaX}, dY: ${deltaY}`)
  }
  const coord = normalizeAndQuantizeUnsigned(x, y)
  const delta = normalizeAndQuantizeSigned(deltaX, deltaY)
  const Data = new DataView(new ArrayBuffer(9))
  Data.setUint8(0, MessageType.MouseMove)
  Data.setUint16(1, coord.x, true)
  Data.setUint16(3, coord.y, true)
  Data.setInt16(5, delta.x, true)
  Data.setInt16(7, delta.y, true)
  sendInputData(Data.buffer)
}

// 发送鼠标按下信息
function emitMouseDown (button, x, y) {
  if (print_inputs) {
    _zhiuLogger.SystemLog(`mouse button ${button} down at (${x}, ${y})`)
  }
  const coord = normalizeAndQuantizeUnsigned(x, y)
  const Data = new DataView(new ArrayBuffer(6))
  Data.setUint8(0, MessageType.MouseDown)
  Data.setUint8(1, button)
  Data.setUint16(2, coord.x, true)
  Data.setUint16(4, coord.y, true)
  sendInputData(Data.buffer)
}

// 发送鼠标抬起信息
function emitMouseUp (button, x, y) {
  if (print_inputs) {
    _zhiuLogger.SystemLog(`mouse button ${button} up at (${x}, ${y})`)
  }
  const coord = normalizeAndQuantizeUnsigned(x, y)
  const Data = new DataView(new ArrayBuffer(6))
  Data.setUint8(0, MessageType.MouseUp)
  Data.setUint8(1, button)
  Data.setUint16(2, coord.x, true)
  Data.setUint16(4, coord.y, true)
  sendInputData(Data.buffer)
}

// 发送鼠标滚轮信息
function emitMouseWheel (delta, x, y) {
  if (print_inputs) {
    _zhiuLogger.SystemLog(`mouse wheel with delta ${delta} at (${x}, ${y})`)
  }
  const coord = normalizeAndQuantizeUnsigned(x, y)
  const Data = new DataView(new ArrayBuffer(7))
  Data.setUint8(0, MessageType.MouseWheel)
  Data.setInt16(1, delta, true)
  Data.setUint16(3, coord.x, true)
  Data.setUint16(5, coord.y, true)
  sendInputData(Data.buffer)
}

// 鼠标按键枚举 https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/button
const MouseButton = {
  MainButton: 0,			// 左键.
  AuxiliaryButton: 1,		// 滚轮按钮.
  SecondaryButton: 2,		// 右键.
  FourthButton: 3,		// 浏览器后退按钮.
  FifthButton: 4			// 浏览器前进按钮.
}

// 鼠标按键遮罩 https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/buttons
const MouseButtonsMask = {
  PrimaryButton: 1,		// 左键.
  SecondaryButton: 2,		// 右键.
  AuxiliaryButton: 4,		// 滚轮按钮.
  FourthButton: 8,		// 浏览器后退按钮.
  FifthButton: 16			// 浏览器前进按钮.
}

// 如果用户按下任何鼠标按钮，则释放它们.
function releaseMouseButtons (buttons, x, y) {
  if (buttons & MouseButtonsMask.PrimaryButton) {
    emitMouseUp(MouseButton.MainButton, x, y)
  }
  if (buttons & MouseButtonsMask.SecondaryButton) {
    emitMouseUp(MouseButton.SecondaryButton, x, y)
  }
  if (buttons & MouseButtonsMask.AuxiliaryButton) {
    emitMouseUp(MouseButton.AuxiliaryButton, x, y)
  }
  if (buttons & MouseButtonsMask.FourthButton) {
    emitMouseUp(MouseButton.FourthButton, x, y)
  }
  if (buttons & MouseButtonsMask.FifthButton) {
    emitMouseUp(MouseButton.FifthButton, x, y)
  }
}

// 如果用户按下了任何鼠标按钮，请再次按下它们.
function pressMouseButtons (buttons, x, y) {
  if (buttons & MouseButtonsMask.PrimaryButton) {
    emitMouseDown(MouseButton.MainButton, x, y)
  }
  if (buttons & MouseButtonsMask.SecondaryButton) {
    emitMouseDown(MouseButton.SecondaryButton, x, y)
  }
  if (buttons & MouseButtonsMask.AuxiliaryButton) {
    emitMouseDown(MouseButton.AuxiliaryButton, x, y)
  }
  if (buttons & MouseButtonsMask.FourthButton) {
    emitMouseDown(MouseButton.FourthButton, x, y)
  }
  if (buttons & MouseButtonsMask.FifthButton) {
    emitMouseDown(MouseButton.FifthButton, x, y)
  }
}

// 注册输入
function registerInputs (playerElement) {
  if (!playerElement) { return }

  registerMouseEnterAndLeaveEvents(playerElement)
  registerTouchEvents(playerElement)
}

// 创建屏幕键盘助手
function createOnScreenKeyboardHelpers (htmlElement) {
  if (document.getElementById('hiddenInput') === null) {
    hiddenInput = document.createElement('input')
    hiddenInput.id = 'hiddenInput'
    hiddenInput.maxLength = 0
    htmlElement.appendChild(hiddenInput)
  }

  if (document.getElementById('editTextButton') === null) {
    editTextButton = document.createElement('button')
    editTextButton.id = 'editTextButton'
    editTextButton.innerHTML = 'edit text'
    htmlElement.appendChild(editTextButton)

    // Hide the 'edit text' button.
    editTextButton.classList.add('hiddenState')

    editTextButton.addEventListener('click', function () {
      // Show the on-screen keyboard.
      hiddenInput.focus()
    })
  }
}

// 显示屏幕键盘
function showOnScreenKeyboard (command) {
  if (command.showOnScreenKeyboard) {
    // Show the 'edit text' button.
    editTextButton.classList.remove('hiddenState')
    // Place the 'edit text' button near the UE4 input widget.
    const pos = unquantizeAndDenormalizeUnsigned(command.x, command.y)
    editTextButton.style.top = pos.y.toString() + 'px'
    editTextButton.style.left = (pos.x - 40).toString() + 'px'
  } else {
    // Hide the 'edit text' button.
    editTextButton.classList.add('hiddenState')
    // Hide the on-screen keyboard.
    hiddenInput.blur()
  }
}

// 注册鼠标进入和离开事件
function registerMouseEnterAndLeaveEvents (playerElement) {
  playerElement.onmouseenter = function (e) {
    if (print_inputs) {
      _zhiuLogger.SystemLog('mouse enter')
    }
    const Data = new DataView(new ArrayBuffer(1))
    Data.setUint8(0, MessageType.MouseEnter)
    sendInputData(Data.buffer)
    playerElement.pressMouseButtons(e)
  }

  playerElement.onmouseleave = function (e) {
    if (print_inputs) {
      _zhiuLogger.SystemLog('mouse leave')
    }
    const Data = new DataView(new ArrayBuffer(1))
    Data.setUint8(0, MessageType.MouseLeave)
    sendInputData(Data.buffer)
    playerElement.releaseMouseButtons(e)
  }
}

// (锁定鼠标模式事件) 用户单击浏览器播放器时，锁定的鼠标起作用，光标消失并被锁定。
// 例如，用户移动光标，摄像机移动。用户按下逃逸键以释放鼠标。
function registerLockedMouseEvents (playerElement) {
  let x = playerElement.width / 2
  let y = playerElement.height / 2

  playerElement.requestPointerLock = playerElement.requestPointerLock || playerElement.mozRequestPointerLock
  document.exitPointerLock = document.exitPointerLock || document.mozExitPointerLock

  playerElement.onclick = function () {
    playerElement.requestPointerLock()
  }

  // Respond to lock state change events
  document.addEventListener('pointerlockchange', lockStateChange, false)
  document.addEventListener('mozpointerlockchange', lockStateChange, false)

  function lockStateChange () {
    if (document.pointerLockElement === playerElement ||
            document.mozPointerLockElement === playerElement) {
      _zhiuLogger.SystemLog('Pointer locked')
      document.addEventListener('mousemove', updatePosition, false)
    } else {
      _zhiuLogger.SystemLog('The pointer lock status is now unlocked')
      document.removeEventListener('mousemove', updatePosition, false)
    }
  }

  function updatePosition (e) {
    x += e.movementX
    y += e.movementY
    if (x > styleWidth) {
      x -= styleWidth
    }
    if (y > styleHeight) {
      y -= styleHeight
    }
    if (x < 0) {
      x = styleWidth + x
    }
    if (y < 0) {
      y = styleHeight - y
    }
    emitMouseMove(x, y, e.movementX, e.movementY)
  }

  playerElement.onmousedown = function (e) {
    emitMouseDown(e.button, x, y)
  }

  playerElement.onmouseup = function (e) {
    emitMouseUp(e.button, x, y)
  }

  playerElement.onmousewheel = function (e) {
    emitMouseWheel(e.wheelDelta, x, y)
  }

  playerElement.pressMouseButtons = function (e) {
    pressMouseButtons(e.buttons, x, y)
  }

  playerElement.releaseMouseButtons = function (e) {
    releaseMouseButtons(e.buttons, x, y)
  }
}

// (滑动鼠标模式事件) 当用户希望光标在视频上产生效果时，通过单击鼠标按钮，可以使鼠标悬停。否则，光标将通过浏览器
function registerHoveringMouseEvents (playerElement) {
  // styleCursor = 'none';   // We will rely on UE4 client's software cursor.
  styleCursor = 'default' // Showing cursor

  playerElement.onmousemove = function (e) {
    emitMouseMove(e.offsetX, e.offsetY, e.movementX, e.movementY)
    e.preventDefault()
  }

  playerElement.onmousedown = function (e) {
    emitMouseDown(e.button, e.offsetX, e.offsetY)
    e.preventDefault()
  }

  playerElement.onmouseup = function (e) {
    emitMouseUp(e.button, e.offsetX, e.offsetY)
    e.preventDefault()
  }

  // When the context menu is shown then it is safest to release the button
  // which was pressed when the event happened. This will guarantee we will
  // get at least one mouse up corresponding to a mouse down event. Otherwise
  // the mouse can get stuck.
  // https://github.com/facebook/react/issues/5531
  playerElement.oncontextmenu = function (e) {
    emitMouseUp(e.button, e.offsetX, e.offsetY)
    e.preventDefault()
  }

  if ('onmousewheel' in playerElement) {
    playerElement.onmousewheel = function (e) {
      emitMouseWheel(e.wheelDelta, e.offsetX, e.offsetY)
      e.preventDefault()
    }
  } else {
    playerElement.addEventListener('DOMMouseScroll', function (e) {
      emitMouseWheel(e.detail * -120, e.offsetX, e.offsetY)
      e.preventDefault()
    }, false)
  }

  playerElement.pressMouseButtons = function (e) {
    pressMouseButtons(e.buttons, e.offsetX, e.offsetY)
  }

  playerElement.releaseMouseButtons = function (e) {
    releaseMouseButtons(e.buttons, e.offsetX, e.offsetY)
  }
}

// 注册触摸事件
function registerTouchEvents (playerElement) {
  // We need to assign a unique identifier to each finger.
  // We do this by mapping each Touch object to the identifier.
  const fingers = [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
  const fingerIds = {}

  function rememberTouch (touch) {
    const finger = fingers.pop()
    if (finger === undefined) {
      _zhiuLogger.SystemLog('exhausted touch indentifiers')
    }
    fingerIds[touch.identifier] = finger
  }

  function forgetTouch (touch) {
    fingers.push(fingerIds[touch.identifier])
    delete fingerIds[touch.identifier]
  }

  function emitTouchData (type, touches) {
    const data = new DataView(new ArrayBuffer(2 + 6 * touches.length))
    data.setUint8(0, type)
    data.setUint8(1, touches.length)
    let byte = 2
    for (let t = 0; t < touches.length; t++) {
      const touch = touches[t]
      const x = touch.clientX - playerElement.offsetLeft
      const y = touch.clientY - playerElement.offsetTop
      if (print_inputs) {
        _zhiuLogger.SystemLog(`F${fingerIds[touch.identifier]}=(${x}, ${y})`)
      }
      const coord = normalizeAndQuantizeUnsigned(x, y)
      data.setUint16(byte, coord.x, true)
      byte += 2
      data.setUint16(byte, coord.y, true)
      byte += 2
      data.setUint8(byte, fingerIds[touch.identifier], true)
      byte += 1
      data.setUint8(byte, 255 * touch.force, true) // force is between 0.0 and 1.0 so quantize into byte.
      byte += 1
    }
    sendInputData(data.buffer)
  }

  if (inputOptions.fakeMouseWithTouches) {
    let finger

    playerElement.ontouchstart = function (e) {
      if (finger === undefined) {
        const firstTouch = e.changedTouches[0]
        finger = {
          id: firstTouch.identifier,
          x: firstTouch.clientX - playerElementClientRect.left,
          y: firstTouch.clientY - playerElementClientRect.top
        }
        // Hack: Mouse events require an enter and leave so we just
        // enter and leave manually with each touch as this event
        // is not fired with a touch device.
        playerElement.onmouseenter(e)
        emitMouseDown(MouseButton.MainButton, finger.x, finger.y)
      }
      e.preventDefault()
    }

    playerElement.ontouchend = function (e) {
      for (let t = 0; t < e.changedTouches.length; t++) {
        const touch = e.changedTouches[t]
        if (touch.identifier === finger.id) {
          const x = touch.clientX - playerElementClientRect.left
          const y = touch.clientY - playerElementClientRect.top
          emitMouseUp(MouseButton.MainButton, x, y)
          // Hack: Manual mouse leave event.
          playerElement.onmouseleave(e)
          finger = undefined
          break
        }
      }
      e.preventDefault()
    }

    playerElement.ontouchmove = function (e) {
      for (let t = 0; t < e.touches.length; t++) {
        const touch = e.touches[t]
        if (touch.identifier === finger.id) {
          const x = touch.clientX - playerElementClientRect.left
          const y = touch.clientY - playerElementClientRect.top
          emitMouseMove(x, y, x - finger.x, y - finger.y)
          finger.x = x
          finger.y = y
          break
        }
      }
      e.preventDefault()
    }
  } else {
    playerElement.ontouchstart = function (e) {
      // Assign a unique identifier to each touch.
      for (let t = 0; t < e.changedTouches.length; t++) {
        rememberTouch(e.changedTouches[t])
      }

      if (print_inputs) {
        _zhiuLogger.SystemLog('touch start')
      }
      emitTouchData(MessageType.TouchStart, e.changedTouches)
      e.preventDefault()
    }

    playerElement.ontouchend = function (e) {
      if (print_inputs) {
        _zhiuLogger.SystemLog('touch end')
      }
      emitTouchData(MessageType.TouchEnd, e.changedTouches)

      // Re-cycle unique identifiers previously assigned to each touch.
      for (let t = 0; t < e.changedTouches.length; t++) {
        forgetTouch(e.changedTouches[t])
      }
      e.preventDefault()
    }

    playerElement.ontouchmove = function (e) {
      if (print_inputs) {
        _zhiuLogger.SystemLog('touch move')
      }
      emitTouchData(MessageType.TouchMove, e.touches)
      e.preventDefault()
    }
  }
}

// (检查是否是浏览器按键)  浏览器键没有charCode，因此我们只需要测试keyCode
function isKeyCodeBrowserKey (keyCode) {
  // 功能键或Tab键。
  return keyCode >= 112 && keyCode <= 123 || keyCode === 9
}

// (特殊按键码 组合键)  必须与JavaScriptKeyCodeToFKey C ++数组保持同步。 条目在数组中的索引是下面给出的特殊键代码。
const SpecialKeyCodes = {
  BackSpace: 8,
  Shift: 16,
  Control: 17,
  Alt: 18,
  RightShift: 253,
  RightControl: 254,
  RightAlt: 255
}

// 我们希望能够区分某些键的左右版本。
function getKeyCode (e) {
  if (e.keyCode === SpecialKeyCodes.Shift && e.code === 'ShiftRight') return SpecialKeyCodes.RightShift
  else if (e.keyCode === SpecialKeyCodes.Control && e.code === 'ControlRight') return SpecialKeyCodes.RightControl
  else if (e.keyCode === SpecialKeyCodes.Alt && e.code === 'AltRight') return SpecialKeyCodes.RightAlt
  else return e.keyCode
}

// 注册键盘事件
function registerKeyboardEvents () {
  document.onkeydown = function (e) {
    if (print_inputs) {
      _zhiuLogger.SystemLog(`key down ${e.keyCode}, repeat = ${e.repeat}`)
    }
    // region LJason (这些代码原本在下方) 将 F1 F2 F3 F4 F5 这类浏览器快捷键判断放在上方，不在传入ue4
    if (inputOptions.suppressBrowserKeys && isKeyCodeBrowserKey(e.keyCode)) {
      // e.preventDefault();
      return// 遇到 F5 这种直接跳出不给ue发送
    }
    // endregion
    sendInputData(new Uint8Array([MessageType.KeyDown, getKeyCode(e), e.repeat]).buffer)
    // Backspace is not considered a keypress in JavaScript but we need it
    // to be so characters may be deleted in a UE4 text entry field.
    if (e.keyCode === SpecialKeyCodes.BackSpace) {
      document.onkeypress({ charCode: SpecialKeyCodes.BackSpace })
    }
    // if (inputOptions.suppressBrowserKeys && isKeyCodeBrowserKey(e.keyCode)) {
    // 	e.preventDefault();
    // }
  }

  document.onkeyup = function (e) {
    if (print_inputs) {
      _zhiuLogger.SystemLog(`key up ${e.keyCode}`)
    }
    sendInputData(new Uint8Array([MessageType.KeyUp, getKeyCode(e)]).buffer)
    if (inputOptions.suppressBrowserKeys && isKeyCodeBrowserKey(e.keyCode)) {
      e.preventDefault()
    }
  }

  document.onkeypress = function (e) {
    if (print_inputs) {
      _zhiuLogger.SystemLog(`key press ${e.charCode}`)
    }
    const data = new DataView(new ArrayBuffer(3))
    data.setUint8(0, MessageType.KeyPress)
    data.setUint16(1, e.charCode, true)
    sendInputData(data.buffer)
  }
}

// 当点击右上角+按键 打开页面
function onExpandOverlay_Click (/* e */) {
  const overlay = document.getElementById('overlay')
  overlay.classList.toggle('overlay-shown')
}

// 可以当做重连使用 开始的工作 默认的UI被跳过，直接进行连接
function start () {
  // update "quality status" to "disconnected" state
  const qualityStatus = document.getElementById('qualityStatus')
  if (qualityStatus) { qualityStatus.className = 'grey-status' }

  const statsDiv = document.getElementById('stats')
  if (statsDiv) {
    statsDiv.innerHTML = 'Not connected'
  }

  // region 跳过前端专用
  connect()
  return
  // endregion

  if (!connect_on_load || is_reconnection) {
    showConnectOverlay()
    invalidateFreezeFrameOverlay()
    shouldShowPlayOverlay = true
    resizePlayerStyle()
  } else {
    connect()
  }

  updateKickButton(0)
}

// 更新踢人按键的数量
function updateKickButton (playersCount) {
  const kickButton = document.getElementById('kick-other-players-button')
  if (kickButton) { kickButton.value = `Kick (${playersCount})` }
}

// webSocket梦的开始
function connect () {
  'use strict'// 严格模式
  // window.WebSocket = window.WebSocket || window.MozWebSocket;

  // if (!window.WebSocket) {
  // 	alert('Your browser doesn\'t support WebSocket');
  // 	return;
  // }
  // ws = new WebSocket(window.location.href.replace('http://', 'ws://').replace('https://', 'wss://'));
  ws = new WebSocket(_pixelStreamingURL)

  ws.onmessage = function (event) {
    _zhiuLogger.SystemLog(`<- SS: ${event.data}`)
    const msg = JSON.parse(event.data)
    if (msg.type === 'config') {
      onConfig(msg)
    } else if (msg.type === 'playerCount') {
      updateKickButton(msg.count - 1)
    } else if (msg.type === 'answer') {
      onWebRtcAnswer(msg)
    } else if (msg.type === 'iceCandidate') {
      onWebRtcIce(msg.candidate)
    } else if (msg.type === 'zhiu_CirrusSetWindowSize') {
      _OnCirrusSetWindowSize(msg)
    } else if (msg.type === 'LJason_CirrusReturnPAKFolderPath') {
      _OnCirrusReturnPAKFolderPath(msg)
    } else {
      _zhiuLogger.SystemLog(`invalid SS message type: ${msg.type}`)
    }
  }

  ws.onerror = function (event) {
    _OnWebSocketError(event)
  }

  ws.onclose = function (event) {
    _OnWebSocketClose(event)
    ws = undefined
    is_reconnection = true

    // destroy `webRtcPlayerObj` if any
    const playerDiv = document.getElementById(_videoContainerId)
    if (webRtcPlayerObj) {
      playerDiv.removeChild(webRtcPlayerObj.video)
      webRtcPlayerObj.close()
      webRtcPlayerObj = undefined
    }

    showTextOverlay(`Disconnected: ${event.reason}`)
    // let reclickToStart = setTimeout(start, 4000);// LJason 关闭自动重连
  }
  // LJason 当通道打开的时候给cirrus发一下用户信息
  ws.onopen = function (event) {
    _OnWebSocketOpen(event)
  }
}

// 该方法会创建webRTC的dom元素 并且选择鼠标控制模式当前不锁定模式 （锁定模式类似游戏鼠标不会出去窗口一样）
// 原翻译：通过Cirrus Web服务器从WebRTC发送者接收到的配置数据
function onConfig (config) {
  const playerDiv = document.getElementById(_videoContainerId)
  const playerElement = setupWebRtcPlayer(playerDiv, config)
  resizePlayerStyle()

  switch (inputOptions.controlScheme) {
    case ControlSchemeType.HoveringMouse:
      registerHoveringMouseEvents(playerElement)
      break
    case ControlSchemeType.LockedMouse:
      registerLockedMouseEvents(playerElement)
      break
    default:
      _zhiuLogger.SystemLog(`ERROR: Unknown control scheme ${inputOptions.controlScheme}`)
      registerLockedMouseEvents(playerElement)
      break
  }
}

function load () {
  setupHtmlEvents()
  setupFreezeFrameOverlay()
  registerKeyboardEvents()
  start()
}

// region LJason zhiu专用api
let _pixelStreamingURL// LJason 用于保存推流服务的地址
// LJason 用于保存用户信息
let _playerData = {
  userName: 'undefined', // 用户名称
  userAuthorityLevel: 0, // 用户权限等级
  userId: 'undefined', // 用户id
  // 窗口尺寸 分辨率
  windowSize: {
    width: 0, // 宽
    height: 0// 高
  }
}
let _videoContainerId// 视频容器DOM的id
const _zhiuLogger = {
  isOpenZhiuLog: false,
  isOpenSystemLog: false,
  Log: function (msg) {
    if (this.isOpenZhiuLog) { console.log(' >LJason< 日志：', msg) }
  },
  Warning: function (msg) {
    if (this.isOpenZhiuLog) { console.warn(' >LJason< 警告：', msg) }
  },
  Error: function (msg) {
    if (this.isOpenZhiuLog) { console.error(' >LJason< 错误：', msg) }
  },
  SystemLog: function (msg) {
    if (this.isOpenSystemLog) { console.log(' >System< 日志：', msg) }
  },
  SystemWarning: function (msg) {
    if (this.isOpenSystemLog) { console.warn(' >System< 警告：', msg) }
  },
  SystemError: function (msg) {
    if (this.isOpenSystemLog) { console.error(' >System< 错误：', msg) }
  }
}// 打印功能，可以直接屏蔽系统日志和己方日志
const _zhiuEventManager = {
  ueMessage: [],
  onVideoPlayed: [],
  onWebRTCAggregatedStats: [],
  onOpen: [],
  onClose: [],
  onError: [],
  kickSelfTimeout: []
}// 事件管理
let _lastWindowSize = ''// 最后一次窗口尺寸，防止反复回调
let _kickSelfTimeout// 自踢倒计时句柄
addResponseEventListener('_OnUeMessage', _OnUeMessage)// ue信息回调添加至原生api内
/**
 * ue信息事件
 * @param {string} msg ue的信息，按照双方约定，应该是标准的JSON
 * @private
 */
function _OnUeMessage (msg) {
  _zhiuLogger.Log(' ueMessage信息事件  ' + msg)
  for (let i = 0; i < _zhiuEventManager.ueMessage.length; i++) {
    _zhiuEventManager.ueMessage[i](msg)
  }
}

/**
 * 推流video播放的回调
 * @private
 */
function _VideoPlayedCallback () {
  _zhiuLogger.Log(' onVideoPlayed视频播放事件  ')
  for (let i = 0; i < _zhiuEventManager.onVideoPlayed.length; i++) {
    _zhiuEventManager.onVideoPlayed[i]()
  }

  // region 视频播放后调整分辨率，避免连接过早导致的分辨率不会自动调整的问题
  const playerElement = document.getElementById(_videoContainerId)
  if (playerElement) {
    _lastWindowSize = ''
    _OnWindowResize(playerElement.clientWidth, playerElement.clientHeight)
  }
  // endregion
}

/***
 * webrtc状态回调 内含帧率等消息
 * @param aggregatedStats
 * @private
 */
function _OnWebRTCAggregatedStatsCallback (aggregatedStats) {
  for (let i = 0; i < _zhiuEventManager.onWebRTCAggregatedStats.length; i++) {
    _zhiuEventManager.onWebRTCAggregatedStats[i](aggregatedStats)
  }
}

/**
 * webSocket打开事件 里面包含了向Cirrus更新客户信息功能(zhiu_AppOnOpen)
 * @param {Object} event
 * @private
 */
function _OnWebSocketOpen (event) {
  if (_playerData) {
    _playerData.type = 'zhiu_AppOnOpen'
    ws.send(JSON.stringify(_playerData))
    updateVideoStreamSize()
  }
  _zhiuLogger.Log(' webSocket打开事件  ' + JSON.stringify(event))
  for (let i = 0; i < _zhiuEventManager.onOpen.length; i++) {
    _zhiuEventManager.onOpen[i](event)
  }
}

/**
 * webSocket关闭事件
 * @param {Object} event
 * @param {number} event.code 关闭码 具体在 https://developer.mozilla.org/en-US/docs/Web/API/CloseEvent#Status_codes
 * @param {string} event.reason 关闭原因
 * @private
 */
function _OnWebSocketClose (event) {
  _zhiuLogger.Warning(' webSocket关闭事件 关闭码  ' + event.code + ' 关闭原因：' + event.reason)
  for (let i = 0; i < _zhiuEventManager.onClose.length; i++) {
    _zhiuEventManager.onClose[i](event)
  }
  _lastWindowSize = ''// 关闭时清空分辨率缓存
}

/**
 * webSocket错误事件
 * @param {Object} event
 * @private
 */
function _OnWebSocketError (event) {
  ws = undefined
  is_reconnection = true

  const playerDiv = document.getElementById(_videoContainerId)
  if (webRtcPlayerObj) {
    playerDiv.removeChild(webRtcPlayerObj.video)
    webRtcPlayerObj.close()
    webRtcPlayerObj = undefined
  }

  _zhiuLogger.Log(' webSocket错误事件 错误原因：' + JSON.stringify(event))
  for (let i = 0; i < _zhiuEventManager.onError.length; i++) {
    _zhiuEventManager.onError[i](event)
  }
}

/**
 * Cirrus设置窗口大小事件
 * @param {Object} msg 信息
 * @param {string} msg.width 窗口宽度
 * @param {string} msg.height 窗口宽度
 * @private
 */
function _OnCirrusSetWindowSize (msg) {
  // 如果消息里面宽为空，证明本次需要分辨率更改的不是这个app
  if (msg.width === undefined) {
    // 如果上次的窗口大小不为空字符串，就改为空字符串，避免下次调整时无法调整
    if (_lastWindowSize !== '') {
      _lastWindowSize = ''
    }
  } else {
    const size = msg.width + 'x' + msg.height
    if (size === _lastWindowSize) {
      // _zhiuLogger.Log(" Cirrus调整分辨率---和上次宽高一样不改了 "+size);
    } else {
      _zhiuLogger.Log(' Cirrus调整分辨率指令分辨率大小 (宽高)：' + size + '--_lastWindowSize：' + _lastWindowSize)

      const descriptor = {
        Console: 'setres ' + size
      }
      emitUIInteraction(descriptor)
      const CaptureSize = {
        Console: 'PixelStreaming.Capturer.CaptureSize ' + size
      }
      emitUIInteraction(CaptureSize)
      // console.log(descriptor,CaptureSize);
    }
  }
}

/**
 * 当分辨率产生变化
 * @param {number} width 宽
 * @param {number} height 高
 * @private
 */
function _OnWindowResize (width, height) {
  const data = {
    type: 'zhiu_AppOnWindowResize',
    width,
    height
  }
  ws.send(JSON.stringify(data))
}

/**
 * 创建欢迎页面 用于播放
 * @private
 */
function _CreateWelcomeLay () {
  if (!webRtcPlayerObj) {
    _zhiuLogger.Warning('创建欢迎页失败 _CreateWelcomeLay 没有webRtcPlayerObj')
    return
  }
  let lay = document.createElement('div')
  lay.id = 'zhiu_WelcomeLay_VideoPlay'
  lay.style.width = '100%'
  lay.style.height = '100%'
  lay.style.position = 'absolute'
  lay.style.top = '0'
  lay.style.left = '0'
  lay.style.zIndex = '1'
  lay.style.background = '#000000'
  lay.innerHTML = '点击进入孪生世界'
  webRtcPlayerObj.video.parentElement.append(lay)
  lay.style.lineHeight = lay.offsetHeight + 'px'
  lay.style.textAlign = 'center'
  lay.style.fontSize = '40px'
  lay.style.fontFamily = 'emoji'
  lay.style.color = '#ffffff'
  lay.onclick = () => {
    if (webRtcPlayerObj) {
      _zhiuLogger.Warning('点击欢迎页播放')
      webRtcPlayerObj.video.play()
      lay.parentElement.removeChild(lay)
      lay = undefined
    }
  }
}

/**
 * 输入回调，可用于刷新自踢倒计时
 * @param {number} [delayTime=300000] 默认5分钟踢出
 * @private
 */
function zhiu_ResetAFKTimer (delayTime = 300000) {
  if (_kickSelfTimeout) {
    clearTimeout(_kickSelfTimeout)
  }
  _kickSelfTimeout = setTimeout(() => {
    if (ws) {
      ws.close(4008, 'APP自踢 闲置时间过长  zhiu_ResetAFKTimer 延迟时间：' + delayTime / 60 / 1000 + '分钟')
      for (let i = 0; i < _zhiuEventManager.kickSelfTimeout.length; i++) {
        _zhiuEventManager.kickSelfTimeout[i]()
      }
    }
  }, delayTime)
}

/**
 * 增加监听
 * @function zhiu_AddListener
 * @param {string} eventName 事件名称  ueMessage wsOpen wsClose wsError
 * @param {function} callback 回调
 */
function zhiu_AddListener (eventName, callback) {
  switch (eventName) {
    case 'app_ueMessage':
      _zhiuEventManager.ueMessage.push(callback)
      break
    case 'app_videoPlayed':
      _zhiuEventManager.onVideoPlayed.push(callback)
      break
    case 'app_webRTCAggregatedStats':
      _zhiuEventManager.onWebRTCAggregatedStats.push(callback)
      break
    case 'app_wsOpen':
      _zhiuEventManager.onOpen.push(callback)
      break
    case 'app_wsClose':
      _zhiuEventManager.onClose.push(callback)
      break
    case 'app_wsError':
      _zhiuEventManager.onError.push(callback)
      break
    case 'app_kickSelfTimeout':
      _zhiuEventManager.kickSelfTimeout.push(callback)
      break
  }
}

/**
 * 发送信息到ue
 * @function zhiu_SendMsgToUe
 * @param {object} msgObject 信息对象 内部会自动转为字符串 不需要专门转换
 */
function zhiu_SendMsgToUe (msgObject) {
  zhiu_ResetAFKTimer()
  // delete msgObject.Time
  // msgObject.time = Date.now()
  console.log('发送UE事件', msgObject)
  emitUIInteraction(msgObject)
}

/**
 * 初始化ue推流 并且直接开启
 * @function zhiu_InitializePixelStream
 * @param {string} url 推流服务器地址 记得端口 用的是Cirrus的http端口  从matchmaker可以直接获取
 * @param {string} videoContainerId 推流视频容器的id dom节点 会在该节点下方创建固定的video标签来容纳推流
 * @param {Object} userData 用户数据
 * @param {string} userData.userName 用户数据
 * @param {number} userData.userAuthorityLevel 用户数据
 * @param {string} userData.userId 用户数据
 */
function zhiu_InitializePixelStream (url, videoContainerId, userData = undefined) {
  _pixelStreamingURL = url
  _videoContainerId = videoContainerId
  _playerData = userData
  load()
}

/**
 * 关闭ue推流
 * @function zhiu_ClosePixelStream
 */
function zhiu_ClosePixelStream () {
  if (ws) {
    ws.close(4007, 'APP主动关闭连接 zhiu_ClosePixelStream')
  }
}

/**
 * 重连ue推流
 * @function zhiu_ReconnectPixelStream
 */
function zhiu_ReconnectPixelStream () {
  if (!ws) {
    connect()
  } else {

  }
}

/**
 * 播放推流 ios端因为不会自动播放 留作备用
 */
function zhiu_PlayVideoPixelStream () {
  webRtcPlayerObj.video.play()
}

/**
 * 通过Cirrus踢出该推流所有玩家 可以选择是否包含自己
 * @function zhiu_UseCirrusServerKickAllPlayers
 * @param {boolean}  hasSelf 是否踢掉自己
 */
function zhiu_UseCirrusServerKickAllPlayers (hasSelf = false) {
  const data = {
    type: 'zhiu_AppKickAllPlayers',
    hasSelf
  }
  ws.send(JSON.stringify(data))
}

// region Pak路径获取流程 专用于CIM基础信息平台
let _pakFolderPath// pak文件夹路径
const _pakFolderCallbackList = []// pak获取文件回调
/**
 * 请求发送给cirrus 由Cirrus处理完发送回来
 * @param pakFolderCallback {function} 回调 参数为pak路径
 * @private
 */
function zhiu_GetPakFolderPath (pakFolderCallback) {
  const msg = {
    type: 'LJason_AppGetPAKFolderPath'
  }
  _pakFolderCallbackList.push(pakFolderCallback)
  ws.send(JSON.stringify(msg))
}

/**
 * 当cirrus返回pak路径  （该func必须挂在connect内部的ws.onmessage里面才能生效）
 * @param data
 * @private
 */
function _OnCirrusReturnPAKFolderPath (data) {
  if (_pakFolderCallbackList.length > 0) {
    _pakFolderCallbackList.shift()(data.PAKFolderPath)
  }
}

// endregion

// endregion

const zhiuPSWeb = {
  zhiu_AddListener,
  zhiu_SendMsgToUe,
  zhiu_InitializePixelStream,
  zhiu_ClosePixelStream,
  zhiu_ReconnectPixelStream,
  zhiu_PlayVideoPixelStream,
  zhiu_UseCirrusServerKickAllPlayers
}
export default { ...zhiuPSWeb }
