
<template>
  <div>
    <ue4Player />
  </div>
</template>

<script>
import ue4Player from './ue4Player.vue'
import { app_load } from './app'

export default {
  components: { ue4Player },
  name: 'Example',
  props: {},
  mounted () {
    app_load('127.0.0.1:7777', () => {
      console.log('画面出现之前的回调，可进行一些初始操作')
    })
  },
  methods: {
  }
}
</script>

<style scoped>
button {
  background-color: rgb(187, 187, 187);
  /* display: block; */
}
</style>
