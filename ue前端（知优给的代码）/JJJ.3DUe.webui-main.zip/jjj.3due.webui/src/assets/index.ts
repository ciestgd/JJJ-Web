import ue4 from "./ue4/app";
import axios from "axios";

/**
 * @author: 王琛
 * @description: UE4项目初始化
 * @Date: 2021-11-15 09:37:53
 * @param {*}
 * @return {*}
 */
export class ue4Init {
  ue4 = ue4;
  message = (data: any) => {
    // console.log('%c王琛-141259', 'color:#fff;background:#ee6f57;padding:3px;border-radius:2px', data)
  };

  constructor(url?: any, name?: any, userName?: any | undefined) {
    // 获取项目名称
    const projectName = name || "not";
    // const userName = userName || "unknown";
    // 判断如果没有给到ue4地址则不会显示流信息;
    if (!url) return;
    // 先关掉UE4场景再开开;
    ue4.zhiu_ClosePixelStream();
    // 所有的cirrus服务
    axios
      .get(`${url}GetAllCirrus`, { params: { zhiu: projectName } })
      .then((data) => {
        const cirrusList = data.data;
        let cirrusServerUrl = "wss://";
        let isReady = false;
        console.warn(" >LJason< 警告：所有cirrus信息", cirrusList);
        // 寻找推流准备就绪的，并且项目名称对上的cirrus
        for (const cirrusId in cirrusList) {
          // console.log(' >LJason< 日志：cirrusList[cirrusId].ready ', cirrusList[cirrusId].ready)
          // console.log(' >LJason< 日志：cirrusList[cirrusId].NowProjectName ', cirrusList[cirrusId].NowProjectName)
          if (
            cirrusList[cirrusId].ready &&
            cirrusList[cirrusId].NowProjectName === projectName
          ) {
            // 检查该服务是否有用户存在，存在就不使用
            if (cirrusList[cirrusId].PlayerList.length < 5) {
              // 是否使用公网ip
              if (cirrusList[cirrusId].UsePublicIp) {
                cirrusServerUrl += cirrusList[cirrusId].PublicIP;
              } else {
                cirrusServerUrl += cirrusList[cirrusId].LocalIP;
              }
              cirrusServerUrl += ":" + cirrusList[cirrusId].NowHttpPort;
              isReady = true;
              // console.log(' >LJason< 日志：找到合适的Cirrus了 ' + cirrusServerUrl)
              break;
            }
          }
        }
        // 如果没有找到合适的就放弃了
        if (!isReady) {
          // console.error(' >LJason< 错误：没有合适的Cirrus服务 项目名称' + projectName)
          // this.$alert('当前没有合适的服务器，请稍后刷新重试......', '知优科技', {
          //   confirmButtonText: '谢谢',
          //   callback: action => {}
          // });
          return;
        }
        // 初始化推流
        ue4.zhiu_InitializePixelStream(cirrusServerUrl, "player", {
          userName: userName || "unknown",
          userAuthorityLevel: 99,
          userId: userName || "unknown" + "id",
        });
        // 接收ue信息的回调
        ue4.zhiu_AddListener("app_ueMessage", (msg: any) => {
          const obj = JSON.parse(msg);
          this.message(obj);
          // console.log('%c王琛-125703', 'color:#fff;background:#ee6f57;padding:3px;border-radius:2px', obj);
          // if (obj.time) State.ue4ToData = obj;
        });
        // socket连接成功
        ue4.zhiu_AddListener("app_wsOpen", (event: any) => {
          console.warn(" >LJason< 警告： wsOpen  ", event);
        });
        // 连接结束
        ue4.zhiu_AddListener("app_wsClose", (event: any) => {
          console.warn(" >LJason< 警告： wsClose  ", event);
        });
        // 连接错误
        ue4.zhiu_AddListener("app_wsError", (event: any) => {
          console.warn(" >LJason< 警告： wsError  ", event);
        });
        // 自踢回调
        ue4.zhiu_AddListener("app_kickSelfTimeout", () => {});
        // UE连接成功
        ue4.zhiu_AddListener("app_videoPlayed", () => {
          console.log(
            "%c王琛-095718",
            "color:#fff;background:#ee6f57;padding:3px;border-radius:2px",
            "我sss连接UE4成功了"
          );
        });
      });
    return this;
  }
}
