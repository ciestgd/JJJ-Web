
<script setup lang="ts">
/*eslint-disable*/
// import DevicePixelRatio from '@/utils/evicePixelRatio'
import { ref, reactive, watch, onMounted } from 'vue'
import { useStore } from 'vuex'
// import { GoBackApi } from '@/api/ue4'
import { ue4Init } from '@/assets/index'
import { useUserStore } from '@/store1/zhuangTaiGuanjLi'
import zhCN from 'ant-design-vue/es/locale/zh_CN'
import dayjs from 'dayjs'
import 'dayjs/locale/zh-cn'
dayjs.locale('zh-cn')
const userStore1 = useUserStore()
const locale = ref(zhCN)
const store = useStore()

onMounted(() => {
  store.commit('appStore/SET_URLKEY', '/index')
  // store.commit('appStore/SET_FLOOR', '')
  userStore1.cangShiXuanZhongBtn('')
  store.commit('appStore/SET_HOMESTATUS', true)
  store.commit('appStore/SET_STATUSOPEN', [true, false,false])
  store.commit('appStore/SET_LEFTHEIGHT', '50.4688rem')
  store.commit('appStore/SET_LEFTSMALLHEIGHT', '41.6667rem')
  store.commit('appStore/SET_LEFTTOP', '1.0417rem')
  const externalScript = document.createElement('script')
  externalScript.setAttribute('src', 'https://[scripturletc].min.js')
  document.head.appendChild(externalScript)
})

</script>

<template>
  <a-config-provider :locale="locale">
    <router-view />
  </a-config-provider>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  /* margin-top: 60px; */
}
* {
  margin: 0;
  padding: 0;
}
p {
  margin-bottom: 0 !important;
}
</style>
