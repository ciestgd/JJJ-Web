/*
 * @Author: moli 992954701@qq.com
 * @Date: 2022-08-03 14:25:09
 * @LastEditors: moli 992954701@qq.com
 * @LastEditTime: 2022-09-21 14:17:18
 * @FilePath: /pc/src/main.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { createApp, markRaw } from 'vue'
import App from './App.vue'
import store from './store'
import store1 from './store1'
import { setDomFontSize } from './utils/dom'

import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import zhCn from 'element-plus/es/locale/lang/zh-cn'

import 'default-passive-events'

import 'animate.css'

import Antd from 'ant-design-vue'
import 'ant-design-vue/dist/antd.css'

/* 引入第三方字体 */
import '@/assets/font/font.less'
/* reset.less */
import '@/styles/reset.less'
/* 引入echarts */
import * as echarts from 'echarts'

/* 全局引入element-plus的icon */
import * as ElIcons from '@element-plus/icons-vue'
import 'virtual:svg-icons-register'
// import '@/router/promit'
import { router } from './router' // npm install vue-router@4.0.0-beta.13 安装vue-router
/* 全局组件 */
import SvgIcon from '@/components/SvgIcon.vue'
setDomFontSize()
const app = createApp(App)
app.use(router)
app.use(store)
app.use(store1)

app.use(ElementPlus, {
  locale: zhCn
})
app.use(Antd)

app.component('SvgIcon', markRaw(SvgIcon))

for (const name in ElIcons) {
  app.component(name, (ElIcons as any)[name])
}

app.config.globalProperties.$echarts = echarts
app.mount('#app')
