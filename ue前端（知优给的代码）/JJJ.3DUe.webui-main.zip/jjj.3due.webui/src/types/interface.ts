export interface IObject<T=any>{
    [key:string]:T;
}

export interface IHttpResponse extends IObject {
    code:number;
    msg:string;
    data:any
}
